# VNC Drill Evidence Review — Public Safe Edition

This is a review-only skill for organizing and evaluating evidence from explicitly authorized CTF or training exercises.

It does not include the original package's VNC automation, remote command execution, credential collection, file transfer, or answer-submission scripts. It does not authorize access to any system.

## Contents

- `SKILL.md` — scope checks, evidence review workflow, stop conditions, and reporting format.

## Install

Copy the `vnc-drill-evidence-review` folder into your Claude Code skills directory:

`%USERPROFILE%\.claude\skills\vnc-drill-evidence-review\`

Use it only with evidence and within the scope authorized by the exercise organizer.
