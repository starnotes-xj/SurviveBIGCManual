# 平台参考：URL 模板 / 接口 / 设备数据（奇安信 tp.qianxin.com 实测）

> 来源：2026-10-11 三场实战（planid 234/235）。平台改版时以页面实际 DOM/接口为准。

## 1. 关键 URL 模板

```
# 演练任务页（读题/提交/进度）
https://tp.qianxin.com/static/dril-web/#/index?uuid=<sourceid>&planid=<planid>&navKey=3
# 单台靶机 VNC 控制台（深链）
https://tp.qianxin.com/static/topo/?_=<随机数,仅用于强制重连>#/vnc?dark=1&view=1&module=drill&type_=taskdrill
        &sourceid=<sourceid>&planid=<planid>&real_user_id=&uuid=<设备domainuuid>&type=vnc&deviceName=<设备名>
```
- `uuid=`（vnc 路由内）要填设备的 **domainuuid**（= nodelist 中该设备对象的**键**），不是节点 `info.uuid`；
- `?_=数字` 只加在 `#` 之前，用于整页重载重连；
- 控制台网关：`wss://tp.qianxin.com/websockify?token=...`（VNC）、`wss://tp.qianxin.com/pty_terminal?pty_path=...`（SSH）；
- 本机可访问 `tp.qianxin.com`，但演练内网（10.0.x/172.16.x）**本机不可达** —— 一切经浏览器。

## 2. 平台 HTTP 接口（同源 POST；鉴权头 `token` + `real_user_id`，取自 localStorage）

token 获取：页面 console 或 `evalenv`（环境变量注入，不落盘）：
`localStorage.userStore.userConfig.auth.token`、`real_user_id`。

| 接口 | 用途 | 备注 |
|---|---|---|
| `POST /domain/domain/nodelist` | 全部设备：名称/uuid/domainuuid/IP/账号口令 `account_json`/protocol(vnc/rdp)/vm_status | body 用 drill 参数：`dark=1&view=1&module=drill&type_=taskdrill&sourceid=<uuid>&planid=<planid>` |
| `POST /domain/domain/gettopo` | 拓扑 JSON（节点坐标、连线、credential） | |
| `POST /domain/domain/topostatus` | 环境启动状态（domains/vm_status） | 排"控制台连不上"先查它 |
| `POST /domain/domain/console` | 取某设备控制台信息（VNC token/口令/超时） | body: `domainuuid=..&protocol=vnc&uuid=..&deviceName=..&type=vnc` |
| `POST /drill/taskview/tasks` `/taskinfo` `/gettip` `/submit` `/downloadFile` … | 任务/提示/提交/下载 | 前端 UI 已封装，一般直接走页面 |
| `POST /sessions/<token>/ls?protocol=...&dir=/`、`download` | guest 文件浏览/下载 | **仅 RDP 会话可用**；VNC 会话返回「当前协议不支持此操作」→ 只能读屏或内网中转 |
| `POST /tool/tools/getViewList` | 工具库文件列表 | 与"导入工具"抽屉对应 |

工具：`scripts/api-nodes.js`（设备清单）、`api-status.js`、`api-console2.js`、`14-cdp-session.mjs`（现取 token+Cookie）、`22-plat-call.mjs`（带鉴权直连任意接口）。

## 3. 页面内取设备清单（不走接口时的替代）

拓扑页 `#/sceneTopo` 里执行：
```js
JSON.parse(findnodelist())   // 每项含 info.text(设备名) info.uuid netCardList[].ip_addr account_json protocol
```
**设备 key = 返回 JSON 对象的键（domainuuid）**，vnc 深链用它。

## 4. 任务页 DOM 速查

```js
// 场景页签（叶子元素文本）：
['移动应用服务器应急响应溯源','企业网应急溯源','APT 恶意样本深度分析']
// 题卡（例）："指定任务 (完成)? <题面> N分/M分"；得分>0 或「完成」= 已完成
// 已/未完成一次抓取（peek-tasks 同款正则）：
const cards=[...document.querySelectorAll('*')].filter(e=>e.children.length>0&&/指定任务/.test(e.innerText||'')&&(e.innerText||'').length<300);
// 提交链：textarea（原生 setter+input/change）→ div.btn-item-style(「提交」) → .ant-message-notice 判定
```

## 5. noVNC 页要点

- 画面在 `<canvas>`；**canvas 截图用 `canvas.toDataURL('image/png')`**（Page 截图对 canvas 常黑）；
- 控制台 tab 有上限（本环境约 4~6），开新设备前关掉不用的（`/json/close/<id>`）；
- 连接慢：开页后等 15~25s；就绪判据 `document.querySelectorAll('canvas').length===1`；
- 键盘：shift/ctrl 需**物理按键事件**；本技能 `vm.js`/`sendkeys.js`/`vnc-helper-browser.js` 均已实现。

## 6. 坐标换算

```js
const r = document.querySelector('canvas').getBoundingClientRect();
cssX = r.x + guestX * r.width  / canvas.width;    // guest 分辨率 = canvas.width × canvas.height
cssY = r.y + guestY * r.height / canvas.height;
// 实例：画布 {x:145.1,y:50.4,w:1089.8,h:608.2}，guest 1376×768 → 中心 ≈ (690, 354)
```

## 7. 实测设备与凭据（planid 235 企业网，示例；以 nodelist 实测为准）

| 主机 | IP | 账号/口令 | 角色 |
|---|---|---|---|
| WEB-DMZ | 10.0.10.10 / 10.0.20.10 | root / Root@Lab#Web | Web 入口（Tomcat/log4j） |
| DB-SRV | 10.0.20.20 | root / Root@Lab#Db | 数据库 |
| DC-FILE | 10.0.20.30 | administrator / Admin!Lab | 域控/文件 |
| PC-HR | 10.0.20.40 | hruser / Hr@Lab#Pc | 办公机 |
| EVIDENCE | 10.0.20.50 | administrator / Admin123 | **取证机（常放 pcap/tshark）** |
| 攻击者基础设施 | 10.0.10.100 / 10.0.10.200（C2:8080/8443） | — | 初始化访问/横向/C2 |

## 8. 注意事项

- 目标机常有多路输入（队友/其他 agent）→ 命令短、分步、每步截图确认（§协作协议）。
- 目标机可能没有 hashcat/john/字典 → 哈希题从能出网的机器跑，或从流量/脚本里找明文。
- 提交被拒=答案错；用分数变化与 `answers.json` 留痕判断，**不要重复轰炸**。
