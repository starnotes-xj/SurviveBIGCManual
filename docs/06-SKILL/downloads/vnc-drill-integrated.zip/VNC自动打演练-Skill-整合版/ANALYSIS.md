# 三套 SKILL 优缺点分析与整合取舍

> 对象（2026-10-11 同一天、同一平台 `tp.qianxin.com` 三次实战沉淀）：
> - **S1** ＝ `C:\Users\星记\Desktop\CTF-drill-skill`（Edge+CDP 脚本流，"下午应急响应表现最好"的那套；已知问题：**偶尔分不清该提交到哪个类别、重复提交已完成的题**）
> - **S2** ＝ `C:\Users\星记\Desktop\Desktop`（vnc-drill-autoplay 字形解码流 + 补充篇 + 实战手册 + toolkit，工程化最深的一套）
> - **S3** ＝ `.claude\skills\drill-vnc-solver`（chrome-devtools MCP 会话内直驱流，本次会话沉淀）

---

## 1. 逐套分析

### S1 · CTF-drill-skill（Edge+CDP 脚本流）

**精华（已采纳）**
- 骨架清晰、零依赖：`cdp.js`（读写页面）+ `vm.js`（noVNC 键鼠，**Shift 物理按键**的正确实现 + `canvas.toDataURL` 截图）+ `submit.js`/`net.js`/`watch.js`；
- `setup-edge.ps1`：一键复制 profile 使 Edge 可调试（免登且不动原始数据）；
- 文档聚焦操作、坑表精炼（CDP 接入/输入/提交/取证四段）；
- 实战背书：APT 样本分析满分 + 企业网溯源 33/36。

**糟粕（已修/已弃）**
- `submit.js` **硬编码"企业网应急溯源"场景**：任务不在该场景时要么空转 60 轮、要么在错误类别里撞文本 → **场景错配的根源**；
- **不查完成状态、不留痕**：已得分/已提交过的题会再交一遍 → **重复提交的根源**；
- `vm.js` 只能逐字符 `type`，没有"把脚本一次带进去"的通道（长命令/引号场景弱）；
- 无单控制台/掉线自愈工具，无进度盘点工具。

**处置**：骨架保留；`submit.js` **重写为 v2**（场景感知 + 三道防重闸 + answers.json 留痕 + 退出码）；`vm.js/setup-edge.ps1/net.js/watch.js` 原样并入。

### S2 · Desktop 大礼包（vnc-drill-autoplay / 补充篇 / 实战手册 / toolkit）

**精华（已采纳）**
- **读屏确定性**：字形模板解码器（glyph.ps1 + 字形表），把"OCR 猜字"升级为逐字符精确；
- **写屏确定性**：`pushsh.js`（base64 免引号 + md5 自校验 + 末尾补回车）；`sendkeys.js`（三段式键事件）；
- **★浏览器侧文件投递**（补充篇核心）：导入文件抽屉 = 零键盘把任意文件挂成靶机光驱（Win `D:\`、Linux `/dev/sr0`），工具表一键推 Wireshark；
- **Windows 生态**：`winr.js`（Win+R 拿焦点，绕开 QuickEdit 标记模式）、`cad.js`（Ctrl+Alt+Del 解锁）、EncodedCommand 无引号套路；
- **纪律与自愈**：`focus.js` 单控制台、`ensure-vnc.js` 掉线自愈、冲突检测三信号；
- **证据级校验**：MD5 + 单字符变体穷举证明唯一原像（关键值时一锤定音）；
- **平台接口**：nodelist/gettopo/console 一次拿全设备口令；大 pcap"一趟全量提取 + findstr"；多 AI `talk.txt` 协作协议。

**糟粕（已弃/裁剪）**
- **体量大而散**：同一内容四份副本（skills 版、toolkit 版、补充篇、手册），271 个文件，重复脚本彼此不同步；
- 部分是一次性探针/样例（probe-*.js、samples/*.png/txt、dbg.ps1 等），无长期价值；
- 门槛：字形表维护、PowerShell 5.1 中文路径/编码坑，对"AI 直接读图已够用"的场景是过度工程；
- 文档互相引用、口径不一（README/SKILL/手册三处描述同一工具用法）。

**处置**：以 `skills/vnc-drill-autoplay/scripts`（107 文件、已整理版）为基并入；补入补充篇的导入文件/run-dialog/vnc-send/OCR 脚本；丢弃 toolkit 重复副本与一次性探针；两篇经验（避坑 9 条、校验法、大 pcap、协作）并入 SKILL.md/checklists。

### S3 · drill-vnc-solver（chrome-devtools MCP 直驱流）

**精华（已采纳）**
- **零额外基建**：Claude Code 自带 chrome-devtools MCP 就能驱动用户浏览器里的 noVNC，不需要开 9222、不需要装脚本；
- **计算+输入合体**：一次 `evaluate_script` 先做本地计算（解码/穷举/比对）再注入下一批命令，往返效率高；
- 明确的键盘助手实现（Shift 序列、符号映射、节奏控制）与"每次重载需重注入"意识。

**糟粕/弱点（已在整合中补强）**
- **无自愈**：页面被重载/浏览器重连（Target closed）后只能手动重建；无 ensure-vnc/focus 类工具；
- **无批次化通道**：长脚本仍靠逐字符敲；没有 base64 注入/导入文件通道；
- **无提交模块**：答题环节靠临场手写 DOM 操作，无防重纪律；
- 输入脆弱性：被"菜单/QuickEdit/多会话"干扰时缺乏标准处置（本次实测踩过：菜单吞键、Ctrl 组合失效）。

**处置**：作为"路线 B"正式并列进 SKILL.md；键盘助手升级为 `vnc-helper-browser.js`（加特殊键、返回几何信息）；其缺口用 S1/S2 的工具补齐；提交环节统一走 `submit.js v2`。

---

## 2. 整合后相对原件的改进（新增价值）

| 项 | 说明 |
|---|---|
| **`submit.js v2`（新写）** | 场景感知（跨场景自动定位 + 歧义退出）、三道防重闸、`answers.json` 留痕、`--list/--dry/--pick/--retry-wrong`、`RESULT {JSON}` + 退出码 → 直接修复 S1 两起事故 |
| **单一口径文档** | SKILL.md 一份总纲（路线/铁律/SOP/纪律/坑表/脚本索引），README 30 秒上手，reference 两篇深水区 —— 替代原来 5+ 份互有出入的文档 |
| **两条路线并列** | 脚本化（9222）与会话内（MCP）共用同一套经验与坑表，按场景选型 |
| **坑表去重合并** | 三套文档里的 ~40 条坑合并为 25 条权威表（同坑归一、按环节排序） |
| **目录瘦身** | 271+ 散文件 → `scripts/`（52 顶级文件 + guest 子目录）+ `reference/` 2 篇 + 3 份根文档 |

## 3. 保留 / 丢弃清单（可核对）

**保留**：S1 的 vm.js/setup-edge.ps1/net.js/watch.js/cdp 思路；S2 的全部核心工具（glyph/pushsh/sendkeys/winr/cad/ai1-shot/import 系列/focus/ensure-vnc/api 系列/guest 取证脚本库/两篇经验）；S3 的键盘助手与 MCP 路线。
**丢弃**：S1 旧 submit.js（留档为 submit-legacy.js）；S2 的 toolkit 重复副本、samples 样例文件、一次性探针（保留 probe-canvas/probe-reconnect/click-reconnect 三个有复用价值的）；重复文档。
**未动**：三个原始目录原样保留（本目录是整合成品，原件可随时回溯比对）。
