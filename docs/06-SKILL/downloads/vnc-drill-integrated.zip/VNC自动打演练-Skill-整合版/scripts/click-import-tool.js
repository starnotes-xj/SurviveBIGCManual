(async () => {
  const rows = [...document.querySelectorAll('#class-item-dialog tr')];
  const w = rows.find(tr => /Wireshark/i.test(tr.innerText || ''));
  if (!w) return 'NOROW';
  const i = w.querySelector('i.anticon-upload');
  if (!i) return 'NOICON';
  const target = i.closest('span') || i;
  const r = target.getBoundingClientRect();
  target.click();
  await new Promise(r2 => setTimeout(r2, 2500));
  const modals = [...document.querySelectorAll('.ant-modal, .ant-popover, .ant-dropdown, .ant-message, .ant-notification')]
    .map(e => (e.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 300)).filter(Boolean);
  return JSON.stringify({ clicked: true, rect: { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) }, modals, drawerTail: (document.querySelector('#class-item-dialog').innerText || '').slice(-250) }, null, 1);
})()
