#!/usr/bin/env node
'use strict';
/**
 * submit.js —— 演练任务页「场景感知 + 已答防重 + 结果留痕」答题提交器（整合版 v2）
 *
 * 修复了历史两起事故：
 *   A. 提交到错误类别（场景）：现在 ①可显式 --scene；②不指定时自动在全部场景里定位题目；
 *      ③场景切换后必须等到题卡真正出现（SCENE_EMPTY/SCENE_NOT_FOUND 会明确报错而不是乱交）。
 *   B. 重复提交已完成的题：三道闸——本地 answers.json 留痕、页面实时得分/「完成」标记、
 *      提交按钮禁用检测；（除非显式 --force / --retry-wrong）。
 *
 * 用法：
 *   node submit.js --list                        # 扫描全部场景：完成度 + 未答题清单
 *   node submit.js --list --scene 企业网应急溯源   # 只看一个场景
 *   node submit.js --list --all                  # 连已完成的一起列
 *   node submit.js "<题面子串>" "<答案>"           # 自动定位（跨场景）后提交
 *   node submit.js "<题面子串>" "<答案>" --scene <场景名>
 *   node submit.js "<题面子串>" --dry             # 只定位+打开题卡看详情，不提交（核对用）
 *   可选： --pick N（多匹配选第N个） --retry-wrong（允许重交以前判错的题）
 *          --force（强行提交已完成/已留痕的题，慎用） --match <url子串> --port 9222
 *
 * 输出：过程为人读文本；最后一行 `RESULT {JSON}` 为机器可读回执。
 * 退出码：0=正确 2=错误 3=重复/已答/锁定 4=没找到题 5=歧义需消歧 9=环境/用法错误
 * 留痕文件：同目录 answers.json（追加式，含时间/场景/题面/答案/判定）
 */
const fs = require('fs');
const path = require('path');

const argv = process.argv.slice(2);
const hasFlag = f => argv.includes(f);
function optOf(name, def) {
  const i = argv.indexOf(name);
  if (i < 0) return def;
  const v = argv[i + 1]; argv.splice(i, 2); return v;
}
const PORT = optOf('--port', '9222');
const MATCH = optOf('--match', 'dril-web');
const SCENE_OPT = optOf('--scene', '');
const PICK = Number(optOf('--pick', '0')) || 0;
const DRY = hasFlag('--dry');
const RETRY_WRONG = hasFlag('--retry-wrong');
const FORCE = hasFlag('--force');
const LIST = hasFlag('--list');
const SHOW_ALL = hasFlag('--all');
const SCENES = optOf('--scene-names',
  '移动应用服务器应急响应溯源,企业网应急溯源,APT 恶意样本深度分析').split(',');
const Q = argv[0] || '';
const A = argv[1] || '';
const LEDGER = path.join(__dirname, 'answers.json');
const base = `http://127.0.0.1:${PORT}`;
const sleep = ms => new Promise(r => setTimeout(r, ms));

function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let id = 0; const pending = new Map();
    ws.addEventListener('message', ev => {
      let msg; try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id); pending.delete(msg.id);
        msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
      }
    });
    ws.addEventListener('error', () => reject(new Error('ws fail')));
    ws.addEventListener('open', () => resolve({
      send(m, p) { return new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); },
      close() { try { ws.close(); } catch {} }
    }));
  });
}
async function ev(c, expression) {
  const r = await c.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true, userGesture: true });
  if (r.exceptionDetails) return 'ERR:' + JSON.stringify(r.exceptionDetails).slice(0, 300);
  return r.result ? r.result.value : null;
}

const EXTRACT = `(() => {
  const nodes = [...document.querySelectorAll('*')].filter(e => e.children.length > 0 && /指定任务/.test(e.innerText||'') && (e.innerText||'').length < 300);
  const seen = new Set(); const out = [];
  for (const n of nodes) {
    const t = (n.innerText||'').replace(/\\s+/g,' ').trim();
    if (seen.has(t)) continue; seen.add(t);
    const m = t.match(/指定任务\\s*(完成)?\\s*(.+?)\\s*(\\d+)\\s*分\\s*\\/\\s*(\\d+)\\s*分/);
    if (!m) continue;
    const got = Number(m[3]);
    out.push({ raw: t, q: m[2].trim(), done: !!m[1] || got > 0, got, total: Number(m[4]) });
  }
  return JSON.stringify(out);
})()`;
async function extractCards(c) {
  const v = await ev(c, EXTRACT);
  if (typeof v !== 'string' || v.startsWith('ERR:')) return [];
  try { return JSON.parse(v); } catch { return []; }
}
async function switchScene(c, name) {
  const r = await ev(c, `(() => {
    const els = [...document.querySelectorAll('span,div,li')].filter(e => e.children.length === 0 && (e.innerText||'').trim() === ${JSON.stringify(name)});
    if (!els.length) return 'NOTFOUND';
    els[0].click(); return 'OK';
  })()`);
  if (r !== 'OK') return 'SCENE_NOT_FOUND';
  for (let i = 0; i < 14; i++) {
    await sleep(1200);
    if ((await extractCards(c)).length) return 'OK';
  }
  return 'SCENE_EMPTY';
}
function clickCardJS(q) {
  return `(() => {
    const q = ${JSON.stringify(q)};
    const cards = [...document.querySelectorAll('*')].filter(e => e.children.length > 0 && (e.innerText||'').includes('指定任务') && (e.innerText||'').includes(q) && (e.innerText||'').length < 300);
    if (!cards.length) return 'NOCARD';
    const el = cards[cards.length - 1];
    el.scrollIntoView({ block: 'center' }); el.click(); return 'CLICKED';
  })()`;
}
function ledgerLoad() { try { return JSON.parse(fs.readFileSync(LEDGER, 'utf8')); } catch { return []; } }
function ledgerSave(arr) { try { fs.writeFileSync(LEDGER, JSON.stringify(arr, null, 2)); } catch {} }
const norm = s => (s || '').replace(/\s+/g, ' ').trim();
function ledgerFind(led, scene, q) {
  return led.find(e => e && e.scene === scene &&
    (norm(e.q) === norm(q) || norm(e.q).includes(norm(q)) || norm(q).includes(norm(e.q))));
}
function out(o) { console.log('RESULT ' + JSON.stringify(o)); }
function bail(code, o) { out(o); process.exit(code); }

(async () => {
  if (!LIST && !Q) {
    console.log('用法: node submit.js --list | node submit.js "<题面子串>" "<答案>" [--scene 场景] [--dry] [--retry-wrong] [--force]');
    process.exit(9);
  }
  let page;
  try {
    const list = await (await fetch(base + '/json/list')).json();
    page = list.find(t => t.type === 'page' && (t.url || '').includes(MATCH));
    if (!page) {
      console.log('没找到 URL 含 "' + MATCH + '" 的页面。当前页面：');
      list.filter(t => t.type === 'page').forEach(t => console.log('  ' + t.url));
      process.exit(9);
    }
  } catch (e) {
    console.error('连不上 CDP(' + base + ')。请用带 --remote-debugging-port=' + PORT + ' 的浏览器打开演练任务页（见 scripts/setup-edge.ps1 或 SKILL.md 会话自愈）。');
    process.exit(9);
  }
  const c = await connect(page.webSocketDebuggerUrl);
  try { await c.send('Page.bringToFront'); } catch {}
  // 确保在「演练任务」视图
  await ev(c, `(() => { const nav=[...document.querySelectorAll('span,a,div,li')].filter(e=>(e.innerText||'').trim()==='演练任务'); if(nav.length) nav[nav.length-1].click(); return 'ok'; })()`);
  await sleep(2000);

  if (LIST) {
    for (const s of (SCENE_OPT ? [SCENE_OPT] : SCENES)) {
      const st = await switchScene(c, s);
      if (st !== 'OK') { console.log('== ' + s + '  [' + st + ']'); continue; }
      const cards = await extractCards(c);
      const doneN = cards.filter(x => x.done).length;
      console.log('== ' + s + '  [' + doneN + '/' + cards.length + ' 完成 | 得分 ' +
        cards.reduce((a, x) => a + x.got, 0) + '/' + cards.reduce((a, x) => a + x.total, 0) + ']');
      for (const x of cards) {
        if (!SHOW_ALL && x.done) continue;
        console.log('   [' + (x.done ? '完成' : '未答') + ' ' + x.got + '/' + x.total + '] ' + x.q);
      }
    }
    c.close(); process.exit(0);
  }

  // —— 定位题目：指定场景优先；未指定则全场景搜索 ——
  const order = SCENE_OPT ? [SCENE_OPT, ...SCENES.filter(s => s !== SCENE_OPT)] : SCENES;
  const found = [];
  for (const s of order) {
    const st = await switchScene(c, s);
    if (st !== 'OK') { if (s === SCENE_OPT || !SCENE_OPT) console.log('! 场景「' + s + '」不可用: ' + st); continue; }
    const cards = await extractCards(c);
    for (const x of cards) if (x.q.includes(Q) || x.raw.includes(Q)) found.push({ scene: s, card: x });
    if (SCENE_OPT && found.length && s === SCENE_OPT) break;
  }
  if (!found.length) { console.log('按关键词「' + Q + '」没找到任何题。先跑 `node submit.js --list` 核对题面原文。'); process.exit(4); }
  const uniq = [];
  for (const f of found) if (!uniq.find(u => u.card.q === f.card.q && u.scene === f.scene)) uniq.push(f);
  let target = null;
  if (uniq.length === 1) target = uniq[0];
  else {
    const un = uniq.filter(f => !f.card.done);
    if (un.length === 1) target = un[0];
    else if (PICK && uniq[PICK - 1]) target = uniq[PICK - 1];
    else {
      console.log('匹配到多道题/多个场景，请用 --scene 或 --pick N 明确：');
      uniq.forEach((f, i) => console.log('  [' + (i + 1) + '] (' + f.scene + ') ' + (f.card.done ? '[完成] ' : '[未答] ') + f.card.q));
      process.exit(5);
    }
  }
  const { scene, card } = target;
  console.log('定位: (' + scene + ') ' + card.q + '  [' + card.got + '/' + card.total + (card.done ? ' 完成' : ' 未答') + ']');

  // —— 防重复闸①：本地留痕 ——
  const led = ledgerLoad();
  const dup = ledgerFind(led, scene, card.q);
  if (dup) {
    console.log('本地留痕: 该题已提交过 → ' + dup.verdict + ' (' + (dup.t || '') + ')');
    if ((dup.verdict === 'CORRECT' || dup.verdict === 'LOCKED') && !FORCE)
      bail(3, { scene, task: card.q, verdict: dup.verdict, note: '本地留痕已锁定，跳过' });
    if (dup.verdict === 'WRONG' && !RETRY_WRONG && !FORCE) {
      console.log('（此前判错；要重交请加 --retry-wrong）');
    }
  }
  // —— 防重复闸②：页面实时状态 ——
  if (card.done && !FORCE) bail(3, { scene, task: card.q, verdict: 'ALREADY_DONE', note: '页面显示已完成/得分>0，跳过' });

  // —— --dry：只打开题卡核对详情 ——
  if (DRY) {
    const cl = await ev(c, clickCardJS(card.q));
    if (cl !== 'CLICKED') bail(4, { scene, task: card.q, verdict: 'CARD_UNCLICKABLE' });
    await sleep(2500);
    const detail = await ev(c, `(() => { const t = document.body.innerText||''; const i = t.lastIndexOf('任务名称'); return i >= 0 ? t.slice(i, i + 160).replace(/\\s+/g,' ') : 'NO_DETAIL'; })()`);
    console.log('DRY 详情: ' + detail);
    out({ scene, task: card.q, verdict: 'DRY_LOCATED' });
    c.close(); process.exit(0);
  }
  if (!A) { console.log('缺少答案参数（或用 --dry 仅核对）。'); process.exit(9); }

  // —— 打开题卡（详情面板加载竞态：NO_TA 时补点一次）——
  let cl = await ev(c, clickCardJS(card.q));
  if (cl !== 'CLICKED') bail(4, { scene, task: card.q, verdict: 'CARD_UNCLICKABLE' });
  let hasTa = 'NOTA';
  for (let i = 0; i < 10; i++) {
    await sleep(1000);
    hasTa = await ev(c, `(() => { const t = document.querySelector('textarea.model-text') || document.querySelector('textarea'); return t ? 'TA' : 'NOTA'; })()`);
    if (hasTa === 'TA') break;
    if (i === 4) { await ev(c, clickCardJS(card.q)); console.log('（详情未加载，已补点一次题卡）'); }
  }
  if (hasTa !== 'TA') bail(4, { scene, task: card.q, verdict: 'NO_TEXTAREA' });

  // —— 填答案（原生 setter + input/change 事件，兼容 Vue）——
  const filled = await ev(c, `(() => {
    const a = ${JSON.stringify(A)};
    const ta = document.querySelector('textarea.model-text') || document.querySelector('textarea');
    if (!ta) return 'NO_INPUT';
    const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
    setter.call(ta, a);
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    ta.dispatchEvent(new Event('change', { bubbles: true }));
    return ta.value === a ? 'FILLED' : 'FILL_MISMATCH';
  })()`);
  if (filled !== 'FILLED') bail(1, { scene, task: card.q, verdict: 'FILL_FAIL', detail: String(filled) });
  await sleep(400);

  // —— 防重复闸③：按钮禁用检测 ——
  const btnState = await ev(c, `(() => {
    const el = [...document.querySelectorAll('.btn-item-style')].find(b => (b.innerText||'').trim() === '提交');
    if (!el) return 'NO_BTN';
    const dis = /disabled/i.test(el.className) || el.getAttribute('aria-disabled') === 'true';
    return dis ? 'DISABLED' : 'OK';
  })()`);
  if (btnState === 'DISABLED') bail(3, { scene, task: card.q, verdict: 'DUPLICATE_LOCKED', note: '提交按钮禁用（疑似已作答）' });
  if (btnState !== 'OK') bail(4, { scene, task: card.q, verdict: 'NO_SUBMIT_BTN' });

  await ev(c, `(() => { const el = [...document.querySelectorAll('.btn-item-style')].find(b => (b.innerText||'').trim() === '提交'); if (el) el.click(); return 'ok'; })()`);
  await sleep(3500);

  // —— 解析判定并留痕 ——
  const noticed = await ev(c, `(() => {
    const msgs = [...document.querySelectorAll('.ant-message-notice')].map(e => (e.innerText||'').replace(/\\s+/g,' ').trim()).filter(Boolean);
    const t = document.body.innerText || '';
    return JSON.stringify({ msgs, bodyHasAnswered: /已被作答|无法再次|重复提交/.test(t) });
  })()`);
  let verdict = 'UNKNOWN', note = '';
  try {
    const j = JSON.parse(noticed || '{}');
    note = (j.msgs || []).join(' | ');
    if (/恭喜|正确/.test(note)) verdict = 'CORRECT';
    else if (/很遗憾|错误|不正确|失败/.test(note)) verdict = 'WRONG';
    else if (/已被作答|无法再次|重复/.test(note) || j.bodyHasAnswered) verdict = 'LOCKED';
    else if (!note) verdict = 'NO_NOTICE';
  } catch {}
  led.push({ t: new Date().toISOString(), scene, q: card.q, a: A, verdict, note });
  ledgerSave(led);
  console.log('判定: ' + verdict + (note ? ' — ' + note : ''));
  out({ scene, task: card.q, answer: A, verdict, note });
  c.close();
  process.exit(verdict === 'CORRECT' ? 0 : verdict === 'WRONG' ? 2 : (verdict === 'LOCKED' ? 3 : 1));
})().catch(e => { console.error('ERR: ' + e.message); process.exit(9); });
