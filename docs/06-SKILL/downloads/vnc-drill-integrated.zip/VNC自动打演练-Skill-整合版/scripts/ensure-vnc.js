#!/usr/bin/env node
'use strict';
// ensure-vnc.js —— 确保控制台页面存在可用画布；掉线则重新连接/重载
const base = 'http://127.0.0.1:9222';
const pageMatch = process.argv[2] || 'static/topo';
function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let id = 0; const pending = new Map();
    ws.addEventListener('message', ev => {
      let msg; try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id); pending.delete(msg.id);
        msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
      }
    });
    ws.addEventListener('error', () => reject(new Error('ws fail')));
    ws.addEventListener('open', () => resolve({
      send(m, p) { return new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); },
      close() { try { ws.close(); } catch {} }
    }));
  });
}
async function evalExpr(c, expression) {
  const r = await c.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) return null;
  return r.result ? r.result.value : undefined;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  const list = await (await fetch(base + '/json/list')).json();
  let pages = list.filter(t => t.type === 'page' && (t.url || '').includes(pageMatch));
  if (!pages.length) { console.error('no console page'); process.exit(1); }
  let c = await connect(pages[0].webSocketDebuggerUrl);
  let has = await evalExpr(c, 'document.querySelectorAll("canvas").length');
  if (!has) {
    // 尝试点击"重新连接"
    const clicked = await evalExpr(c, `(() => {
      const el = [...document.querySelectorAll('a,button,span,div')].find(e => (e.innerText||'').trim() === '重新连接');
      if (el) { el.click(); return 'CLICKED'; } return 'NO_BTN';
    })()`);
    console.log('reconnect btn: ' + clicked);
    await sleep(6000);
    has = await evalExpr(c, 'document.querySelectorAll("canvas").length');
  }
  if (!has) {
    // 整页重载（带缓存破坏参数）
    const url = pages[0].url.replace(/\?_\=\d+/, '?_=' + Date.now());
    const newUrl = url.includes('?_=') ? url : url.replace('/static/topo/', '/static/topo/?_=' + Date.now());
    await c.send('Page.enable');
    await c.send('Page.navigate', { url: newUrl });
    console.log('reloaded: ' + newUrl.slice(0, 80));
    c.close();
    await sleep(10000);
    pages = (await (await fetch(base + '/json/list')).json()).filter(t => t.type === 'page' && (t.url || '').includes(pageMatch));
    if (!pages.length) { console.error('page gone'); process.exit(1); }
    c = await connect(pages[0].webSocketDebuggerUrl);
    has = await evalExpr(c, 'document.querySelectorAll("canvas").length');
  }
  console.log('canvas=' + has);
  c.close();
  process.exit(has ? 0 : 1);
})();
