(() => {
  const c = document.querySelector('canvas');
  if (!c) return 'NOCANVAS';
  const r = c.getBoundingClientRect();
  return JSON.stringify({ x: r.x, y: r.y, w: r.width, h: r.height, gw: c.width, gh: c.height, dpr: devicePixelRatio, iw: innerWidth, ih: innerHeight });
})()
