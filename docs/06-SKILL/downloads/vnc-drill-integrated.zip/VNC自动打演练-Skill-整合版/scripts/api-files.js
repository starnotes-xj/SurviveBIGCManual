(async () => {
  const token = JSON.parse(localStorage.getItem('userStore') || '{}').userConfig.auth.token;
  const common = { module: 'drill', type_: 'taskdrill', sourceid: '5ab4a224-a0d3-49bf-9f1a-7ced2124007b', planid: '235' };
  const devUuid = '71e5aa98-b927-40f5-8674-152d965918b2'; // WEB-DMZ
  const name = 'YJ-WEB-DMZ';
  // 1) 取 console token
  const cr = await fetch('/domain/domain/console', {
    method: 'POST', credentials: 'include',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', token },
    body: new URLSearchParams(Object.assign({}, common, { domainuuid: devUuid, protocol: 'vnc', uuid: devUuid, deviceName: name, type: 'vnc' })).toString()
  });
  const cinfo = await cr.json();
  const sess = cinfo.data.token;
  // 2) 列目录
  const ls = async (dir) => {
    const r = await fetch('/sessions/' + sess + '/ls?protocol=vnc&dir=' + encodeURIComponent(dir), {
      credentials: 'include', headers: { token }
    });
    return (await r.text()).slice(0, 2500);
  };
  const out = { sess };
  out.root = await ls('/');
  out.var = await ls('/var/log/');
  return JSON.stringify(out, null, 1);
})()
