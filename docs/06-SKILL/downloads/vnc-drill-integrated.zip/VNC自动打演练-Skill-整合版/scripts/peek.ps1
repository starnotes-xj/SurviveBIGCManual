param([Parameter(Mandatory=$true)][string]$Png, [int]$Row = 0, [int]$Col = 0, [int]$Cells = 6)
Add-Type -AssemblyName System.Drawing
$bmp = [System.Drawing.Bitmap]::FromFile($Png)
$w = $bmp.Width; $h = $bmp.Height
Write-Output ("size=" + $w + "x" + $h)
$scale = [int]([math]::Round($w / 1024.0))
Write-Output ("scale=" + $scale)
# 找出有墨迹的行范围
$rowsWithInk = @()
for ($y = 0; $y -lt $h; $y += 4) {
  $ink = 0
  for ($x = 0; $x -lt $w; $x += 4) {
    $c = $bmp.GetPixel($x, $y)
    $l = [int](($c.R + $c.G + $c.B) / 3)
    if ($l -gt 90) { $ink++ }
  }
  if ($ink -gt 0) { $rowsWithInk += ($y.ToString() + ':' + $ink) }
}
Write-Output ("inkRows(first 40): " + (($rowsWithInk | Select-Object -First 40) -join ' '))
Write-Output '--- bitmap first cells of row ---'
for ($ci = 0; $ci -lt $Cells; $ci++) {
  $x0 = ($Col + $ci) * 8 * $scale
  $y0 = $Row * 16 * $scale
  Write-Output ("cell " + ($Col + $ci) + " at x=" + $x0 + " y=" + $y0)
  for ($yy = 0; $yy -lt 16 * $scale; $yy += $scale) {
    $line = ''
    for ($xx = 0; $xx -lt 8 * $scale; $xx += $scale) {
      $c = $bmp.GetPixel($x0 + $xx, $y0 + $yy)
      $l = [int](($c.R + $c.G + $c.B) / 3)
      if ($l -gt 128) { $line += '#' } elseif ($l -gt 40) { $line += '+' } else { $line += '.' }
    }
    Write-Output $line
  }
}
$bmp.Dispose()
