(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const base = 'http://127.0.0.1:9222';
  function connect(wsUrl) {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(wsUrl);
      let id = 0; const pending = new Map();
      ws.addEventListener('message', ev => {
        let msg; try { msg = JSON.parse(ev.data); } catch { return; }
        if (msg.id && pending.has(msg.id)) { const { res, rej } = pending.get(msg.id); pending.delete(msg.id); msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result); }
      });
      ws.addEventListener('error', () => reject(new Error('ws fail')));
      ws.addEventListener('open', () => resolve({
        send(m, p) { return new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); },
        close() { try { ws.close(); } catch {} }
      }));
    });
  }
  const list = await (await fetch(base + '/json/list')).json();
  const page = list.find(t => t.type === 'page' && (t.url || '').includes('dril-web'));
  const c = await connect(page.webSocketDebuggerUrl);
  const mk = (scene) => `(() => { const sc=[...document.querySelectorAll('span,div,li')].filter(e=>e.children.length===0 && (e.innerText||'').trim()===${JSON.stringify(scene)}); if(sc.length) sc[0].click(); return sc.length; })()`;
  for (const scene of ['移动应用服务器应急响应溯源', '企业网应急溯源', 'APT 恶意样本深度分析']) {
    await c.send('Runtime.evaluate', { expression: mk(scene), returnByValue: true });
    await sleep(2500);
    const r = await c.send('Runtime.evaluate', {
      expression: `(() => {
        const cards = [...document.querySelectorAll('*')].filter(e => e.children.length > 0 && /指定任务/.test(e.innerText||'') && (e.innerText||'').length < 200);
        const seen = new Set(); const out = [];
        for (const c of cards) {
          const t = (c.innerText||'').replace(/\\s+/g,' ').trim();
          if (seen.has(t) || t === '指定任务') continue; seen.add(t);
          const m = t.match(/指定任务\\s*(完成)?\\s*(.*?)\\s*(\\d+)分\\s*\\/\\s*(\\d+)分/);
          if (m) out.push({ done: !!m[1], q: m[2], got: Number(m[3]), max: Number(m[4]) });
        }
        return JSON.stringify(out);
      })()`, returnByValue: true
    });
    console.log('##### ' + scene);
    const arr = JSON.parse(r.result.value || '[]');
    arr.forEach((x, i) => console.log((i + 1) + '. [' + (x.done ? '✔ ' + x.got : '  ') + '/' + x.max + '] ' + x.q));
  }
  c.close();
  process.exit(0);
})();
