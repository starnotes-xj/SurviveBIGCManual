#!/usr/bin/env node
'use strict';
// focus.js —— 把匹配页面置前；把其它控制台页面导航到 about:blank（释放会话）
// 用法: node focus.js <keepMatch>
const keep = process.argv[2];
const base = 'http://127.0.0.1:9222';
function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let id = 0; const pending = new Map();
    ws.addEventListener('message', ev => {
      let msg; try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id); pending.delete(msg.id);
        msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
      }
    });
    ws.addEventListener('error', () => reject(new Error('ws fail')));
    ws.addEventListener('open', () => resolve({
      send(m, p) { return new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); },
      close() { try { ws.close(); } catch {} }
    }));
  });
}
(async () => {
  const list = await (await fetch(base + '/json/list')).json();
  const pages = list.filter(t => t.type === 'page' && (t.url || '').includes('static/topo'));
  for (const p of pages) {
    const c = await connect(p.webSocketDebuggerUrl);
    if (p.url.includes(keep)) {
      await c.send('Page.enable');
      await c.send('Page.bringToFront');
      console.log('FRONT: ' + p.url.slice(0, 70));
    } else {
      await c.send('Page.enable');
      await c.send('Page.navigate', { url: 'about:blank' });
      console.log('RELEASED: ' + p.url.slice(0, 70));
    }
    c.close();
  }
  process.exit(0);
})();
