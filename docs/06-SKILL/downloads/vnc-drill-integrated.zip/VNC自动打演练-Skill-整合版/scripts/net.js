// capture requests + response bodies of matching XHRs while reloading a page
// usage: node net.js <urlSubstr> <respBodyRegex> [seconds]
const HOST='127.0.0.1:9222'; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function list(){return (await (await fetch(`http://${HOST}/json/list`)).json())}
async function conn(u){const ws=new WebSocket(u);await new Promise((r,j)=>{ws.onopen=r;ws.onerror=()=>j(new Error('wserr'))});
  let id=0;const p=new Map();const ev=[];
  ws.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch{return}
    if(m.id&&p.has(m.id)){p.get(m.id)(m);p.delete(m.id);return}
    if(m.method)ev.push(m)};
  const send=(method,params={})=>new Promise(r=>{const i=++id;p.set(i,r);ws.send(JSON.stringify({id:i,method,params}))});
  return{ws,send,ev}}
(async()=>{
  const [,,sub,rx,secs]=process.argv;
  const t=(await list()).filter(x=>x.type==='page').find(x=>x.url.includes(sub));
  if(!t){console.log('NO_TARGET');return}
  const c=await conn(t.webSocketDebuggerUrl);
  const re=new RegExp(rx||'.');
  await c.send('Network.enable');await c.send('Page.enable');
  await c.send('Page.reload');
  await sleep((Number(secs)||12)*1000);
  const seen=new Set();
  for(const m of c.ev){
    if(m.method==='Network.requestWillBeSent'){const u=m.params.request.url;if(!/\.(js|css|png|jpg|ico|woff2?|svg)(\?|$)/.test(u))console.log('REQ '+m.params.request.method+' '+u.slice(0,140))}
    if(m.method==='Network.responseReceived'){const u=m.params.response.url;if(re.test(u)&&!seen.has(m.params.requestId)){seen.add(m.params.requestId);
      try{const b=await c.send('Network.getResponseBody',{requestId:m.params.requestId});console.log('\n==== '+u.slice(0,120)+'\n'+((b.result&&b.result.body)||'').slice(0,3000))}catch(e){}}}
  }
  try{c.ws.close()}catch(e){}
  process.exit(0);
})();
