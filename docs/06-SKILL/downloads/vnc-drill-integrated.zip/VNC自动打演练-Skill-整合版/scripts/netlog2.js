#!/usr/bin/env node
'use strict';
// netlog2.js —— 抓取指定 URL 子串的请求（含完整 headers），用于复刻鉴权
// 用法: node netlog2.js <pageMatch> <navUrl|-> <waitMs> <urlSubstr>
const pageMatch = process.argv[2];
const navTo = process.argv[3] !== '-' ? process.argv[3] : null;
const waitMs = Number(process.argv[4] || 12000);
const urlSub = process.argv[5] || '/domain/';
const base = 'http://127.0.0.1:9222';

function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let id = 0; const pending = new Map();
    ws.addEventListener('message', ev => {
      let msg; try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id); pending.delete(msg.id);
        msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
      } else if (msg.method) handlers.forEach(h => h(msg));
    });
    ws.addEventListener('error', () => reject(new Error('ws fail')));
    ws.addEventListener('open', () => resolve({
      send(m, p) { return new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); },
      close() { try { ws.close(); } catch {} }
    }));
  });
}
const handlers = [];
handlers.push(msg => {
  if (msg.method === 'Network.requestWillBeSent' && msg.params.request.url.includes(urlSub)) {
    const r = msg.params.request;
    console.log('=== ' + r.method + ' ' + r.url);
    console.log(JSON.stringify(r.headers, null, 1));
    if (r.postData) console.log('BODY: ' + r.postData);
  }
});
(async () => {
  const list = await (await fetch(base + '/json/list')).json();
  const pages = list.filter(t => t.type === 'page' && (t.url || '').includes(pageMatch));
  if (!pages.length) { console.error('no page ' + pageMatch); process.exit(1); }
  const c = await connect(pages[0].webSocketDebuggerUrl);
  await c.send('Network.enable');
  await c.send('Page.enable');
  if (navTo) await c.send('Page.navigate', { url: navTo });
  await new Promise(r => setTimeout(r, waitMs));
  c.close(); process.exit(0);
})();
