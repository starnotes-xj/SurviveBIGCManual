#!/bin/bash
clear
echo "== EV.TXT =="
ls -la /tmp/ev.txt 2>/dev/null
wc -c /tmp/ev.txt 2>/dev/null
head -25 /tmp/ev.txt 2>/dev/null
