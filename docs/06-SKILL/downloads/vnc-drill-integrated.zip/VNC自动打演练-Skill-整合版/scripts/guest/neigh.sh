#!/bin/bash
clear
echo "### ip neigh ###"
ip neigh show 2>/dev/null | head -20
echo "### arp -an ###"
arp -an 2>/dev/null | head -20
