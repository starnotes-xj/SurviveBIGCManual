#!/bin/bash
clear
echo LS
ls /var/lib/mysql/mysql/ 2>/dev/null | head -20
echo CSVGREP
strings /var/lib/mysql/mysql/general_log.CSV 2>/dev/null | grep -ia 'identified' | head -6
echo CSVSIZE
ls -la /var/lib/mysql/mysql/general_log.CSV 2>/dev/null
echo SLOW
strings /var/lib/mysql/mysql/slow_log.CSV 2>/dev/null | grep -ia 'identified' | head -4
