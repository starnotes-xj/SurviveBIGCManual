﻿#!/bin/bash
clear
curl -s -m 5 http://10.0.10.200:8080/ | head -30
echo ==LIST2==
curl -s -m 5 http://10.0.10.200:8080/ | grep -oaE 'href="[^"]+"' | head -20
