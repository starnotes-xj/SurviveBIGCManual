#!/bin/bash
clear
echo MYD
strings /var/lib/mysql/mysql/user.MYD 2>/dev/null | head -20
echo TABLES
ls /var/lib/mysql/ 2>/dev/null | head -12
