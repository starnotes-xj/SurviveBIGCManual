﻿#!/bin/bash
clear
grep -ainE 'identified|create user|db_backup|mysql' /tmp/stage.sh /tmp/*.sh 2>/dev/null | head -12
echo SEP
ls -la /tmp/*.sh 2>/dev/null | head -6
