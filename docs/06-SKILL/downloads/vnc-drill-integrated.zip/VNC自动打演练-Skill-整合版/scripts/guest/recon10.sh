#!/bin/bash
clear
echo "### LogServlet strings ###"
strings /var/lib/tomcat9/webapps/oa/WEB-INF/classes/LogServlet.class 2>/dev/null | head -25
echo "### jsp files ###"
find /var/lib/tomcat9/webapps/oa -name '*.jsp*' 2>/dev/null | head -10
echo "### catalina today tail ###"
tail -12 /var/log/tomcat9/catalina.2026-10-11.log
echo "### syslog 9-22 tail ###"
grep -a 'Sep 22' /var/log/syslog 2>/dev/null | tail -8
