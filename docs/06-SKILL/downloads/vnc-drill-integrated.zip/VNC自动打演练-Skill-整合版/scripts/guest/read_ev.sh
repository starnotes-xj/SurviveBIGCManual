#!/bin/bash
clear
ls -l /tmp/ev.txt 2>/dev/null
echo "=== head ==="
head -35 /tmp/ev.txt 2>/dev/null
