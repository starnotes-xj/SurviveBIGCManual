#!/bin/bash
clear
echo A_rpmV
rpm -V redis 2>&1 | head -5
echo B_backup
ls -la /etc/redis.conf.rpmsave /etc/redis.conf.rpmnew 2>/dev/null | head -4
echo C_crondirs
ls -la /etc/cron.d/ 2>/dev/null | head -6
ls -la /var/spool/cron/crontabs/ 2>/dev/null | head -4
echo D_journal
journalctl -u redis --no-pager 2>/dev/null | grep -iaE 'config|dir|dbfilename|protected|bind' | tail -6
echo E_rdb
ls -la /var/lib/redis/ /var/spool/cron/ 2>/dev/null | head -8
