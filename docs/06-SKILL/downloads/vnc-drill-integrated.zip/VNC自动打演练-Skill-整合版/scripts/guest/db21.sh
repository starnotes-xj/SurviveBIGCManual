#!/bin/bash
clear
echo "=1 attacker scripts="
ls -l /tmp/db_stage.sh /root/db_stage.sh /tmp/*.sql /tmp/*.sh 2>/dev/null
echo "--- db_stage.sh ---"
cat /tmp/db_stage.sh 2>/dev/null | head -25
echo "=2 my.cnf="
cat /root/.my.cnf 2>/dev/null
grep -nE 'password' /etc/my.cnf /etc/my.cnf.d/*.cnf 2>/dev/null | head -6
echo "=3 mail root="
head -20 /var/spool/mail/root 2>/dev/null
