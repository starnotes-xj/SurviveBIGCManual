#!/bin/bash
clear
echo "== RECV STATUS =="
ls -la /tmp/ev.txt /tmp/recv.ready 2>/dev/null
echo "== CONTENT (head 30) =="
head -30 /tmp/ev.txt 2>/dev/null
echo "== TAIL =="
tail -6 /tmp/recv.log 2>/dev/null
