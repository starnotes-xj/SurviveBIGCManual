#!/bin/bash
clear
echo C2ROOT
curl -s -m 6 http://10.0.10.200:8080/ | head -20
echo C2STAGE
curl -s -m 6 http://10.0.10.200:8080/db_stage.sh | head -40
echo C2STAGE2
curl -s -m 6 http://10.0.10.200:8080/stage.sh | grep -iaE 'identified|create user|mysql|password' | head -10
