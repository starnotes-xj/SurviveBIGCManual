import socket, os
# 接收 Windows 靶机推送的文本，落盘 /tmp/ev.txt
s = socket.socket()
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(('0.0.0.0', 9999))
s.listen(4)
open('/tmp/recv.ready', 'w').write('ready')
while True:
    c, a = s.accept()
    data = b''
    c.settimeout(15)
    try:
        while True:
            b = c.recv(65536)
            if not b:
                break
            data += b
    except Exception:
        pass
    c.close()
    with open('/tmp/ev.txt', 'ab') as f:
        f.write(b'=== from ' + str(a).encode() + b' ===\n')
        f.write(data)
        f.write(b'\n')
