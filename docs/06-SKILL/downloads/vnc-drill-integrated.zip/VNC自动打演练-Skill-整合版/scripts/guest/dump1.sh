#!/bin/bash
clear
sed -n '1,22p' /tmp/db_dump.sql
