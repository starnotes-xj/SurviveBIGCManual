#!/bin/bash
clear
echo "== A: redis log =="
grep -aE 'CONFIG SET|DB saved|Background saving|dir|dbfilename' /var/log/redis/redis.log 2>/dev/null | tail -14
echo "== B: /tmp =="
ls -la /tmp 2>/dev/null | head -14
echo "== C: rex1 =="
cat /tmp/rex1.txt 2>/dev/null
echo "== D: mysql users =="
mysql -uroot -p'Root@Lab#Db' -e "select user,host from mysql.user" 2>&1 | head -10
