#!/bin/bash
clear
echo "### /tmp/stage.sh ###"
cat /tmp/stage.sh 2>/dev/null | head -30
echo "### ls /tmp (dot files) ###"
ls -la /tmp/.tools /tmp/.scan.log /tmp/.scan_full.log 2>/dev/null | head -20
echo "### .scan.log head ###"
head -12 /tmp/.scan.log 2>/dev/null
echo "### LogServlet refs in tomcat logs ###"
for f in /var/log/tomcat9/*; do zcat -f "$f" 2>/dev/null; done | grep -a 'LogServlet' | head -6
echo "### oa classes ###"
ls -la /var/lib/tomcat9/webapps/oa/WEB-INF/classes/ 2>/dev/null
