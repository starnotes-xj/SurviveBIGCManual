﻿#!/bin/bash
clear
echo LASTLOG
lastlog 2>/dev/null | head -8
echo DBADMIN_LAST
lastlog -u dbadmin 2>/dev/null
