#!/bin/bash
pkill -f 'python3 /tmp/recv.py' 2>/dev/null
rm -f /tmp/ev.txt /tmp/recv.ready
cat > /tmp/recv.py <<'PYEOF'
import socket
s = socket.socket()
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(('0.0.0.0', 9999))
s.listen(4)
open('/tmp/recv.ready', 'w').write('ready')
while True:
    c, a = s.accept()
    data = b''
    c.settimeout(20)
    try:
        while True:
            b = c.recv(65536)
            if not b:
                break
            data += b
    except Exception:
        pass
    c.close()
    with open('/tmp/ev.txt', 'ab') as f:
        f.write(b'=== from ' + str(a).encode() + b' ===\n')
        f.write(data)
        f.write(b'\n')
PYEOF
nohup python3 /tmp/recv.py > /tmp/recv.log 2>&1 &
sleep 1
ls -la /tmp/recv.ready /tmp/recv.py
ss -lntp 2>/dev/null | grep 9999
