#!/bin/bash
clear
echo "=HEX="
grep -o "IDENTIFIED BY '[^']*'" /tmp/db_dump.sql 2>/dev/null | head -1 | od -An -tx1
echo "=TXT="
grep -o "IDENTIFIED BY '[^']*'" /tmp/db_dump.sql 2>/dev/null | head -1
