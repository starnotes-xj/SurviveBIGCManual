#!/bin/bash
clear
echo SECURE_ACCEPT
grep -ah 'Accepted' /var/log/secure* 2>/dev/null | head -12
echo LAST
last -ai 2>/dev/null | head -8
echo W
who 2>/dev/null | head -5
