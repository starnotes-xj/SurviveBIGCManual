#!/bin/bash
clear
sed -n '55,90p' /etc/redis.conf
