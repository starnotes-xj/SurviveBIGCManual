﻿#!/bin/bash
clear
curl -s -m 6 http://10.0.10.200:8080/db_stage.sh | sed -n '30,52p'
echo END
