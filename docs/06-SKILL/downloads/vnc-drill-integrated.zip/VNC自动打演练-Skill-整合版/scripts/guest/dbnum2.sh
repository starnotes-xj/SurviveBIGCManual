#!/bin/bash
clear
grep -i -o "identified by '[^']*'" /tmp/db_dump.sql 2>/dev/null | head -2 | od -An -tu1
