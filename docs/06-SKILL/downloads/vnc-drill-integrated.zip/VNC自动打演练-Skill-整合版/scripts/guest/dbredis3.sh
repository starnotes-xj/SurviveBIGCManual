#!/bin/bash
clear
which redis-cli
redis-cli config get save 2>&1
redis-cli config get dir 2>&1
redis-cli config get dbfilename 2>&1
redis-cli config get protected-mode 2>&1
redis-cli config get bind 2>&1
redis-cli config get requirepass 2>&1
redis-cli config get appendonly 2>&1
