#!/bin/bash
clear
echo "=1 redis conf="
grep -nE '^(bind|protected-mode|requirepass|rename-command|save|dir|dbfilename|appendonly|maxmemory)' /etc/redis.conf 2>/dev/null
echo "=2 cron files="
ls -la /var/spool/cron/ 2>/dev/null
cat /var/spool/cron/root 2>/dev/null
echo "=3 mysql users="
mysql -uroot -e "select user,host,password from mysql.user" 2>&1 | head -14
