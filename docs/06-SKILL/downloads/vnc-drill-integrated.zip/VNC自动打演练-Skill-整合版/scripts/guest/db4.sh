#!/bin/bash
clear
echo "== A: mysql 用户(免密) =="
mysql -uroot -e "select user,host from mysql.user" 2>&1 | head -12
echo "== B: redis 日志 =="
ls -la /var/log/redis/ 2>/dev/null
echo "== C: mail =="
head -20 /var/spool/mail/root 2>/dev/null
echo "== D: dump 头部 =="
head -6 /tmp/db_dump.sql 2>/dev/null
echo "== E: tar 内容 =="
tar tzf /tmp/db_export_20260922.tar.gz 2>/dev/null | head -8
