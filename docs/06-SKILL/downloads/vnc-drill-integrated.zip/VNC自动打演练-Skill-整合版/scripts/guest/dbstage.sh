#!/bin/bash
clear
echo "=== db_stage.sh ==="
cat /tmp/db_stage.sh
