#!/bin/bash
clear
echo "ROWSCOLS: $(stty size)"
echo "FB: $(cat /sys/class/graphics/fb0/virtual_size 2>/dev/null)"
awk 'BEGIN{for(i=32;i<72;i++)printf "%c",i; printf "\n"; for(i=72;i<127;i++)printf "%c",i; printf "\n"}'
echo "REF2-DONE"
