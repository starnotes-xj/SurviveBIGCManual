#!/bin/bash
clear
echo A_BANNER
/tmp/.tools/fscan 2>&1 | head -14
echo B_STRINGS
strings /tmp/.tools/fscan 2>/dev/null | grep -oE 'fscan[^ ]*[0-9]+\.[0-9]+(\.[0-9]+)?' | head -4
strings /tmp/.tools/fscan 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | sort | uniq -c | sort -rn | head -5
