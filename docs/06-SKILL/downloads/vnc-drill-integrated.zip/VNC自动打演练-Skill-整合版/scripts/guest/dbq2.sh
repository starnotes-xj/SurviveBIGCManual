#!/bin/bash
clear
echo "=A redis live config="
redis-cli CONFIG GET dir 2>&1 | head -4
redis-cli CONFIG GET dbfilename 2>&1 | head -4
redis-cli CONFIG GET protected-mode 2>&1 | head -4
redis-cli CONFIG GET bind 2>&1 | head -6
echo "=B redis.conf auth/rename="
grep -nE 'requirepass|rename-command' /etc/redis.conf 2>/dev/null | head -8
ls -la /etc/redis.conf* 2>/dev/null
echo "=C mysql creds="
ls -la /root/.my.cnf 2>/dev/null
cat /root/.my.cnf 2>/dev/null
