#!/bin/bash
clear
echo GENFILES
ls -la /var/lib/mysql/mysql/ 2>/dev/null | grep -iE 'general|slow' | head -5
echo GENSTR
strings /var/lib/mysql/mysql/general_log.* 2>/dev/null | grep -iaE 'identified|create user|grant' | head -8
echo ALLGREP
grep -ra "IDENTIFIED BY" /var/lib/mysql/ 2>/dev/null | head -4
echo HISTORY
cat /root/.bash_history 2>/dev/null
