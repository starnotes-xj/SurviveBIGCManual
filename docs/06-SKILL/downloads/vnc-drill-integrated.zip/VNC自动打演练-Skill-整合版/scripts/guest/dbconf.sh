#!/bin/bash
clear
grep -vE '^#|^$' /etc/redis.conf
