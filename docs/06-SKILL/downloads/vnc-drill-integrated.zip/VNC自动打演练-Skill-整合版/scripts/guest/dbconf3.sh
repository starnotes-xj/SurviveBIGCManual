#!/bin/bash
clear
echo A_requirepass_count
grep -c requirepass /etc/redis.conf
echo B_rename_count
grep -c rename-command /etc/redis.conf
echo C_daemonize_count
grep -c daemonize /etc/redis.conf
echo D_size
wc -c /etc/redis.conf
echo E_stopwrites
grep -n 'stop-writes-on-bgsave-error' /etc/redis.conf
