#!/bin/bash
clear
echo "== A: 关键文件时间 =="
stat -c '%y %s %n' /opt/ops/check_disk.sh /tmp/stage.sh /tmp/.tools/fscan /usr/share/.health.py /usr/local/bin/.sysupdate 2>/dev/null | cut -c1-19,21-60
echo "== B: ssh 公钥登录次数 =="
for f in /var/log/auth.log*; do zcat -f "$f" 2>/dev/null; done | grep -c 'Accepted publickey'
echo "== C: 持久化项 =="
ls /etc/cron.d/ 2>/dev/null | head -5
crontab -l 2>/dev/null | head -5
ls /etc/systemd/system/ 2>/dev/null | head -8
echo "== D: fscan 版本 =="
strings /tmp/.tools/fscan 2>/dev/null | grep -iE '^fscan|fscan v|version' | head -4
echo "== E: 引用 C2 的文件 =="
grep -rIl '10.0.10.200' /opt /tmp /root /usr/share /etc 2>/dev/null | head -6
