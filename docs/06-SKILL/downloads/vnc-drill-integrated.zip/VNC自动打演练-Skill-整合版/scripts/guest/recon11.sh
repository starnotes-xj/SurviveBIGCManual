#!/bin/bash
clear
echo "### pcap copies ###"
find / -xdev \( -name '*.pcap' -o -name '*.pcapng' -o -name '*.cap' \) 2>/dev/null | head -10
echo "### cron ###"
ls -la /etc/cron.d/ 2>/dev/null | head -12
cat /etc/crontab 2>/dev/null | tail -6
echo "### systemd units new ###"
ls -la /etc/systemd/system/ 2>/dev/null | head -16
echo "### bash_history tomcat ###"
for f in /home/tomcat/.bash_history /var/lib/tomcat9/.bash_history /root/.bash_history; do echo "-- $f"; cat "$f" 2>/dev/null | tail -12; done
