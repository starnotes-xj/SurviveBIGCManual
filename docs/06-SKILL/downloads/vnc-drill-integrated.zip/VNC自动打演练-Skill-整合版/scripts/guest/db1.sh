#!/bin/bash
clear
echo "== A: os =="
cat /etc/redhat-release 2>/dev/null
echo "== B: listen =="
ss -lntp 2>/dev/null | awk 'NR>1{print $4}' | head -8
echo "== C: redis conf =="
ls -la /etc/redis.conf /etc/redis/ 2>/dev/null | head -4
grep -nE 'save |appendonly|rename-command|requirepass|port |bind |dir |dbfilename' /etc/redis.conf 2>/dev/null | head -12
echo "== D: cron =="
crontab -l 2>/dev/null | head -6
ls -la /var/spool/cron/ 2>/dev/null | head -6
echo "== E: tmp/root files =="
ls -la /tmp /root 2>/dev/null | head -20
