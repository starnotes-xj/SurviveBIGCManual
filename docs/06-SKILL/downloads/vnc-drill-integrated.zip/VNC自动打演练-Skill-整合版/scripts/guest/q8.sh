#!/bin/bash
clear
echo "== Q8 dropped scripts (mtime) =="
ls -l --time-style=+%m-%d_%H:%M /tmp/stage.sh /opt/ops/check_disk.sh /usr/share/.health.py 2>/dev/null | awk '{print $6, $7}'
find / -xdev -newermt '2026-09-22 19:00' ! -newermt '2026-09-23 00:00' -type f \( -name '*.sh' -o -name '*.py' -o -name '*.elf' \) 2>/dev/null | head -8
echo "== Q9 ssh key login count =="
for f in /var/log/auth.log /var/log/auth.log.1 /var/log/auth.log.2.gz; do zcat -f "$f" 2>/dev/null; done | grep -c 'Accepted publickey'
for f in /var/log/auth.log /var/log/auth.log.1 /var/log/auth.log.2.gz; do zcat -f "$f" 2>/dev/null; done | grep 'Accepted publickey' | awk '{print $11}' | sort | uniq -c
echo "== Q12 autostart =="
systemctl list-unit-files --state=enabled --no-pager 2>/dev/null | grep -viE 'ssh|getty|cron|network|rsyslog|dbus|apport|unattended|snap|multi-user|remote-fs|systemd-|lvm|vmware|blk|e2scrub|fstrim|motd|grub|keyboard|console|plymouth|resolv|setvtrgb|ua-|time' | head -10
ls -la /etc/systemd/system/*.service 2>/dev/null | head -8
echo "== Q15 fscan version =="
/tmp/.tools/fscan -v 2>&1 | head -2
strings /tmp/.tools/fscan 2>/dev/null | grep -iE 'fscan' | head -4
