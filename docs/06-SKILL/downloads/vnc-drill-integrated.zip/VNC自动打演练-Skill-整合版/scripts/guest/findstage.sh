#!/bin/bash
clear
echo "=find db_stage="
find / -xdev -name 'db_stage*' 2>/dev/null
echo "=tmp list="
ls -l /tmp 2>/dev/null
echo "=root list="
ls -l /root 2>/dev/null | head -20
