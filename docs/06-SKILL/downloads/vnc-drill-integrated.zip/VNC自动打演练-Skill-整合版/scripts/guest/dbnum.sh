#!/bin/bash
clear
P=$(grep -o "IDENTIFIED BY '[^']*'" /tmp/db_dump.sql 2>/dev/null | head -1)
echo "$P" | tr -d "'" | tr -d ' ' | od -An -tu1
