#!/bin/bash
clear
echo "---HIST-START---"
cat /root/.mysql_history 2>/dev/null
echo "---HIST-END---"
grep -ra "IDENTIFIED BY" /var/lib/mysql/*.log /var/log/mariadb/ 2>/dev/null | head -5
echo "---CNF---"
cat /root/.my.cnf 2>/dev/null
