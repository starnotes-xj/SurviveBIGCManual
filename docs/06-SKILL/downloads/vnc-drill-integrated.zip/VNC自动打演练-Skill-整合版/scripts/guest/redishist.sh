#!/bin/bash
clear
echo A_files
ls -la /root/.rediscli_history /root/.redis_history /home/*/.rediscli_history 2>/dev/null
echo B_hist
cat /root/.rediscli_history 2>/dev/null | head -25
echo C_hist2
cat /root/.redis_history 2>/dev/null | head -10
