#!/bin/bash
clear
echo "### tomcat log files ###"
ls -la /var/log/tomcat9/
echo "### access logs content ###"
for f in /var/log/tomcat9/*access*; do echo "-- $f"; zcat -f "$f" 2>/dev/null | head -6; done
echo "### localhost logs head ###"
for f in /var/log/tomcat9/localhost.2026-*; do echo "-- $f"; zcat -f "$f" 2>/dev/null | head -4; done
