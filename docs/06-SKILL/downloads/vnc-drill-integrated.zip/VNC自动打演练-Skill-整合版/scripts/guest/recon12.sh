#!/bin/bash
clear
echo "### stage.sh head ###"
head -14 /tmp/stage.sh
echo "### refs to 10.0.10.x ###"
grep -rhoE '10[.]0[.]10[.][0-9]+' /tmp /opt /root /usr/share /usr/local/bin /etc /var/spool /var/log 2>/dev/null | sort | uniq -c | sort -rn | head -12
echo "### files with attacker refs ###"
grep -rlE '10[.]0[.]10[.]100|10[.]0[.]10[.]200' /tmp /opt /root /usr/share /usr/local/bin /etc 2>/dev/null | head -10
