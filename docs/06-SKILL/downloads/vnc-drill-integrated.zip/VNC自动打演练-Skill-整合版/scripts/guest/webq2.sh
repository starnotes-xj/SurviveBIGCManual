#!/bin/bash
clear
echo COUNT_PUBKEY
for f in /var/log/auth.log*; do zcat -f "$f" 2>/dev/null; done | grep -c 'Accepted publickey'
echo FSCAN_BANNER
/tmp/.tools/fscan 2>&1 | head -6
