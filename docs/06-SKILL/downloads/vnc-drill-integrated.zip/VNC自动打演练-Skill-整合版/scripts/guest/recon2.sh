#!/bin/bash
clear
echo "### listen ports ###"
ss -lntp 2>/dev/null | head -20
echo "### procs ###"
ps aux | grep -iE 'java|nginx|httpd|apache|redis|mysql' | grep -v grep | head -8
echo "### /opt/ops ###"
ls -la /opt/ops 2>/dev/null
echo "### /root ###"
ls -la /root 2>/dev/null | head -20
echo "### auth.log Sep22 ###"
grep -a 'Sep 22' /var/log/auth.log 2>/dev/null | head -15
