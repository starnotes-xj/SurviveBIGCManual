#!/bin/bash
clear
echo USERS
awk -F: '$3>=1000 || $3==0 {print $1" " $3" "$7}' /etc/passwd
echo NEWFILES
ls -la /etc/passwd /etc/shadow /home 2>/dev/null
echo MYSQLUSER
mysql -uroot -e "select user,host from mysql.user" 2>&1 | head -8
