#!/bin/bash
clear
echo "== Q8: 文件时间 =="
ls -l --time-style=+%m-%d_%H:%M /tmp/stage.sh /opt/ops/check_disk.sh /usr/share/.health.py /usr/local/bin/.sysupdate 2>/dev/null
echo "== Q9: 公钥登录次数 =="
for f in /var/log/auth.log*; do zcat -f "$f" 2>/dev/null; done | grep -c 'Accepted publickey'
echo "== Q9b: 来源统计 =="
for f in /var/log/auth.log*; do zcat -f "$f" 2>/dev/null; done | grep 'Accepted publickey' | awk '{print $11}' | sort | uniq -c
echo "== Q12: 自启动项 =="
systemctl cat nss-health.service 2>/dev/null | head -10
echo "== Q15: fscan 版本 =="
/tmp/.tools/fscan -v 2>&1 | head -3
strings /tmp/.tools/fscan 2>/dev/null | grep -iE 'fscan v|fscan-' | head -3
