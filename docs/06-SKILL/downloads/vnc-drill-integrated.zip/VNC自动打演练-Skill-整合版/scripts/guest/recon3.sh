#!/bin/bash
clear
echo "### check_disk.sh ###"
cat /opt/ops/check_disk.sh
echo "### /root/.ssh ###"
ls -la /root/.ssh
for f in /root/.ssh/*; do echo "-- $f"; head -c 300 "$f"; echo; done
echo "### bash_history tail ###"
tail -25 /root/.bash_history 2>/dev/null
echo "### Sep logs ###"
find / -xdev -name "*.log" -newermt 2026-09-21 ! -newermt 2026-09-30 2>/dev/null | head -20
