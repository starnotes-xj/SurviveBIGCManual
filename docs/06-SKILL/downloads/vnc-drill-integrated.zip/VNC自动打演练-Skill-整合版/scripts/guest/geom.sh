#!/bin/bash
clear
echo "FB"
cat /sys/class/graphics/fb0/virtual_size 2>/dev/null
echo "ROWS"
stty size 2>/dev/null | cut -d' ' -f1
echo "COLS"
stty size 2>/dev/null | cut -d' ' -f2
echo "MODES"
cat /sys/class/graphics/fb0/modes 2>/dev/null
