#!/bin/bash
clear
echo STEP1
ls -la /etc/cron.d/
echo STEP2
cat /etc/cron.d/redis_sync 2>/dev/null
echo STEP3
ls -la /etc/cron.d/redis_sync 2>/dev/null
