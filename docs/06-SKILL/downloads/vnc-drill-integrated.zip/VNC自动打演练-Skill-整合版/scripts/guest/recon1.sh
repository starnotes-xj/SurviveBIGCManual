#!/bin/bash
clear
echo "### A: tomcat log IPs (top) ###"
cd /var/log/tomcat9
for f in *; do zcat -f "$f" 2>/dev/null; done | grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}' | sort | uniq -c | sort -rn | head -12
echo "### B: webapps ###"
ls -la /var/lib/tomcat9/webapps/ 2>/dev/null
echo "### C: opt ###"
ls -la /opt 2>/dev/null
