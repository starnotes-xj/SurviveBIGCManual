﻿#!/bin/bash
clear
ip route | head -4
curl -s -m 6 http://10.0.10.200:8080/db_stage.sh | head -30
echo END
