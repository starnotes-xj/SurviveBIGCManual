#!/bin/bash
clear
echo "### log4j2.xml ###"
cat /var/lib/tomcat9/webapps/oa/WEB-INF/classes/log4j2.xml
echo "### db.properties ###"
cat /var/lib/tomcat9/webapps/oa/WEB-INF/classes/db.properties
echo "### .health.py ###"
cat /usr/share/.health.py 2>/dev/null | head -25
echo "### scan.log tail ###"
tail -12 /tmp/.scan.log 2>/dev/null
