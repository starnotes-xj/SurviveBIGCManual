#!/bin/bash
clear
echo "### catalina 09-23 ###"
zcat -f /var/log/tomcat9/catalina.2026-09-23.log.gz 2>/dev/null
echo "### catalina 09-24 ###"
zcat -f /var/log/tomcat9/catalina.2026-09-24.log.gz 2>/dev/null | head -14
echo "### catalina 09-27 ###"
zcat -f /var/log/tomcat9/catalina.2026-09-27.log.gz 2>/dev/null | head -8
