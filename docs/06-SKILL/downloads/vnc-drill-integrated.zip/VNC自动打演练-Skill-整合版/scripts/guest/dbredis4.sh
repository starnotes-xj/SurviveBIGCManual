#!/bin/bash
clear
for k in protected-mode bind requirepass save appendonly stop-writes-on-bgsave-error maxmemory maxmemory-policy timeout tcp-keepalive daemonize supervised notify-keyspace-events; do
  printf '%-32s = ' "$k"
  redis-cli config get "$k" 2>/dev/null | tail -1
done
