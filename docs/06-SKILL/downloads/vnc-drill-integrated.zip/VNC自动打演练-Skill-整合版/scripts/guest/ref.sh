#!/bin/bash
# 参考样本：打印 ASCII 32..126 一行，用于建立字形模板
clear
awk 'BEGIN{for(i=32;i<127;i++){printf "%c",i}; printf "\n"}'
echo "REF-DONE-0123456789"
