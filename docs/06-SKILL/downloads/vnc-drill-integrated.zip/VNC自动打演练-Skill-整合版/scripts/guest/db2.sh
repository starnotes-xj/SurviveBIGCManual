#!/bin/bash
clear
echo "== A: bash_history =="
cat /root/.bash_history 2>/dev/null
echo "== B: bashrc tail =="
tail -10 /root/.bashrc 2>/dev/null
echo "== C: redis 关键项 =="
grep -nE 'protected-mode|^save|appendonly|^dbfilename|^dir|^rename-command' /etc/redis.conf 2>/dev/null
echo "== D: cron 文件 =="
ls -la /var/spool/cron/ 2>/dev/null
cat /var/spool/cron/root 2>/dev/null
echo "== E: .ssh =="
ls -la /root/.ssh 2>/dev/null
