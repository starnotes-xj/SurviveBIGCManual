#!/bin/bash
# 参考样本：常规 + 粗体 两份，用于建立字形模板（兼容 CentOS 粗体字形）
clear
awk 'BEGIN{for(i=32;i<127;i++){printf "%c",i}; printf "\n"}'
printf '\033[1m'
awk 'BEGIN{for(i=32;i<127;i++){printf "%c",i}; printf "\n"}'
printf '\033[0m'
echo "REF-DONE-0123456789"
