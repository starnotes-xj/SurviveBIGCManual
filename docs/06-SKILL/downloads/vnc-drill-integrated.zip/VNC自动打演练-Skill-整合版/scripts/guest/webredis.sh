#!/bin/bash
clear
echo WEBREDIS
ls -la /etc/redis/ /var/log/redis/ 2>/dev/null | head -12
grep -nE '^(protected-mode|bind|save|appendonly|requirepass|rename-command|maxmemory|daemonize)' /etc/redis/redis.conf /etc/redis.conf 2>/dev/null | head -12
echo RPMLIST
rpm -qa 2>/dev/null | grep -i redis | head -3
