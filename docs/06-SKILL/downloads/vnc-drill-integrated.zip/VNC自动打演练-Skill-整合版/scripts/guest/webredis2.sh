#!/bin/bash
clear
echo A_conf
ls -la /etc/redis* 2>/dev/null | head -8
echo B_pkg
dpkg -l 2>/dev/null | grep -i redis | head -3
echo C_run
redis-cli config get save 2>&1 | tail -1
echo D_svc
systemctl is-active redis-server 2>&1
echo E_proc
ps aux | grep -i redis | grep -v grep | head -3
