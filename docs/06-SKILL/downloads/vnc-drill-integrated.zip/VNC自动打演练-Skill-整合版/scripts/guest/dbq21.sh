#!/bin/bash
clear
echo "== A: mysql 客户端历史 =="
cat /root/.mysql_history 2>/dev/null | head -20
echo "== B: user 表 =="
mysql -uroot -e "select user,host,password from mysql.user" 2>&1 | head -12
echo "== C: binlog 里的建号语句 =="
ls /var/lib/mysql/mysql-bin* 2>/dev/null | head -4
grep -ra "IDENTIFIED BY" /var/lib/mysql/mysql-bin* 2>/dev/null | head -5
echo "== D: 配置文件 =="
ls -la /root/.my.cnf /etc/my.cnf 2>/dev/null
