#!/bin/bash
clear
echo A_tomcat_hist
cat /home/tomcat/.bash_history 2>/dev/null | tail -20
echo B_tomcat_redis
cat /home/tomcat/.rediscli_history 2>/dev/null | head -20
echo C_root_bash
cat /root/.bash_history 2>/dev/null | tail -10
echo D_find
find / -xdev -name '.rediscli_history' -o -xdev -name '*redis*history*' 2>/dev/null | head -5
