#!/bin/bash
clear
echo "### auth.log files ###"
ls -la /var/log/auth.log*
echo "### auth.log head/tail ###"
head -2 /var/log/auth.log 2>/dev/null
tail -3 /var/log/auth.log 2>/dev/null
echo "### Accepted ###"
for f in /var/log/auth.log*; do zcat -f "$f" 2>/dev/null; done | grep -a 'Accepted' | head -15
echo "### last ###"
last -a -n 12 2>/dev/null
echo "### jndi/ldap in logs ###"
grep -rail 'jndi' /var/log 2>/dev/null | head -10
