#!/bin/bash
clear
echo "=pwd clause="
grep -o "IDENTIFIED BY '[^']*'" /tmp/db_dump.sql 2>/dev/null | sort -u | head -5
echo "=create user="
grep -o "CREATE USER [^;]*" /tmp/db_dump.sql 2>/dev/null | head -5
