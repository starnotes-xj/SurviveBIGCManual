#!/bin/bash
clear
echo "### tools ###"
for t in smbclient python3 tcpdump tshark nc ncat wget curl; do printf "%s=" "$t"; command -v $t >/dev/null 2>&1 && command -v $t || echo NO; done
echo "### smb list EVIDENCE ###"
smbclient -L //10.0.20.50 -U Administrator%Admin123 2>&1 | head -14
