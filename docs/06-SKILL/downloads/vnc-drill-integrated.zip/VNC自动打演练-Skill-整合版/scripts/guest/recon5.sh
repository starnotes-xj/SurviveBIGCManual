#!/bin/bash
clear
echo "### jndi/ldap in tomcat logs ###"
for f in /var/log/tomcat9/*; do zcat -f "$f" 2>/dev/null; done | grep -iaE 'jndi|ldap|lookup' | head -10
echo "### files modified 09-22..09-24 ###"
find /var/log /var/lib/tomcat9 /opt /root /tmp /usr/local/bin /etc -newermt 2026-09-22 ! -newermt 2026-09-24 2>/dev/null | head -30
echo "### auth.log.2 head ###"
zcat -f /var/log/auth.log.2.gz 2>/dev/null | head -18
