#!/bin/bash
clear
sed -n '23,50p' /tmp/db_dump.sql
