#!/bin/bash
clear
echo "=files with db_backup="
grep -rl 'db_backup' /tmp /root /usr/share /etc /var/tmp /home /opt /usr/local 2>/dev/null | head -10
echo "=hit lines="
grep -rh 'IDENTIFIED BY' /tmp /root /usr/share /etc /var/tmp /home /opt /usr/local 2>/dev/null | head -5
