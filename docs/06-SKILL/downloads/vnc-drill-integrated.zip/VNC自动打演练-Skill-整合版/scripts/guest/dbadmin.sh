#!/bin/bash
clear
echo DBADMIN_LOGS
grep -ah 'dbadmin' /var/log/secure* 2>/dev/null | head -10
echo ACCEPT_BY_USER
grep -ah 'Accepted' /var/log/secure* 2>/dev/null | awk '{print $9}' | sort | uniq -c
echo SUDO
grep -ah 'dbadmin' /var/log/secure* 2>/dev/null | grep -c 'session opened'
