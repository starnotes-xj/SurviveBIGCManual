#!/usr/bin/env node
'use strict';
// shot2.js —— 正确的参数解析版截图
// 用法: node shot2.js <pageMatch> <outPng> [--selector "#id"] [--clip x,y,w,h] [--scale 2] [--wait 800] [--full 1]
const argv = process.argv.slice(2);
const fs = require('fs');
const flags = {};
const pos = [];
for (let i = 0; i < argv.length; i++) {
  if (argv[i].startsWith('--')) { flags[argv[i].slice(2)] = argv[i + 1]; i++; }
  else pos.push(argv[i]);
}
const pageMatch = pos[0];
const outPath = pos[1];
const base = 'http://127.0.0.1:9222';

function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let id = 0; const pending = new Map();
    ws.addEventListener('message', ev => {
      let msg; try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id); pending.delete(msg.id);
        msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
      }
    });
    ws.addEventListener('error', () => reject(new Error('ws fail')));
    ws.addEventListener('open', () => resolve({
      send(m, p) { return new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); },
      close() { try { ws.close(); } catch {} }
    }));
  });
}
async function evalExpr(c, expression) {
  const r = await c.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) throw new Error('eval error: ' + JSON.stringify(r.exceptionDetails).slice(0, 300));
  return r.result ? r.result.value : undefined;
}
(async () => {
  const list = await (await fetch(base + '/json/list')).json();
  const pages = list.filter(t => t.type === 'page' && (t.url || '').includes(pageMatch));
  if (!pages.length) { console.error('no page matching ' + pageMatch); process.exit(1); }
  const t = pages[0];
  const c = await connect(t.webSocketDebuggerUrl);
  await c.send('Page.enable');
  if (flags.wait) await new Promise(r => setTimeout(r, Number(flags.wait)));
  const scale = Number(flags.scale || 1);
  let clip = null;
  if (flags.selector) {
    const r = await evalExpr(c, `(() => { const el=document.querySelector(${JSON.stringify(flags.selector)}); if(!el) return null; const b=el.getBoundingClientRect(); return {x:b.x,y:b.y,width:b.width,height:b.height}; })()`);
    if (!r || !r.width) throw new Error('selector not found: ' + flags.selector);
    clip = { x: Math.max(0, Math.floor(r.x)), y: Math.max(0, Math.floor(r.y)), width: Math.ceil(r.width), height: Math.ceil(r.height), scale };
  } else if (flags.clip) {
    const [x, y, w, h] = flags.clip.split(',').map(Number);
    clip = { x, y, width: w, height: h, scale };
  }
  const params = { format: 'png' };
  if (clip) params.clip = clip;
  if (flags.full) params.captureBeyondViewport = true;
  const res = await c.send('Page.captureScreenshot', params);
  fs.writeFileSync(outPath, Buffer.from(res.data, 'base64'));
  console.log('SHOT ' + outPath + ' target=' + t.url.slice(0, 90) + (clip ? ' clip=' + JSON.stringify(clip) : ' viewport'));
  c.close(); process.exit(0);
})();
