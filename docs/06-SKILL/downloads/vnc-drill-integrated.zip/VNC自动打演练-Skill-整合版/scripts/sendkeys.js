#!/usr/bin/env node
'use strict';
// sendkeys.js —— 向 noVNC 画布注入真实键盘事件
// 用法: node sendkeys.js <pageMatch> "<文本>" [--delay 30] [--clickon 1]
// 支持 \n(Enter) \t(Tab) \b(Backspace) \e(Escape) 以及 US 布局可打印字符
const argv = process.argv.slice(2);
const flags = {};
const pos = [];
for (let i = 0; i < argv.length; i++) {
  if (argv[i].startsWith('--')) { flags[argv[i].slice(2)] = argv[i + 1]; i++; }
  else pos.push(argv[i]);
}
const pageMatch = pos[0];
const text = pos.slice(1).join(' ').replace(/\\n/g, '\n').replace(/\\t/g, '\t').replace(/\\b/g, '\b').replace(/\\e/g, '\x1b');
const base = 'http://127.0.0.1:9222';

function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let id = 0; const pending = new Map();
    ws.addEventListener('message', ev => {
      let msg; try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id); pending.delete(msg.id);
        msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
      }
    });
    ws.addEventListener('error', () => reject(new Error('ws fail')));
    ws.addEventListener('open', () => resolve({
      send(m, p) { return new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); },
      close() { try { ws.close(); } catch {} }
    }));
  });
}
async function evalExpr(c, expression) {
  const r = await c.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) throw new Error('eval: ' + JSON.stringify(r.exceptionDetails).slice(0, 200));
  return r.result ? r.result.value : undefined;
}

// US 布局：字符 -> {code, keyCode, shift}
const SHIFT_MAP = { '~': '`', '!': '1', '@': '2', '#': '3', '$': '4', '%': '5', '^': '6', '&': '7', '*': '8', '(': '9', ')': '0', '_': '-', '+': '=', '{': '[', '}': ']', '|': '\\', ':': ';', '"': "'", '<': ',', '>': '.', '?': '/' };
const PUNCT = { '`': ['Backquote', 192], '-': ['Minus', 189], '=': ['Equal', 187], '[': ['BracketLeft', 219], ']': ['BracketRight', 221], '\\': ['Backslash', 220], ';': ['Semicolon', 186], "'": ['Quote', 222], ',': ['Comma', 188], '.': ['Period', 190], '/': ['Slash', 191], ' ': ['Space', 32] };
const NAMED = { '\n': ['Enter', 13, 'Enter'], '\t': ['Tab', 9, 'Tab'], '\b': ['Backspace', 8, 'Backspace'], '\x1b': ['Escape', 27, 'Escape'] };

function keyFor(ch) {
  if (NAMED[ch]) { const [code, kc, key] = NAMED[ch]; return { code, keyCode: kc, key, shift: false, text: ch === '\n' ? '\r' : (ch === '\t' ? '\t' : '') }; }
  if (/[a-z]/.test(ch)) return { code: 'Key' + ch.toUpperCase(), keyCode: ch.toUpperCase().charCodeAt(0), key: ch, shift: false, text: ch };
  if (/[A-Z]/.test(ch)) return { code: 'Key' + ch, keyCode: ch.charCodeAt(0), key: ch, shift: true, text: ch };
  if (/[0-9]/.test(ch)) return { code: 'Digit' + ch, keyCode: ch.charCodeAt(0), key: ch, shift: false, text: ch };
  if (SHIFT_MAP[ch]) {
    const b = SHIFT_MAP[ch];
    if (/[0-9]/.test(b)) return { code: 'Digit' + b, keyCode: b.charCodeAt(0), key: ch, shift: true, text: ch };
    const base = PUNCT[b];
    if (!base) return null;
    return { code: base[0], keyCode: base[1], key: ch, shift: true, text: ch };
  }
  if (PUNCT[ch]) { const [code, kc] = PUNCT[ch]; return { code, keyCode: kc, key: ch, shift: false, text: ch }; }
  return null;
}

(async () => {
  const list = await (await fetch(base + '/json/list')).json();
  const pages = list.filter(t => t.type === 'page' && (t.url || '').includes(pageMatch));
  if (!pages.length) { console.error('no page ' + pageMatch); process.exit(1); }
  const t = pages[0];
  const c = await connect(t.webSocketDebuggerUrl);

  // 点击画布中心以获得键盘焦点
  if (flags.clickon !== '0') {
    const rect = await evalExpr(c, `(() => { const cv = document.querySelector('canvas'); if(!cv) return null; const b = cv.getBoundingClientRect(); return {x: b.x + b.width/2, y: b.y + b.height/2}; })()`);
    if (rect) {
      await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: rect.x, y: rect.y, button: 'left', clickCount: 1 });
      await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: rect.x, y: rect.y, button: 'left', clickCount: 1 });
      await new Promise(r => setTimeout(r, 200));
    }
  }

  const delay = Number(flags.delay || 30);
  const skipped = [];
  const down = async (key, code, keyCode, modifiers) => {
    await c.send('Input.dispatchKeyEvent', { type: 'rawKeyDown', modifiers, key, code, windowsVirtualKeyCode: keyCode, nativeVirtualKeyCode: keyCode });
  };
  const up = async (key, code, keyCode, modifiers) => {
    await c.send('Input.dispatchKeyEvent', { type: 'keyUp', modifiers, key, code, windowsVirtualKeyCode: keyCode, nativeVirtualKeyCode: keyCode });
  };
  const tap = async (key, code, keyCode, modifiers, text) => {
    await down(key, code, keyCode, modifiers);
    if (text) await c.send('Input.dispatchKeyEvent', { type: 'char', modifiers, text, unmodifiedText: text, key, code, windowsVirtualKeyCode: keyCode, nativeVirtualKeyCode: keyCode });
    await up(key, code, keyCode, modifiers);
    await new Promise(r => setTimeout(r, delay));
  };
  for (const ch of text) {
    const k = keyFor(ch);
    if (!k) { skipped.push(ch); continue; }
    if (k.shift) {
      // QEMU 扩展键事件按 PS/2 扫描码注入：Shift 必须"按住 -> 打字符 -> 松开"
      await down('Shift', 'ShiftLeft', 16, 8);
      await new Promise(r => setTimeout(r, 20));
      await tap(k.key, k.code, k.keyCode, 8, k.text);
      await up('Shift', 'ShiftLeft', 16, 0);
      await new Promise(r => setTimeout(r, delay));
    } else {
      await tap(k.key, k.code, k.keyCode, 0, k.text);
    }
  }
  console.log('TYPED ' + text.length + ' chars' + (skipped.length ? ' SKIPPED=' + JSON.stringify(skipped) : ''));
  c.close(); process.exit(0);
})();
