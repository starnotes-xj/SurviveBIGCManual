// 35-upload.mjs -- 用 CDP 把本地文件塞进「导入文件」抽屉的 file input（绕过逐字符键入）
// 用法: node 35-upload.mjs <本地文件> [url片段]
import fs from 'node:fs';
const argv = process.argv.slice(2);
const file = argv[0];
const match = argv[1] || 'deviceName=ops-win-01';
if (!file) { console.error('用法: node 35-upload.mjs <文件> [url片段]'); process.exit(2); }
const base = 'http://127.0.0.1:9222';
const list = await (await fetch(base + '/json/list')).json();
const t = list.filter(x => x.type === 'page' && x.webSocketDebuggerUrl).find(x => (x.url || '').includes(match));
if (!t) { console.error('没找到页面: ' + match); process.exit(3); }
const ws = new WebSocket(t.webSocketDebuggerUrl);
let id = 0; const pend = new Map();
ws.onmessage = e => { let m; try { m = JSON.parse(e.data); } catch { return; } if (m.id && pend.has(m.id)) { const p = pend.get(m.id); pend.delete(m.id); m.error ? p.reject(new Error(JSON.stringify(m.error))) : p.resolve(m.result); } };
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = () => rej(new Error('ws error')); });
const send = (method, params = {}) => new Promise((resolve, reject) => { const i = ++id; pend.set(i, { resolve, reject }); ws.send(JSON.stringify({ id: i, method, params })); });
const sleep = ms => new Promise(r => setTimeout(r, ms));

await send('DOM.enable'); await send('Page.enable'); await send('Page.bringToFront');
const doc = await send('DOM.getDocument', { depth: -1 });
const q = await send('DOM.querySelector', { nodeId: doc.root.nodeId, selector: '#class-item-dialog input[type=file]' });
if (!q.nodeId) { console.error('没找到 file input（抽屉没打开？）'); process.exit(4); }
await send('DOM.setFileInputFiles', { files: [file], nodeId: q.nodeId });
console.log('SET file ->', file);
await sleep(2500);
const st = await send('Runtime.evaluate', {
  expression: `(()=>{const d=document.querySelector('#class-item-dialog');const b=[...document.querySelectorAll('#class-item-dialog button')].map(x=>x.innerText.trim()).join('/');return JSON.stringify({btns:b,text:(d?d.innerText:'').slice(0,400)});})()`,
  returnByValue: true
});
console.log('STATE: ' + st.result.value);
ws.close(); process.exit(0);
