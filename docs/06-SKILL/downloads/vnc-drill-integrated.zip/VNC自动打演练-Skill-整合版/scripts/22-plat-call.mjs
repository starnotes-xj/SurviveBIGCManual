#!/usr/bin/env node
// 22-plat-call.mjs —— 通用平台接口调用器（带上 token + PHPSESSID Cookie，只读探测）
//
// 用法：
//   node 22-plat-call.mjs --out <outdir> --path /domain/domain/vpninfo --body "dark=1&view=1&module=drill&type_=taskdrill&sourceid=<uuid>&planid=234"
//   node 22-plat-call.mjs --out <outdir> --probe vpn        # 跑一组 vpninfo 参数组合，找能返回 VPN 信息的那种
// 退出码：0 有 code=1 的响应  2 全部非成功  3 通道错误
import fs from 'node:fs';
import path from 'node:path';

const argv = process.argv.slice(2);
const opt = (n, d) => { const i = argv.indexOf('--' + n); if (i < 0) return d; const v = argv[i + 1]; argv.splice(i, 2); return v; };

const BASE = opt('base', 'https://tp.qianxin.com');
const OUT = path.resolve(opt('out', '.'));
const SRCID = opt('sourceid', '23b2374f-5691-45c7-8d18-3abea8797778');
const PLANID = opt('planid', '234');
const DRILL = `dark=1&view=1&module=drill&type_=taskdrill&sourceid=${SRCID}&planid=${PLANID}`;

const token = fs.existsSync(path.join(OUT, 'token.txt')) ? fs.readFileSync(path.join(OUT, 'token.txt'), 'utf8').trim() : '';
const cookie = fs.existsSync(path.join(OUT, 'cookie-header.txt')) ? fs.readFileSync(path.join(OUT, 'cookie-header.txt'), 'utf8').trim() : '';

const HDR = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',
  'Accept': 'application/json, text/plain, */*',
  'Accept-Language': 'zh-CN,zh;q=0.9',
  'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
  'Referer': BASE + '/static/topo/',
  'Origin': BASE,
  'X-Requested-With': 'XMLHttpRequest',
  ...(token ? { token } : {}),
  ...(cookie ? { Cookie: cookie } : {}),
};

async function call(p, body) {
  const t0 = Date.now();
  try {
    const r = await fetch(BASE + p, { method: 'POST', headers: HDR, body });
    const text = await r.text();
    let json = null; try { json = JSON.parse(text); } catch { }
    return { path: p, body, status: r.status, ms: Date.now() - t0, code: json && json.code, msg: json && json.msg, json, text };
  } catch (e) { return { path: p, body, err: e.message }; }
}

function show(r) {
  console.log(`\n### ${r.path}  body="${r.body}"`);
  if (r.err) { console.log('  ERR ' + r.err); return; }
  console.log(`  HTTP ${r.status} code=${r.code} msg=${r.msg || ''}  ${r.ms}ms`);
  console.log('  ' + String(r.text).replace(/\s+/g, ' ').slice(0, 1500));
}

const probe = opt('probe', '');
if (probe === 'vpn') {
  const combos = [
    [DRILL, '/domain/domain/vpninfo'],
    [`${DRILL}&uuid=3efd490f-9d5f-4c48-8395-d58baf0df988`, '/domain/domain/vpninfo'],
    [`${DRILL}&domainuuid=3efd490f-9d5f-4c48-8395-d58baf0df988`, '/domain/domain/vpninfo'],
    [`${DRILL}&virtuuid=e599a498-c54c-35ab-9499-417eaef83b68`, '/domain/domain/vpninfo'],
    [`${DRILL}&uuid=b86b20b2-3fa5-4e36-8dd4-aba5576d2579`, '/domain/domain/vpninfo'],
    [`${DRILL}&uuid=f1d48b6c-b6d4-3dcb-aa01-0e84dc58b412`, '/domain/domain/vpninfo'],
    [`${DRILL}&uuid=118ab23c-c0d9-43ef-9cb2-1547ca9af46b`, '/domain/domain/vpninfo'],
    [DRILL, '/domain/domain/getvpn'],
    [`${DRILL}`, '/drill/drillView/vpninfo'],
    [`dmid=${SRCID}`, '/drill/drillView/vpninfo'],
    [`dmid=${SRCID}`, '/drill/drillView/webInfo'],
    [DRILL, '/domain/domain/gettopo'],
    [DRILL, '/domain/domain/nodelist'],
    [DRILL, '/domain/domain/topostatus'],
  ];
  let ok = 0, bad = 0, err = 0;
  for (const [body, p] of combos) {
    const r = await call(p, body);
    show(r);
    if (r.err) err++; else if (r.code === 1) ok++; else bad++;
  }
  console.log(`\n[*] ok=${ok} 非成功=${bad} 通道错误=${err}`);
  process.exit(ok > 0 ? 0 : (err ? 3 : 2));
}

const p = opt('path', '');
const body = opt('body', DRILL);
if (!p) { console.error('用法: --path <接口> [--body <表单>]  或  --probe vpn'); process.exit(3); }
const r = await call(p, body);
show(r);
process.exit(r.code === 1 ? 0 : (r.err ? 3 : 2));
