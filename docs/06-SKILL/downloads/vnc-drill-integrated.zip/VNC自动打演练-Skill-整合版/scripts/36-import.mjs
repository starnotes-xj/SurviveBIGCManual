// 36-import.mjs -- 打开「导入文件」抽屉 -> 塞文件 -> 点上传（一次 CDP 会话内完成）
// 用法: node 36-import.mjs <本地文件> [url片段]
const argv = process.argv.slice(2);
const file = argv[0];
const match = argv[1] || 'deviceName=ops-win-01';
if (!file) { console.error('用法: node 36-import.mjs <文件> [url片段]'); process.exit(2); }
const base = 'http://127.0.0.1:9222';
const list = await (await fetch(base + '/json/list')).json();
const t = list.filter(x => x.type === 'page' && x.webSocketDebuggerUrl).find(x => (x.url || '').includes(match));
if (!t) { console.error('没找到页面: ' + match); process.exit(3); }
const ws = new WebSocket(t.webSocketDebuggerUrl);
let id = 0; const pend = new Map();
ws.onmessage = e => { let m; try { m = JSON.parse(e.data); } catch { return; } if (m.id && pend.has(m.id)) { const p = pend.get(m.id); pend.delete(m.id); m.error ? p.reject(new Error(JSON.stringify(m.error))) : p.resolve(m.result); } };
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = () => rej(new Error('ws error')); });
const send = (method, params = {}) => new Promise((resolve, reject) => { const i = ++id; pend.set(i, { resolve, reject }); ws.send(JSON.stringify({ id: i, method, params })); });
const sleep = ms => new Promise(r => setTimeout(r, ms));
const ev = async expr => (await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true })).result.value;

await send('DOM.enable'); await send('Page.enable'); await send('Page.bringToFront');
// 1) 打开抽屉（若已开则跳过）
let opened = await ev(`(()=>{const d=document.querySelector('#class-item-dialog .ant-drawer-open');if(d)return 'ALREADY';const i=document.querySelector('.icon-icon_importingfiles');if(!i)return 'NOICON';(i.parentElement||i).click();return 'CLICKED';})()`);
console.log('DRAWER: ' + opened);
await sleep(2000);
// 2) 塞文件
const doc = await send('DOM.getDocument', { depth: -1 });
const q = await send('DOM.querySelector', { nodeId: doc.root.nodeId, selector: '#class-item-dialog input[type=file]' });
if (!q.nodeId) { console.error('没找到 file input'); process.exit(4); }
await send('DOM.setFileInputFiles', { files: [file], nodeId: q.nodeId });
console.log('SET file -> ' + file);
await sleep(1200);
// 3) 点上传
const clicked = await ev(`(()=>{const b=[...document.querySelectorAll('#class-item-dialog button')].find(x=>x.innerText.trim()==='上传文件');if(!b)return 'NOBTN';b.click();return 'CLICKED';})()`);
console.log('UPLOAD: ' + clicked);
await sleep(8000);
console.log('TAIL: ' + (await ev(`document.querySelector('#class-item-dialog').innerText.slice(-200)`)));
ws.close(); process.exit(0);
