// vnc-helper-browser.js —— 路线B（chrome-devtools MCP / 任意页面 eval）用的 noVNC 键鼠注入助手
//
// 适用：Claude Code 自带 chrome-devtools MCP（evaluate_script）直接驱动浏览器里的 noVNC 页面，
//       不需要 9222 端口、不需要 Node 脚本（路线A 见同目录 cdp.js / vm.js / sendkeys.js）。
//
// 用法（把整个 IIFE 作为 evaluate_script 的 function 注入，每次页面加载后重新注入一次）：
//   await window.__vnc.click(356, 279);                 // 点 canvas 内部坐标（默认 1280x720 坐标系）
//   await window.__vnc.type('id\n');                    // 逐字符输入（\n=回车；内部自动处理 Shift）
//   await window.__vnc.lines(['cmd1', 'cmd2'], 900);    // 依次整行输入，行间等待 900ms
//   await window.__vnc.key('c', { ctrl: true });        // Ctrl+C（修饰键独立按下/抬起）
//   await window.__vnc.press('Escape');                 // 特殊键：Escape/Tab/Backspace/Enter/方向键
//
// 关键经验：
//  - 合成 KeyboardEvent 必须 defineProperty 覆写 keyCode/which/charCode（noVNC 依赖）；
//  - Shift 字符必须显式 Shift keydown → 字符 keydown/keyup → Shift keyup（否则 _ 变 -）；
//  - Ctrl 组合（Ctrl+C）修饰键与字符事件必须分开发，且 keyup 顺序相反；
//  - 打字节奏：16ms/字符 + 每 22 字符补 180ms（防远端丢键）；长命令分 3~5 行批处理；
//  - 每次操作前先 click 终端内容区恢复焦点；页面重载/浏览器重连后必须重新注入并重取 canvas。
(() => {
  const canvas = document.querySelector('canvas');
  if (!canvas) return 'NO_CANVAS(页面里没有 canvas —— VNC 未就绪或选错了页面)';
  const r = canvas.getBoundingClientRect();
  const SX = r.width / canvas.width, SY = r.height / canvas.height;
  const sleep = ms => new Promise(res => setTimeout(res, ms));
  const KEY = {};
  'abcdefghijklmnopqrstuvwxyz'.split('').forEach((c, i) => { KEY[c] = [c, 'Key' + c.toUpperCase(), 65 + i]; });
  '0123456789'.split('').forEach((c, i) => { KEY[c] = [c, 'Digit' + c, 48 + i]; });
  Object.assign(KEY, {
    ' ': [' ', 'Space', 32], '-': ['-', 'Minus', 189], '=': ['=', 'Equal', 187], '/': ['/', 'Slash', 191],
    '\\': ['\\', 'Backslash', 220], '.': ['.', 'Period', 190], ',': [',', 'Comma', 188], ';': [';', 'Semicolon', 186],
    "'": ["'", 'Quote', 222], '[': ['[', 'BracketLeft', 219], ']': [']', 'BracketRight', 221], '`': ['`', 'Backquote', 192],
    '\n': ['Enter', 'Enter', 13]
  });
  const SH = {
    '~': '`', '!': '1', '@': '2', '#': '3', '$': '4', '%': '5', '^': '6', '&': '7', '*': '8', '(': '9', ')': '0',
    '_': '-', '+': '=', '{': '[', '}': ']', '|': '\\', ':': ';', '"': "'", '<': ',', '>': '.', '?': '/'
  };
  const SPECIAL = {
    Escape: ['Escape', 'Escape', 27], Tab: ['Tab', 'Tab', 9], Backspace: ['Backspace', 'Backspace', 8],
    Enter: ['Enter', 'Enter', 13], ArrowUp: ['ArrowUp', 'ArrowUp', 38], ArrowDown: ['ArrowDown', 'ArrowDown', 40],
    ArrowLeft: ['ArrowLeft', 'ArrowLeft', 37], ArrowRight: ['ArrowRight', 'ArrowRight', 39],
    Home: ['Home', 'Home', 36], End: ['End', 'End', 35], Delete: ['Delete', 'Delete', 46]
  };
  const ev = (type, kn, code, kc, sh, ct) => {
    const e = new KeyboardEvent(type, { bubbles: true, cancelable: true, view: window, key: kn, code, shiftKey: !!sh, ctrlKey: !!ct });
    Object.defineProperty(e, 'keyCode', { get: () => kc });
    Object.defineProperty(e, 'which', { get: () => kc });
    Object.defineProperty(e, 'charCode', { get: () => 0 });
    canvas.dispatchEvent(e);
  };
  const ka = async (ch, d = 16) => {
    let b, s = false;
    if (/[A-Z]/.test(ch)) { b = ch.toLowerCase(); s = true; }
    else if (KEY[ch]) b = ch; else if (SH[ch]) { b = SH[ch]; s = true; } else return;
    const t = KEY[b]; if (!t) return;
    const kn = s ? (b.length === 1 ? b.toUpperCase() : t[0]) : t[0];
    if (s) { ev('keydown', 'Shift', 'ShiftLeft', 16, true, false); await sleep(55); }
    ev('keydown', kn, t[1], t[2], s, false); await sleep(d);
    ev('keyup', kn, t[1], t[2], s, false); await sleep(d);
    if (s) { ev('keyup', 'Shift', 'ShiftLeft', 16, false, false); await sleep(55); }
  };
  const press = async name => {
    const t = SPECIAL[name]; if (!t) return 'UNKNOWN_KEY:' + name;
    ev('keydown', t[0], t[1], t[2], false, false); await sleep(90);
    ev('keyup', t[0], t[1], t[2], false, false); await sleep(90);
    return 'pressed:' + name;
  };
  const click = async (x, y) => {
    const cx = r.left + x * SX, cy = r.top + y * SY;
    const cfg = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy, button: 0, buttons: 1 };
    canvas.dispatchEvent(new MouseEvent('mousemove', Object.assign({}, cfg, { buttons: 0 })));
    await sleep(60);
    canvas.dispatchEvent(new MouseEvent('mousedown', cfg));
    await sleep(60);
    canvas.dispatchEvent(new MouseEvent('mouseup', Object.assign({}, cfg, { buttons: 0 })));
    await sleep(250);
  };
  window.__vnc = {
    canvas, rect: r, scale: [SX, SY],
    click, press,
    type: async (text, d = 16) => { let n = 0; for (const ch of text) { await ka(ch, d); n++; if (n % 22 === 0) await sleep(180); } await sleep(250); },
    lines: async (arr, wait = 900, d = 16) => { for (const L of arr) { await window.__vnc.type(L + '\n', d); await sleep(wait); } },
    key: async (ch, o = {}) => {
      const mods = [];
      if (o.ctrl) mods.push(['Control', 'ControlLeft', 17]);
      if (o.alt) mods.push(['Alt', 'AltLeft', 18]);
      if (o.shift) mods.push(['Shift', 'ShiftLeft', 16]);
      for (const m of mods) { ev('keydown', m[0], m[1], m[2], !!o.shift, !!o.ctrl); await sleep(40); }
      const t = KEY[ch] || (SH[ch] && KEY[SH[ch]]);
      if (t) {
        ev('keydown', t[0], t[1], t[2], !!o.shift, !!o.ctrl); await sleep(40);
        ev('keyup', t[0], t[1], t[2], !!o.shift, !!o.ctrl); await sleep(40);
      }
      for (const m of mods.reverse()) { ev('keyup', m[0], m[1], m[2], false, false); await sleep(40); }
      return 'key:' + ch;
    },
    // 清除远端可能卡住的修饰键。
    // 典型场景：本机按了 Alt+Tab 切窗口/标签 → 浏览器只转发了 Alt keydown，焦点切走后 keyup 丢失 →
    // 远端 Alt 卡住，此后每次打字都变成 Alt+组合键（Alt+T→Terminal 菜单、Alt+E→Edit 菜单），按键被菜单吞掉。
    clearMods: async () => {
      for (const m of [['Alt', 'AltLeft', 18], ['Control', 'ControlLeft', 17], ['Shift', 'ShiftLeft', 16]]) {
        ev('keydown', m[0], m[1], m[2], false, false); await sleep(30);
        ev('keyup', m[0], m[1], m[2], false, false); await sleep(30);
      }
      const t = SPECIAL.Escape;
      ev('keydown', t[0], t[1], t[2], false, false); await sleep(80);
      ev('keyup', t[0], t[1], t[2], false, false); await sleep(120);
      return 'mods cleared';
    }
  };
  return 'injected ' + JSON.stringify({ rect: [r.left, r.top, r.width, r.height], canvas: [canvas.width, canvas.height], scale: [SX, SY] });
})()
