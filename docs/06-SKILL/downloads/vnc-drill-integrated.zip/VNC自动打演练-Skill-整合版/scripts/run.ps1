param(
  [Parameter(Mandatory=$true)][string]$Sh,
  [int]$Wait = 8,
  [string]$Tag = 'r',
  [string]$Page = '71e5aa98-b927-40f5-8674-152d965918b2',
  [string]$Map = 'glyphmap.json'
)
$ErrorActionPreference = 'Stop'
$scripts = $PSScriptRoot
$root = Split-Path $scripts -Parent
$png = Join-Path $root ($Tag + '.png')
Write-Output ('--- PUSH ' + $Sh + '  -> page ' + $Page + '  map ' + $Map)
node (Join-Path $scripts 'pushsh.js') $Page $Sh '/tmp/g.sh' 'bash'
Start-Sleep -Seconds $Wait
node (Join-Path $scripts 'vnc-shot.js') $Page $png --scale 2 | Out-Null
Write-Output '--- SCREEN'
& (Join-Path $scripts 'glyph.ps1') -Png $png -MapPath (Join-Path $scripts $Map)
