#!/usr/bin/env node
// 16-vnc.mjs —— 通过 CDP 驱动「网页 VNC 控制台」（ops-win-01）
//
// 为什么不用 cdp.js type：cdp.js 用的是 Input.insertText，它不会产生键盘事件，
// noVNC 收不到 → 字符永远到不了被控机。这里用 Input.dispatchKeyEvent 逐字符发
// keyDown/keyUp（带 windowsVirtualKeyCode + modifiers），noVNC 才认。
//
// 用法（--match 用来挑页面，默认 topo；--port 默认 9222）：
//   node 16-vnc.mjs focus                              画布点击聚焦（发 Ctrl+Alt+Del 唤醒用）
//   node 16-vnc.mjs type "whoami"                      逐字符输入
//   node 16-vnc.mjs key enter                          单键：enter/tab/esc/backspace/delete/up/down/left/right/home/end
//   node 16-vnc.mjs key win+r                          组合键：win/ctrl/alt/shift + 单键，如 ctrl+shift+enter、ctrl+v
//   node 16-vnc.mjs mouse 500,300                      鼠标单击（CSS 像素，视口坐标）
//   node 16-vnc.mjs readclip                           读「被控机 → 浏览器」剪贴板（input#clipboard 等）
//   node 16-vnc.mjs paste "长文本"                     走剪贴板通道粘贴：写入 input#clipboard → 焦点 → Ctrl+V
//   node 16-vnc.mjs shot <png 路径>                    截图（证据留存）
//   node 16-vnc.mjs eval "<js 表达式>"                 在页面里求值（排查用）
import fs from 'node:fs';

const argv = process.argv.slice(2);
const opt = (n, d) => { const i = argv.indexOf('--' + n); if (i < 0) return d; const v = argv[i + 1]; argv.splice(i, 2); return v; };
const PORT = opt('port', '9222');
const MATCH = opt('match', 'topo');
const DELAY = Number(opt('delay', '35'));
const cmd = argv[0] || 'readclip';
const arg = argv.slice(1).join(' ');

const base = `http://127.0.0.1:${PORT}`;

async function target() {
  const r = await fetch(base + '/json/list');
  const list = await r.json();
  const pages = list.filter(t => t.type === 'page' && t.webSocketDebuggerUrl);
  const hit = pages.find(t => (t.url || '').includes(MATCH)) || pages.find(t => /vnc/i.test(t.url || ''));
  if (!hit) throw new Error('没找到匹配页面: ' + MATCH + '；现有: ' + pages.map(p => p.url).join(' | '));
  return hit;
}

class Cdp {
  constructor(wsUrl) { this.wsUrl = wsUrl; this.seq = 0; this.pending = new Map(); }
  connect() {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(this.wsUrl); this.ws = ws;
      const to = setTimeout(() => reject(new Error('CDP 连接超时')), 8000);
      ws.onopen = () => { clearTimeout(to); resolve(); };
      ws.onerror = () => { clearTimeout(to); reject(new Error('CDP 连接失败')); };
      ws.onmessage = ev => {
        let m; try { m = JSON.parse(ev.data); } catch { return; }
        if (m.id && this.pending.has(m.id)) { const p = this.pending.get(m.id); this.pending.delete(m.id); m.error ? p.reject(new Error(JSON.stringify(m.error))) : p.resolve(m.result); }
      };
    });
  }
  send(method, params = {}) {
    const id = ++this.seq;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params }));
      setTimeout(() => { if (this.pending.has(id)) { this.pending.delete(id); reject(new Error('CDP 超时: ' + method)); } }, 30000);
    });
  }
  close() { try { this.ws.close(); } catch { } }
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

// ---- 单键定义：key / code / windowsVirtualKeyCode / 是否需要 shift
const NAMED = {
  enter: { key: 'Enter', code: 'Enter', vk: 13 },
  tab: { key: 'Tab', code: 'Tab', vk: 9 },
  esc: { key: 'Escape', code: 'Escape', vk: 27 },
  escape: { key: 'Escape', code: 'Escape', vk: 27 },
  backspace: { key: 'Backspace', code: 'Backspace', vk: 8 },
  delete: { key: 'Delete', code: 'Delete', vk: 46 },
  space: { key: ' ', code: 'Space', vk: 32 },
  up: { key: 'ArrowUp', code: 'ArrowUp', vk: 38 },
  down: { key: 'ArrowDown', code: 'ArrowDown', vk: 40 },
  left: { key: 'ArrowLeft', code: 'ArrowLeft', vk: 37 },
  right: { key: 'ArrowRight', code: 'ArrowRight', vk: 39 },
  home: { key: 'Home', code: 'Home', vk: 36 },
  end: { key: 'End', code: 'End', vk: 35 },
  win: { key: 'Meta', code: 'MetaLeft', vk: 91 },
  ctrl: { key: 'Control', code: 'ControlLeft', vk: 17 },
  alt: { key: 'Alt', code: 'AltLeft', vk: 18 },
  shift: { key: 'Shift', code: 'ShiftLeft', vk: 16 },
};
// F1–F12（Alt+F4 关窗口、Ctrl+Shift+Esc 任务管理器等组合键要用）
for (let i = 1; i <= 12; i++) NAMED['f' + i] = { key: 'F' + i, code: 'F' + i, vk: 111 + i };
const MOD = { alt: 1, ctrl: 2, meta: 4, win: 4, shift: 8 };

function charInfo(ch) {
  if (/^[a-z]$/.test(ch)) return { key: ch, code: 'Key' + ch.toUpperCase(), vk: ch.toUpperCase().charCodeAt(0) };
  if (/^[A-Z]$/.test(ch)) return { key: ch, code: 'Key' + ch, vk: ch.charCodeAt(0), shift: true };
  if (/^[0-9]$/.test(ch)) return { key: ch, code: 'Digit' + ch, vk: ch.charCodeAt(0) };
  const sym = {
    ' ': ['Space', 'Space', 32, false], '!': ['1', 'Digit1', 49, true], '@': ['2', 'Digit2', 50, true], '#': ['3', 'Digit3', 51, true],
    '$': ['4', 'Digit4', 52, true], '%': ['5', 'Digit5', 53, true], '^': ['6', 'Digit6', 54, true], '&': ['7', 'Digit7', 55, true],
    '*': ['8', 'Digit8', 56, true], '(': ['9', 'Digit9', 57, true], ')': ['0', 'Digit0', 48, true],
    '-': ['-', 'Minus', 189, false], '_': ['-', 'Minus', 189, true], '=': ['=', 'Equal', 187, false], '+': ['=', 'Equal', 187, true],
    '[': ['[', 'BracketLeft', 219, false], '{': ['[', 'BracketLeft', 219, true], ']': [']', 'BracketRight', 221, false], '}': [']', 'BracketRight', 221, true],
    '\\': ['\\', 'Backslash', 220, false], '|': ['\\', 'Backslash', 220, true],
    ';': [';', 'Semicolon', 186, false], ':': [';', 'Semicolon', 186, true], "'": ["'", 'Quote', 222, false], '"': ["'", 'Quote', 222, true],
    ',': [',', 'Comma', 188, false], '<': [',', 'Comma', 188, true], '.': ['.', 'Period', 190, false], '>': ['.', 'Period', 190, true],
    '/': ['/', 'Slash', 191, false], '?': ['/', 'Slash', 191, true], '`': ['`', 'Backquote', 192, false], '~': ['`', 'Backquote', 192, true],
  };
  const e = sym[ch];
  if (!e) return null;
  return { key: e[0], code: e[1], vk: e[2], shift: e[3] };
}

async function keyEvent(c, type, k, modifiers) {
  await c.send('Input.dispatchKeyEvent', {
    type, key: k.key, code: k.code,
    windowsVirtualKeyCode: k.vk, nativeVirtualKeyCode: k.vk,
    modifiers: modifiers || 0,
    ...(type === 'keyDown' && k.text ? { text: k.text, unmodifiedText: k.text } : {}),
  });
}

async function pressChar(c, ch) {
  const info = charInfo(ch);
  if (!info) throw new Error('暂不支持的字符: ' + JSON.stringify(ch));
  const mods = info.shift ? MOD.shift : 0;
  if (info.shift) await keyEvent(c, 'keyDown', NAMED.shift, MOD.shift);
  // 三段式：rawKeyDown(触发 keydown) → char(触发 keypress/输入) → keyUp
  // 有些网页终端(自研 canvas 客户端 / noVNC 不同版本)只认其中一种，这里三种都发。
  await c.send('Input.dispatchKeyEvent', {
    type: 'rawKeyDown', key: info.key, code: info.code,
    windowsVirtualKeyCode: info.vk, nativeVirtualKeyCode: info.vk, modifiers: mods,
  });
  await c.send('Input.dispatchKeyEvent', { type: 'char', text: ch, unmodifiedText: ch, key: ch, modifiers: mods });
  await keyEvent(c, 'keyUp', info, mods);
  if (info.shift) await keyEvent(c, 'keyUp', NAMED.shift, 0);
}

async function pressCombo(c, spec) {
  const parts = spec.toLowerCase().split('+').map(s => s.trim()).filter(Boolean);
  const main = parts.pop();
  const mods = parts.map(p => NAMED[p]).filter(Boolean);
  let modMask = 0;
  for (const p of mods) modMask |= MOD[p.key === 'Meta' ? 'win' : p.key === 'Control' ? 'ctrl' : p.key === 'Alt' ? 'alt' : 'shift'];
  const mainKey = NAMED[main] || (/^[a-z]$/.test(main) ? { key: main, code: 'Key' + main.toUpperCase(), vk: main.toUpperCase().charCodeAt(0) } : /^[0-9]$/.test(main) ? { key: main, code: 'Digit' + main, vk: main.charCodeAt(0) } : null);
  if (!mainKey) throw new Error('不认识的主键: ' + main);
  for (const m of mods) await keyEvent(c, 'keyDown', m, modMask);
  await keyEvent(c, 'keyDown', mainKey, modMask);
  await keyEvent(c, 'keyUp', mainKey, modMask);
  for (const m of [...mods].reverse()) await keyEvent(c, 'keyUp', m, 0);
}

async function evalExpr(c, expression) {
  const r = await c.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true, userGesture: true });
  if (r.exceptionDetails) throw new Error('页面求值异常: ' + ((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text));
  return r.result ? r.result.value : undefined;
}

async function canvasRect(c) {
  return await evalExpr(c, `(() => { const c = document.querySelector('canvas'); if (!c) return null; const r = c.getBoundingClientRect(); return { x: r.x, y: r.y, w: r.width, h: r.height }; })()`);
}

(async () => {
  const t = await target();
  console.log('# target: ' + (t.title || '') + '  ' + t.url);
  const c = new Cdp(t.webSocketDebuggerUrl);
  await c.connect();
  try {
    // 关键：把 VNC 标签页切到前台。后台标签会被 Chrome 节流 —— 画面不重绘、
    // 键盘事件也可能被丢掉（第 7 轮踩坑：Run 对话框一直停在旧画面）。
    try { await c.send('Page.enable'); await c.send('Page.bringToFront'); } catch { }
    if (cmd === 'eval') {
      console.log(await evalExpr(c, arg));
    } else if (cmd === 'focus') {
      const r = await canvasRect(c);
      if (!r) throw new Error('没有 canvas');
      const x = Math.round(r.x + r.w / 2), y = Math.round(r.y + r.h / 2);
      await c.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y, button: 'none' });
      await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 });
      await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 });
      console.log('FOCUS: clicked canvas center ' + x + ',' + y + '  rect=' + JSON.stringify(r));
    } else if (cmd === 'mouse') {
      const [x, y] = arg.split(',').map(Number);
      await c.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y, button: 'none' });
      await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 });
      await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 });
      console.log('MOUSE: ' + x + ',' + y);
    } else if (cmd === 'type') {
      for (const ch of arg) { await pressChar(c, ch); await sleep(DELAY); }
      console.log('TYPED: ' + arg);
    } else if (cmd === 'typefile') {
      // 从本地文件读一行命令再逐字符键入 —— 绕开 PowerShell 传参吞引号的坑
      const txt = fs.readFileSync(arg, 'utf8').replace(/^\uFEFF/, '').replace(/[\r\n]+$/, '');
      for (const ch of txt) { await pressChar(c, ch); await sleep(DELAY); }
      console.log('TYPEDFILE: ' + arg + '  chars=' + txt.length);
      console.log('LINE: ' + txt);
    } else if (cmd === 'key') {
      if (arg.includes('+')) await pressCombo(c, arg);
      else {
        const k = NAMED[arg.toLowerCase()];
        if (!k) throw new Error('不认识的键: ' + arg);
        await keyEvent(c, 'keyDown', k, 0); await keyEvent(c, 'keyUp', k, 0);
      }
      console.log('KEY: ' + arg);
    } else if (cmd === 'readclip') {
      const v = await evalExpr(c, `(() => {
        const out = { at: new Date().toISOString() };
        const el = document.getElementById('clipboard');
        out.clipboardInput = el ? (el.value || '') : null;
        const tas = [...document.querySelectorAll('textarea')].map(t => ({ cls: t.className, id: t.id, val: (t.value || '') }));
        out.textareas = tas;
        out.clipboardNodeText = ([...document.querySelectorAll('.clipboard_node')][0] || {}).innerText || '';
        return JSON.stringify(out);
      })()`);
      console.log(v);
    } else if (cmd === 'paste') {
      const ok = await evalExpr(c, `(() => {
        const el = document.getElementById('clipboard');
        if (!el) return 'NO_CLIPBOARD_INPUT';
        el.focus(); el.value = ${JSON.stringify(arg)}; el.dispatchEvent(new Event('input', { bubbles: true }));
        const node = document.querySelector('.clipboard_node');
        return 'SET len=' + el.value.length + ' node=' + (node ? node.innerText.slice(0, 40) : 'none');
      })()`);
      console.log('CLIPSET: ' + ok);
      await sleep(300);
      const r = await canvasRect(c);
      if (r) await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: Math.round(r.x + r.w / 2), y: Math.round(r.y + r.h / 2), button: 'left', clickCount: 1 }).then(() => c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: Math.round(r.x + r.w / 2), y: Math.round(r.y + r.h / 2), button: 'left', clickCount: 1 }));
      await pressCombo(c, 'ctrl+v');
      console.log('PASTE: ctrl+v 已发送（文本长度 ' + arg.length + '）');
    } else if (cmd === 'shot') {
      const r = await c.send('Page.captureScreenshot', { format: 'png' });
      fs.writeFileSync(arg, Buffer.from(r.data, 'base64'));
      console.log('SHOT: ' + arg);
    } else {
      throw new Error('未知命令: ' + cmd);
    }
  } finally {
    c.close();
    setTimeout(() => process.exit(0), 50);
  }
})().catch(e => { console.error('ERR: ' + e.message); process.exit(1); });
