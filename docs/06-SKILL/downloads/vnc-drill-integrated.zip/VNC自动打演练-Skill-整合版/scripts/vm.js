// Drive a noVNC console via CDP. Reliable: physically presses Shift for shifted chars.
// usage:
//   node vm.js click <sub> <x> <y>      (x,y in PAGE css px)
//   node vm.js dblclick <sub> <x> <y>
//   node vm.js key <sub> <Key> <vk> [mods]      (mods bitmask Alt=1 Ctrl=2 Shift=8)
//   node vm.js type <sub> <text>        (types text; \n = Enter if passed literally as two chars)
//   node vm.js enter <sub>
//   node vm.js shot <sub> <file.png>    (canvas capture)
const HOST = '127.0.0.1:9222';
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function targets() { return (await (await fetch(`http://${HOST}/json/list`)).json()).filter(t => t.type === 'page'); }
async function conn(u) { const ws = new WebSocket(u); await new Promise((r, j) => { ws.onopen = r; ws.onerror = () => j(new Error('wserr')); }); let id = 0; const p = new Map(); ws.onmessage = e => { let m; try { m = JSON.parse(e.data); } catch { return; } if (m.id && p.has(m.id)) { p.get(m.id)(m); p.delete(m.id); } }; const send = (method, params = {}) => new Promise(r => { const i = ++id; p.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); }); return { ws, send }; }
async function withPage(sub, fn) { const t = (await targets()).find(x => x.url.includes(sub)) || (await targets()).slice(-1)[0]; if (!t) { console.log('NO_TARGET'); return; } const c = await conn(t.webSocketDebuggerUrl); try { await c.send('Page.bringToFront').catch(() => { }); return await fn(c); } finally { c.ws.close(); } }
const rv = r => r && r.result && r.result.result && r.result.result.value;

// ---- key map: ch -> {vk, code, shift} ----
const M = {};
for (let i = 0; i < 26; i++) { const lc = String.fromCharCode(97 + i), uc = lc.toUpperCase(); M[lc] = { vk: 65 + i, code: 'Key' + uc, shift: false }; M[uc] = { vk: 65 + i, code: 'Key' + uc, shift: true }; }
const base = { '0': [48, 'Digit0'], '1': [49, 'Digit1'], '2': [50, 'Digit2'], '3': [51, 'Digit3'], '4': [52, 'Digit4'], '5': [53, 'Digit5'], '6': [54, 'Digit6'], '7': [55, 'Digit7'], '8': [56, 'Digit8'], '9': [57, 'Digit9'],
  ' ': [32, 'Space'], '-': [189, 'Minus'], '=': [187, 'Equal'], '[': [219, 'BracketLeft'], ']': [221, 'BracketRight'], '\\': [220, 'Backslash'], ';': [186, 'Semicolon'], "'": [222, 'Quote'], ',': [188, 'Comma'], '.': [190, 'Period'], '/': [191, 'Slash'], '`': [192, 'Backquote'] };
for (const k in base) M[k] = { vk: base[k][0], code: base[k][1], shift: false };
const shifted = { '!': '1', '@': '2', '#': '3', '$': '4', '%': '5', '^': '6', '&': '7', '*': '8', '(': '9', ')': '0', '_': '-', '+': '=', '{': '[', '}': ']', '|': '\\', ':': ';', '"': "'", '<': ',', '>': '.', '?': '/', '~': '`' };
for (const s in shifted) { const b = M[shifted[s]]; M[s] = { vk: b.vk, code: b.code, shift: true }; }

async function tap(c, ch) {
  if (ch === '\n' || ch === '\r') return tapKey(c, 'Enter', 'Enter', 13, 0);
  if (ch === '\t') return tapKey(c, 'Tab', 'Tab', 9, 0);
  const m = M[ch]; if (!m) return;
  const mod = m.shift ? 8 : 0;
  if (m.shift) await c.send('Input.dispatchKeyEvent', { type: 'rawKeyDown', key: 'Shift', code: 'ShiftLeft', windowsVirtualKeyCode: 16, nativeVirtualKeyCode: 16, modifiers: 8 });
  await c.send('Input.dispatchKeyEvent', { type: 'keyDown', key: ch, code: m.code, windowsVirtualKeyCode: m.vk, nativeVirtualKeyCode: m.vk, modifiers: mod, text: ch, unmodifiedText: ch });
  await c.send('Input.dispatchKeyEvent', { type: 'keyUp', key: ch, code: m.code, windowsVirtualKeyCode: m.vk, nativeVirtualKeyCode: m.vk, modifiers: mod });
  if (m.shift) await c.send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Shift', code: 'ShiftLeft', windowsVirtualKeyCode: 16, nativeVirtualKeyCode: 16, modifiers: 0 });
  await sleep(22);
}
async function tapKey(c, key, code, vk, mods) {
  await c.send('Input.dispatchKeyEvent', { type: 'keyDown', key, code, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk, modifiers: mods });
  await c.send('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk, modifiers: mods });
  await sleep(22);
}

(async () => {
  const [, , cmd, sub, ...a] = process.argv;
  if (cmd === 'click' || cmd === 'dblclick') { await withPage(sub, async c => { const x = +a[0], y = +a[1], cc = cmd === 'dblclick' ? 2 : 1; await c.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y }); await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', buttons: 1, clickCount: cc }); await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', buttons: 0, clickCount: cc }); console.log(cmd, x, y); }); return; }
  if (cmd === 'key') {
    await withPage(sub, async c => {
      const key = a[0], vk = a[1] ? +a[1] : 13, mods = a[2] ? +a[2] : 0;
      const held = [];
      if (mods & 1) { await c.send('Input.dispatchKeyEvent', { type: 'rawKeyDown', key: 'Alt', code: 'AltLeft', windowsVirtualKeyCode: 18, nativeVirtualKeyCode: 18, modifiers: 1 }); held.push(['Alt', 'AltLeft', 18]); }
      if (mods & 2) { await c.send('Input.dispatchKeyEvent', { type: 'rawKeyDown', key: 'Control', code: 'ControlLeft', windowsVirtualKeyCode: 17, nativeVirtualKeyCode: 17, modifiers: 2 }); held.push(['Control', 'ControlLeft', 17]); }
      if (mods & 8) { await c.send('Input.dispatchKeyEvent', { type: 'rawKeyDown', key: 'Shift', code: 'ShiftLeft', windowsVirtualKeyCode: 16, nativeVirtualKeyCode: 16, modifiers: 8 }); held.push(['Shift', 'ShiftLeft', 16]); }
      await c.send('Input.dispatchKeyEvent', { type: 'keyDown', key, code: key, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk, modifiers: mods });
      await c.send('Input.dispatchKeyEvent', { type: 'keyUp', key, code: key, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk, modifiers: mods });
      for (const [k, cd, v] of held.reverse()) await c.send('Input.dispatchKeyEvent', { type: 'keyUp', key: k, code: cd, windowsVirtualKeyCode: v, nativeVirtualKeyCode: v, modifiers: 0 });
      console.log('key', key, vk, mods);
    }); return;
  }
  if (cmd === 'enter') { await withPage(sub, async c => { await tapKey(c, 'Enter', 'Enter', 13, 0); console.log('enter'); }); return; }
  if (cmd === 'type') { await withPage(sub, async c => { const text = a.join(' '); for (const ch of text) await tap(c, ch); console.log('typed', text.length); }); return; }
  if (cmd === 'shot') { await withPage(sub, async c => { const r = await c.send('Runtime.evaluate', { expression: "(()=>{const c=document.querySelector('canvas');if(!c)return 'NOCANVAS';try{return c.toDataURL('image/png')}catch(e){return 'ERR '+e}})()", returnByValue: true }); const v = rv(r); if (!v || v.startsWith('ERR') || v === 'NOCANVAS') { console.log(v); return; } require('fs').writeFileSync(a[0], Buffer.from(v.split(',')[1], 'base64')); console.log('saved', a[0]); }); return; }
  console.log('cmds: click|dblclick|key|enter|type|shot');
})();
