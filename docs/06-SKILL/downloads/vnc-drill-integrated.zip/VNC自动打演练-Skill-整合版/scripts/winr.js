#!/usr/bin/env node
'use strict';
// winr.js —— Windows 靶机：Win+R 打开运行框，输入命令并回车
// 用法: node winr.js <pageMatch> "<要输入的命令>" [--enter 1]
const base = 'http://127.0.0.1:9222';
const pageMatch = process.argv[2];
const text = process.argv[3] || '';
function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let id = 0; const pending = new Map();
    ws.addEventListener('message', ev => {
      let msg; try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id); pending.delete(msg.id);
        msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
      }
    });
    ws.addEventListener('error', () => reject(new Error('ws fail')));
    ws.addEventListener('open', () => resolve({
      send(m, p) { return new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); },
      close() { try { ws.close(); } catch {} }
    }));
  });
}
async function ev(c, expression) {
  const r = await c.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true, userGesture: true });
  if (r.exceptionDetails) return 'ERR';
  return r.result ? r.result.value : null;
}
const SHIFT_MAP = { '~': '`', '!': '1', '@': '2', '#': '3', '$': '4', '%': '5', '^': '6', '&': '7', '*': '8', '(': '9', ')': '0', '_': '-', '+': '=', '{': '[', '}': ']', '|': '\\', ':': ';', '"': "'", '<': ',', '>': '.', '?': '/' };
const PUNCT = { '`': ['Backquote', 192], '-': ['Minus', 189], '=': ['Equal', 187], '[': ['BracketLeft', 219], ']': ['BracketRight', 221], '\\': ['Backslash', 220], ';': ['Semicolon', 186], "'": ['Quote', 222], ',': ['Comma', 188], '.': ['Period', 190], '/': ['Slash', 191], ' ': ['Space', 32] };
function keyFor(ch) {
  if (ch === '\n') return { code: 'Enter', keyCode: 13, key: 'Enter', shift: false, text: '' };
  if (/[a-z]/.test(ch)) return { code: 'Key' + ch.toUpperCase(), keyCode: ch.toUpperCase().charCodeAt(0), key: ch, shift: false, text: ch };
  if (/[A-Z]/.test(ch)) return { code: 'Key' + ch, keyCode: ch.charCodeAt(0), key: ch, shift: true, text: ch };
  if (/[0-9]/.test(ch)) return { code: 'Digit' + ch, keyCode: ch.charCodeAt(0), key: ch, shift: false, text: ch };
  if (SHIFT_MAP[ch]) { const b = SHIFT_MAP[ch]; if (/[0-9]/.test(b)) return { code: 'Digit' + b, keyCode: b.charCodeAt(0), key: ch, shift: true, text: ch }; const p = PUNCT[b]; return p ? { code: p[0], keyCode: p[1], key: ch, shift: true, text: ch } : null; }
  if (PUNCT[ch]) { const [code, kc] = PUNCT[ch]; return { code, keyCode: kc, key: ch, shift: false, text: ch }; }
  return null;
}
(async () => {
  const list = await (await fetch(base + '/json/list')).json();
  const page = list.find(t => t.type === 'page' && (t.url || '').includes(pageMatch));
  if (!page) { console.error('no page ' + pageMatch); process.exit(1); }
  const c = await connect(page.webSocketDebuggerUrl);
  const rect = await ev(c, `(() => { const cv=document.querySelector('canvas'); if(!cv) return null; const b=cv.getBoundingClientRect(); return {x:b.x+b.width/2,y:b.y+b.height/2}; })()`);
  if (rect && rect.x) {
    await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: rect.x, y: rect.y, button: 'left', clickCount: 1 });
    await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: rect.x, y: rect.y, button: 'left', clickCount: 1 });
    await new Promise(r => setTimeout(r, 200));
  }
  const down = (key, code, kc, mod) => c.send('Input.dispatchKeyEvent', { type: 'rawKeyDown', modifiers: mod, key, code, windowsVirtualKeyCode: kc, nativeVirtualKeyCode: kc });
  const up = (key, code, kc, mod) => c.send('Input.dispatchKeyEvent', { type: 'keyUp', modifiers: mod, key, code, windowsVirtualKeyCode: kc, nativeVirtualKeyCode: kc });
  // Win+R
  await down('Meta', 'MetaLeft', 91, 4);
  await new Promise(r => setTimeout(r, 150));
  await down('r', 'KeyR', 82, 4);
  await up('r', 'KeyR', 82, 4);
  await up('Meta', 'MetaLeft', 91, 0);
  await new Promise(r => setTimeout(r, 1200));
  const delay = 55;
  for (const ch of text) {
    const k = keyFor(ch);
    if (!k) continue;
    if (k.shift) { await down('Shift', 'ShiftLeft', 16, 8); await down(k.key, k.code, k.keyCode, 8); await up(k.key, k.code, k.keyCode, 8); await up('Shift', 'ShiftLeft', 16, 0); }
    else { await down(k.key, k.code, k.keyCode, 0); await up(k.key, k.code, k.keyCode, 0); }
    await new Promise(r => setTimeout(r, delay));
  }
  await down('Enter', 'Enter', 13, 0);
  await up('Enter', 'Enter', 13, 0);
  console.log('WINR+typed: ' + text);
  c.close();
  process.exit(0);
})();
