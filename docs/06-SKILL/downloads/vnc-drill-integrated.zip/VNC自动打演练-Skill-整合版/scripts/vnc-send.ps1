param(
  [string]$Line = '',
  [string]$LineFile = '',
  [string]$PsFile = '',
  [int]$Wait = 6,
  [string]$Tag = 'cmd',
  [int]$Delay = 35,
  [string]$Match = 'YJ-EVIDENCE',
  [switch]$NoFocus
)
# vnc-send.ps1 -- 向指定 topo VNC 被控机键入"一行"命令 -> 回车 -> 等待 -> 截图 -> OCR
# 三种输入：-PsFile(脚本文件,走 base64 -EncodedCommand) / -LineFile(文件内容当命令行) / -Line(直接文本)
# -NoFocus: 跳过"点击画布聚焦"。Windows 被控机开了快速编辑时，点击会把控制台拖进 Mark 模式并吞掉所有按键，
#           此时应配合 scripts\run-dialog.ps1（Win+R 拿焦点）或手动 win+r 后用 -NoFocus。
$root = Split-Path -Parent $PSScriptRoot
$outDir = Join-Path $root 'out'
if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }

if ($PsFile -ne '') {
  if (-not [System.IO.Path]::IsPathRooted($PsFile)) { $PsFile = Join-Path $root $PsFile }
  $code = [System.IO.File]::ReadAllText($PsFile)
  $Line = 'powershell -nop -enc ' + [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($code))
}
elseif ($LineFile -ne '') {
  if (-not [System.IO.Path]::IsPathRooted($LineFile)) { $LineFile = Join-Path $root $LineFile }
  $Line = [System.IO.File]::ReadAllText($LineFile).TrimEnd("`r", "`n")
}
if ($Line -eq '') { throw 'need -Line, -LineFile or -PsFile' }

$ErrorActionPreference = 'Stop'
$env:PYTHONIOENCODING = 'utf-8'
$cmdFile = Join-Path $root "out\line-$Tag.txt"
[System.IO.File]::WriteAllText($cmdFile, $Line, (New-Object System.Text.UTF8Encoding($false)))
Write-Host ("[vnc-send] match=$Match tag=$Tag chars=" + $Line.Length + " wait=${Wait}s")

if (-not $NoFocus) {
  node "$root\scripts\16-vnc.mjs" focus --match $Match | Out-Null
  Start-Sleep -Milliseconds 700
}
node "$root\scripts\16-vnc.mjs" typefile $cmdFile --match $Match --delay $Delay
node "$root\scripts\16-vnc.mjs" key enter --match $Match
Start-Sleep -Seconds $Wait
$png = Join-Path $root "out\scr-$Tag.png"
node "$root\scripts\16-vnc.mjs" shot $png --match $Match
python "$root\scripts\20-screen-ocr.py" $png --txt (Join-Path $root "out\ocr-$Tag.txt") 2>$null | Out-Null
Write-Host "OCR -> out\ocr-$Tag.txt (png: out\scr-$Tag.png)"
