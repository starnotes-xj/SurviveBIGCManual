(() => {
  if (window.__wshook3) return 'ALREADY';
  window.__wshook3 = true;
  window.__ks = [];
  const orig = WebSocket.prototype.send;
  WebSocket.prototype.send = function (d) {
    try {
      let u = null;
      if (d instanceof ArrayBuffer) u = new Uint8Array(d);
      else if (d && d.buffer instanceof ArrayBuffer) u = new Uint8Array(d.buffer, d.byteOffset, d.byteLength);
      if (u && u[0] === 255 && u.length >= 12) {
        const hex = [...u].map(b => b.toString(16).padStart(2, '0')).join(' ');
        let ks = ((u[4] << 24) | (u[5] << 16) | (u[6] << 8) | u[7]) >>> 0;
        const down = (ks & 0x80000000) ? 1 : 0;
        ks = ks & 0x7fffffff;
        const scan = ((u[8] << 24) | (u[9] << 16) | (u[10] << 8) | u[11]) >>> 0;
        window.__ks.push('hex[' + hex + '] keysym=' + ks + ' scan=' + scan + ' down=' + down);
      }
    } catch (e) { window.__ks.push('ERR ' + e.message); }
    return orig.apply(this, arguments);
  };
  return 'WS_HOOKED3';
})()
