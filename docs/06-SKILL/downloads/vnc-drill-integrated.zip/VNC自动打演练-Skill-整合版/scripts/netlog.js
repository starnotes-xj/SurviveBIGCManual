#!/usr/bin/env node
'use strict';
// netlog.js —— 附加到某个 CDP 页面，开启 Network，导航/等待，打印所有请求（用于发现平台接口）
// 用法: node netlog.js <urlMatch> <navigateUrl|-> [waitMs]
const match = process.argv[2] || 'dril-web';
const navTo = process.argv[3] && process.argv[3] !== '-' ? process.argv[3] : null;
const waitMs = Number(process.argv[4] || 8000);
const base = 'http://127.0.0.1:9222';

function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let id = 0;
    const pending = new Map();
    ws.addEventListener('message', ev => {
      let msg; try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id); pending.delete(msg.id);
        msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
      } else if (msg.method) handlers.forEach(h => h(msg));
    });
    ws.addEventListener('error', () => reject(new Error('ws fail')));
    ws.addEventListener('open', () => resolve({
      send(m, p) { return new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); },
      close() { try { ws.close(); } catch {} }
    }));
  });
}
const handlers = [];
const seen = new Map();
handlers.push(msg => {
  if (msg.method === 'Network.requestWillBeSent') {
    const r = msg.params.request;
    if (/\.(png|jpg|jpeg|gif|svg|woff2?|ttf|css|ico|map)(\?|$)/i.test(r.url)) return;
    if (seen.has(r.url)) return;
    seen.set(r.url, 1);
    console.log(`[${r.method}] ${r.url}${r.postData ? '  BODY=' + String(r.postData).slice(0, 300) : ''}`);
  }
  if (msg.method === 'Network.responseReceived') {
    const r = msg.params.response;
    if (r.mimeType && /json/i.test(r.mimeType)) console.log(`   <- ${r.status} ${r.url}`);
  }
});

(async () => {
  const list = await (await fetch(base + '/json/list')).json();
  const pages = list.filter(t => t.type === 'page' && (t.url || '').includes(match));
  if (!pages.length) { console.error('no page matching ' + match); process.exit(1); }
  const t = pages[0];
  console.log('# target: ' + t.url);
  const c = await connect(t.webSocketDebuggerUrl);
  await c.send('Network.enable');
  await c.send('Page.enable');
  if (navTo) { await c.send('Page.navigate', { url: navTo }); console.log('# NAV -> ' + navTo); }
  await new Promise(r => setTimeout(r, waitMs));
  c.close();
  process.exit(0);
})();
