﻿# glyph.ps1 鈥斺€?鎺у埗鍙板瓧褰㈡ā鏉胯В鐮佸櫒锛堥€愬儚绱犵簿纭尮閰嶏紝鏇夸唬 OCR锛?# 鐢ㄦ硶:
#   寤烘ā鏉? glyph.ps1 -Png ref.png -Build -RefRow 0
#   瑙ｇ爜  : glyph.ps1 -Png xxx.png [-MapPath map.json] [-Rows 0-10]
param(
  [Parameter(Mandatory=$true)][string]$Png,
  [switch]$Build,
  [int]$RefRow = 0,
  [int]$RefRow2 = -1,
  [string]$MapPath = '',
  [string]$Rows = '',
  [int]$CellW = 8,
  [int]$CellH = 16,
  [int]$OffX = 0,
  [int]$OffY = 0,
  [switch]$Dump
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

if ($MapPath -eq '') { $MapPath = Join-Path (Split-Path $Png -Parent) 'glyphmap.json' }

$script:bmp = [System.Drawing.Bitmap]::FromFile($Png)
$script:bw = $bmp.Width
$script:bh = $bmp.Height
$rect = New-Object System.Drawing.Rectangle 0, 0, $bw, $bh
$data = $bmp.LockBits($rect, [System.Drawing.Imaging.ImageLockMode]::ReadOnly, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
$script:stride = [int]$data.Stride
$script:buf = New-Object 'byte[]' ($stride * $bh)
[System.Runtime.InteropServices.Marshal]::Copy($data.Scan0, $buf, 0, $buf.Length)
$bmp.UnlockBits($data)

$script:scale = [int]([math]::Round($bw / 1024.0))
if ($scale -lt 1) { $script:scale = 1 }
$script:cw = $CellW
$script:ch = $CellH
$script:offX = $OffX
$script:offY = $OffY
$script:cols = [int][math]::Floor($bw / ($CellW * $scale))
$script:totalRows = [int][math]::Floor($bh / ($CellH * $scale))

function Get-CellKey([int]$row, [int]$col) {
  $x0 = $script:offX + $col * $script:cw * $script:scale
  $y0 = $script:offY + $row * $script:ch * $script:scale
  $sb = New-Object System.Text.StringBuilder
  for ($yy = 0; $yy -lt $script:ch; $yy++) {
    $py = $y0 + $yy * $script:scale
    $mn = 255; $mx = 0
    for ($xx = 0; $xx -lt $script:cw; $xx++) {
      $idx = $py * $script:stride + ($x0 + $xx * $script:scale) * 4
      $lum = [int](($script:buf[$idx] + $script:buf[$idx + 1] + $script:buf[$idx + 2]) / 3)
      if ($lum -lt $mn) { $mn = $lum }
      if ($lum -gt $mx) { $mx = $lum }
    }
    $thr = [int](($mn + $mx) / 2)
    for ($xx = 0; $xx -lt $script:cw; $xx++) {
      $idx = $py * $script:stride + ($x0 + $xx * $script:scale) * 4
      $lum = [int](($script:buf[$idx] + $script:buf[$idx + 1] + $script:buf[$idx + 2]) / 3)
      if (($mx - $mn) -lt 40) { [void]$sb.Append('.') }
      elseif ($lum -gt $thr) { [void]$sb.Append('#') }
      else { [void]$sb.Append('.') }
    }
  }
  return [string]$sb.ToString()
}

function Get-RowText($map, [int]$row) {
  $chars = New-Object System.Text.StringBuilder
  for ($c = 0; $c -lt $script:cols; $c++) {
    $k = Get-CellKey $row $c
    if ($map.ContainsKey($k)) { [void]$chars.Append($map[$k]) } else { [void]$chars.Append([char]0x00B7) }
  }
  return [string]$chars.ToString().TrimEnd()
}

if ($Build) {
  $map = @{}
  $ref = -join (32..126 | ForEach-Object { [char]$_ })
  $rows = @()
  $rows = @($RefRow)
  if ($RefRow2 -ge 0) { $rows += $RefRow2 }
  foreach ($rr in $rows) {
    for ($i = 0; $i -lt $ref.Length; $i++) {
      $k = Get-CellKey $rr $i
      if (-not $map.ContainsKey($k)) { $map[$k] = [string]$ref[$i] }
    }
  }
  $blank = '.' * ($CellW * $CellH)
  if (-not $map.ContainsKey($blank)) { $map[$blank] = ' ' }
  $map | ConvertTo-Json -Depth 3 | Set-Content -Path $MapPath -Encoding UTF8
  Write-Output ('MAP built: ' + $map.Count + ' glyphs -> ' + $MapPath + ' (scale=' + $scale + ' cols=' + $cols + ' rows=' + $totalRows + ' refRows=' + ($rows -join '/') + ')')
  foreach ($rr in $rows) { Write-Output ('ROW' + $rr + ': ' + (Get-RowText $map $rr)) }
  exit 0
}

$map = @{}
if (Test-Path $MapPath) {
  $obj = Get-Content $MapPath -Raw | ConvertFrom-Json
  foreach ($p in $obj.PSObject.Properties) { $map[$p.Name] = [string]$p.Value }
} else {
  Write-Output 'NO_MAP: run with -Build first'
  exit 2
}

$range = @()
if ($Rows -ne '') {
  foreach ($part in $Rows.Split(',')) {
    if ($part -match '^(\d+)-(\d+)$') { $range += ($matches[1]..$matches[2]) }
    else { $range += [int]$part }
  }
} else { $range = 0..($totalRows - 1) }

foreach ($r in $range) {
  if ($r -ge $totalRows) { continue }
  $t = Get-RowText $map $r
  if ($t.Trim() -ne '' -or $Dump) { Write-Output ('{0,2}| {1}' -f $r, $t) }
}

