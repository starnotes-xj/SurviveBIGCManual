(async () => {
  const token = JSON.parse(localStorage.getItem('userStore') || '{}').userConfig.auth.token;
  const body = 'dark=1&view=1&module=drill&type_=taskdrill&sourceid=5ab4a224-a0d3-49bf-9f1a-7ced2124007b&planid=235';
  const r = await fetch('/domain/domain/nodelist', {
    method: 'POST', credentials: 'include',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', token }, body
  });
  const j = await r.json();
  const list = (j.data || []).map(n => ({
    name: n.text, uuid: n.uuid, ip: (n.netCardList || []).map(c => c.ip_addr).join('/'),
    vm_status: n.vm_status, status: n.status, showvnc: n.showvnc, launched: n.launched_on
  }));
  return JSON.stringify(list, null, 1);
})()
