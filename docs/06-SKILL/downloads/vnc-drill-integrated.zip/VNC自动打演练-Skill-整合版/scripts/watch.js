// capture console + network errors for a target, then reload
// usage: node watch.js <urlSubstr> <seconds>
const HOST='127.0.0.1:9222'; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function list(){return (await (await fetch(`http://${HOST}/json/list`)).json())}
async function ver(){return (await (await fetch(`http://${HOST}/json/version`)).json())}
async function conn(u){const ws=new WebSocket(u);await new Promise((r,j)=>{ws.onopen=r;ws.onerror=()=>j(new Error('wserr'))});let id=0;const p=new Map();
  ws.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch{return} if(m.id&&p.has(m.id)){p.get(m.id)(m);p.delete(m.id)} else if(m.method){ev(m)}};
  const send=(method,params={})=>new Promise(r=>{const i=++id;p.set(i,r);ws.send(JSON.stringify({id:i,method,params}))});return{ws,send}}
const out=[]; const ev=m=>{try{
  if(m.method==='Runtime.consoleAPICalled'){out.push('CONSOLE '+m.params.type+': '+m.params.args.map(a=>a.value??a.description??a.type).join(' ').slice(0,300))}
  if(m.method==='Log.entryAdded'){out.push('LOG '+m.params.entry.level+': '+m.params.entry.text.slice(0,300))}
  if(m.method==='Network.loadingFailed'){out.push('FAIL '+m.params.type+' '+(m.params.errorText||''))}
  if(m.method==='Network.webSocketFrameError'){out.push('WSERR '+m.params.errorMessage)}
  if(m.method==='Network.webSocketCreated'){out.push('WSCREATE '+m.params.url.slice(0,140))}
  if(m.method==='Network.responseReceived'&&m.params.response.status>=400){out.push('HTTP '+m.params.response.status+' '+m.params.response.url.slice(0,140))}
}catch{}}
(async()=>{const [,,sub,secs]=process.argv;
  const t=(await list()).filter(x=>x.type==='page').find(x=>x.url.includes(sub));
  if(!t){console.log('NO_TARGET');return}
  const c=await conn(t.webSocketDebuggerUrl);
  await c.send('Runtime.enable');await c.send('Log.enable');await c.send('Network.enable');await c.send('Page.enable');
  await c.send('Page.reload',{ignoreCache:false});
  await sleep((Number(secs)||10)*1000);
  console.log(out.slice(-60).join('\n')||'(no events)');
  c.ws.close();
})();
