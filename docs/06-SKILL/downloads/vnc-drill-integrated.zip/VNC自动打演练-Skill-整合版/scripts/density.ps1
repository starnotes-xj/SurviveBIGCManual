param([Parameter(Mandatory=$true)][string]$Png, [int]$Cols = 64, [int]$Rows = 24)
Add-Type -AssemblyName System.Drawing
$b = [System.Drawing.Bitmap]::FromFile($Png)
$bw = $b.Width; $bh = $b.Height
Write-Output ("size=$bw x $bh")
$sb = New-Object System.Text.StringBuilder
for ($r = 0; $r -lt $Rows; $r++) {
  $line = ''
  for ($c = 0; $c -lt $Cols; $c++) {
    $x0 = [int]($c * $bw / $Cols); $x1 = [int](($c + 1) * $bw / $Cols)
    $y0 = [int]($r * $bh / $Rows); $y1 = [int](($r + 1) * $bh / $Rows)
    $ink = 0; $n = 0
    for ($y = $y0; $y -lt $y1; $y += 3) {
      for ($x = $x0; $x -lt $x1; $x += 3) {
        $p = $b.GetPixel($x, $y)
        $l = [int](($p.R + $p.G + $p.B) / 3)
        if ($l -gt 90) { $ink++ }
        $n++
      }
    }
    $ratio = if ($n -gt 0) { $ink / $n } else { 0 }
    if ($ratio -gt 0.5) { $line += '#' } elseif ($ratio -gt 0.2) { $line += '+' } elseif ($ratio -gt 0.05) { $line += '.' } else { $line += ' ' }
  }
  [void]$sb.AppendLine($line)
}
$b.Dispose()
Write-Output $sb.ToString()
