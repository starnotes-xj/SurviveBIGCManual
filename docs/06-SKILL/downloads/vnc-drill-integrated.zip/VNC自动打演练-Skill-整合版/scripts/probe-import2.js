(async () => {
  const out = {};
  const i = document.querySelector('.icon-icon_importingfiles');
  out.iconFound = !!i;
  if (!i) return JSON.stringify(out);
  (i.parentElement || i).click();
  await new Promise(r => setTimeout(r, 1500));
  const d = document.querySelector('#class-item-dialog');
  out.dlg = d ? d.outerHTML.slice(0, 3000) : null;
  out.fileInputs = [...document.querySelectorAll('input[type=file]')].map(e => ({ id: e.id, cls: (e.className || '').toString(), accept: e.accept }));
  out.inputsAll = [...document.querySelectorAll('input')].map(e => ({ id: e.id, type: e.type, cls: (e.className || '').toString().slice(0, 40) }));
  out.dialogs = [...document.querySelectorAll('.ant-modal, .ant-drawer, [role=dialog]')].map(e => (e.innerText || '').slice(0, 300));
  return JSON.stringify(out, null, 1);
})()
