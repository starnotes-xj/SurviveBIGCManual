#!/usr/bin/env node
'use strict';
// vnc-shot.js —— 稳定截取 noVNC 画布：放大视口、画布还原为原始像素、隐藏页头，再截图
// 用法: node vnc-shot.js <pageMatch> <outPng> [--scale 2]
const argv = process.argv.slice(2);
const flags = {};
const pos = [];
for (let i = 0; i < argv.length; i++) {
  if (argv[i].startsWith('--')) { flags[argv[i].slice(2)] = argv[i + 1]; i++; }
  else pos.push(argv[i]);
}
const pageMatch = pos[0], outPath = pos[1];
const scale = Number(flags.scale || 2);
const base = 'http://127.0.0.1:9222';
const fs = require('fs');

function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let id = 0; const pending = new Map();
    ws.addEventListener('message', ev => {
      let msg; try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id); pending.delete(msg.id);
        msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
      }
    });
    ws.addEventListener('error', () => reject(new Error('ws fail')));
    ws.addEventListener('open', () => resolve({
      send(m, p) { return new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); },
      close() { try { ws.close(); } catch {} }
    }));
  });
}
async function evalExpr(c, expression) {
  const r = await c.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) throw new Error('eval: ' + JSON.stringify(r.exceptionDetails).slice(0, 200));
  return r.result ? r.result.value : undefined;
}

(async () => {
  const list = await (await fetch(base + '/json/list')).json();
  const pages = list.filter(t => t.type === 'page' && (t.url || '').includes(pageMatch));
  if (!pages.length) { console.error('no page ' + pageMatch); process.exit(1); }
  const c = await connect(pages[0].webSocketDebuggerUrl);
  await c.send('Page.enable');
  // 放大渲染视口，保证画布完整可见（不做任何固定定位，避免影响 noVNC 键盘捕获）
  await c.send('Emulation.setDeviceMetricsOverride', { width: 1400, height: 1000, deviceScaleFactor: 1, mobile: false });
  await new Promise(r => setTimeout(r, 800));
  // 画布还原原始像素 + 隐藏页头/工具栏
  const rect = await evalExpr(c, `(() => {
    const cv = document.querySelector('canvas');
    if (!cv) return null;
    // 以画布原始像素显示（不改定位，避免破坏 noVNC 的键鼠捕获）
    cv.style.width = cv.width + 'px';
    cv.style.height = cv.height + 'px';
    cv.style.imageRendering = 'pixelated';
    [...document.querySelectorAll('div,header,nav')].forEach(el => {
      const t = (el.className || '') + '';
      if (/vncoperate|commonmodeltitle|header|topbar|ant-layout-header/.test(t) && el.getBoundingClientRect().height < 120) el.style.display = 'none';
    });
    window.scrollTo(0, 0);
    const b = cv.getBoundingClientRect();
    return { x: Math.max(0, Math.floor(b.x)), y: Math.max(0, Math.floor(b.y)), width: Math.ceil(b.width), height: Math.ceil(b.height) };
  })()`);
  if (!rect) { console.error('no canvas'); process.exit(1); }
  let clip = { x: rect.x, y: rect.y, width: rect.width, height: rect.height, scale };
  if (flags.clip) {
    const [cx, cy, cw, ch] = flags.clip.split(',').map(Number);
    clip = { x: rect.x + cx, y: rect.y + cy, width: cw, height: ch, scale };
  }
  const res = await c.send('Page.captureScreenshot', { format: 'png', clip });
  fs.writeFileSync(outPath, Buffer.from(res.data, 'base64'));
  console.log('SHOT ' + outPath + ' rect=' + JSON.stringify(rect) + ' clip=' + JSON.stringify(clip));
  c.close(); process.exit(0);
})();
