(() => {
  const cands = [...document.querySelectorAll('button,a,span,div')].filter(e => (e.innerText || '').trim() === '重新连接');
  if (!cands.length) return 'NOBTN';
  const b = cands[0];
  b.click();
  return 'CLICKED ' + b.tagName + ' cls=' + (b.className || '');
})()
