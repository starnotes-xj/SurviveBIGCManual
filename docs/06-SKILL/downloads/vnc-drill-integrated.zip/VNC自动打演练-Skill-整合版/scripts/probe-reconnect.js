(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.innerText || '').trim() === '重新连接');
  const out = { dpr: window.devicePixelRatio, iw: innerWidth, ih: innerHeight };
  if (b) {
    const r = b.getBoundingClientRect();
    out.btn = { x: r.x, y: r.y, w: r.width, h: r.height, cx: Math.round(r.x + r.width / 2), cy: Math.round(r.y + r.height / 2) };
  } else {
    const d = [...document.querySelectorAll('div,span')].find(x => (x.innerText || '').trim() === '重新连接');
    if (d) { const r = d.getBoundingClientRect(); out.div = { cx: Math.round(r.x + r.width / 2), cy: Math.round(r.y + r.height / 2), tag: d.tagName, cls: (d.className || '').toString() }; }
  }
  out.dispatch = [...document.querySelectorAll('.no_canvas')].map(e => ({ disp: getComputedStyle(e).display, txt: (e.innerText || '').trim() }));
  return JSON.stringify(out);
})()
