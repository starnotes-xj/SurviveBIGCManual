<#
  setup-edge.ps1 — 一键把 Edge 置于可 CDP 调试状态（复制 profile，不动原始登录态）
  用法:  powershell -NoProfile -ExecutionPolicy Bypass -File setup-edge.ps1
  之后 CDP 在 http://127.0.0.1:9222
  说明:  Chromium 默认 profile 禁止远程调试，所以必须用“复制出来的 profile + 非默认 user-data-dir”。
#>
param(
  [int]$Port = 9222,
  [string]$Src = "$env:LOCALAPPDATA\Microsoft\Edge\User Data",
  [string]$Dst = "C:\Temp\edge-cdp"
)
$ErrorActionPreference = 'SilentlyContinue'

Write-Host "[1/4] 关闭 Edge ..." -ForegroundColor Cyan
taskkill /F /IM msedge.exe | Out-Null
Start-Sleep -Seconds 3

Write-Host "[2/4] 复制 profile -> $Dst（排除缓存，保留登录态）..." -ForegroundColor Cyan
if (!(Test-Path $Dst)) { New-Item -ItemType Directory -Path $Dst | Out-Null }
robocopy $Src $Dst /E `
  /XD Cache "Code Cache" GPUCache DawnGraphiteCache DawnWebGPUCache GrShaderCache ShaderCache `
      "Service Worker" "Media Cache" "Application Cache" Crashpad BrowserMetrics `
      component_crx_cache extensions_crx_cache OptimizationGuideModelDownloading `
  /XF "*.pma" "*.tmp" /NFL /NDL /NJH /NJS /NP /R:1 /W:1 | Out-Null
Remove-Item "$Dst\Singleton*","$Dst\lockfile" -Force -ErrorAction SilentlyContinue

Write-Host "[3/4] 启动 Edge（调试端口 $Port，正斜杠路径）..." -ForegroundColor Cyan
$edge = "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
if (!(Test-Path $edge)) { $edge = "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe" }
# 关键：user-data-dir 必须用正斜杠，否则 git-bash/cmd 会吞掉反斜杠导致回落到默认 profile
Start-Process $edge -ArgumentList "--user-data-dir=$($Dst -replace '\\','/')","--remote-debugging-port=$Port","--remote-allow-origins=*","--profile-directory=Default","--no-first-run","about:blank"
Start-Sleep -Seconds 8

Write-Host "[4/4] 验证 CDP ..." -ForegroundColor Cyan
try {
  $v = Invoke-RestMethod "http://127.0.0.1:$Port/json/version" -TimeoutSec 8
  Write-Host "  OK: $($v.Browser)  ($($v.webSocketDebuggerUrl))" -ForegroundColor Green
} catch {
  Write-Host "  失败：CDP 未就绪。检查是否残留 Edge 进程占用，或端口被占。" -ForegroundColor Red
}
Write-Host "完成。CDP 目标列表: http://127.0.0.1:$Port/json/list" -ForegroundColor Green
