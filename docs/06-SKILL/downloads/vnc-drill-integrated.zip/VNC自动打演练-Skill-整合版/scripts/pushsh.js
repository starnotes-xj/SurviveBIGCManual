#!/usr/bin/env node
'use strict';
// pushsh.js —— 把本地 shell 脚本 base64 后注入靶机（免引号），并执行
// 用法: node pushsh.js <pageMatch> <本地脚本路径> [远端路径，默认 /tmp/g.sh] [执行命令，默认 bash]
const fs = require('fs');
const pageMatch = process.argv[2];
const localPath = process.argv[3];
const remotePath = process.argv[4] || '/tmp/g.sh';
const runner = process.argv[5] || 'bash';
const base = 'http://127.0.0.1:9222';

function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let id = 0; const pending = new Map();
    ws.addEventListener('message', ev => {
      let msg; try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id); pending.delete(msg.id);
        msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
      }
    });
    ws.addEventListener('error', () => reject(new Error('ws fail')));
    ws.addEventListener('open', () => resolve({
      send(m, p) { return new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); },
      close() { try { ws.close(); } catch {} }
    }));
  });
}
async function evalExpr(c, expression) {
  const r = await c.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) throw new Error('eval: ' + JSON.stringify(r.exceptionDetails).slice(0, 200));
  return r.result ? r.result.value : undefined;
}

const SHIFT_MAP = { '~': '`', '!': '1', '@': '2', '#': '3', '$': '4', '%': '5', '^': '6', '&': '7', '*': '8', '(': '9', ')': '0', '_': '-', '+': '=', '{': '[', '}': ']', '|': '\\', ':': ';', '"': "'", '<': ',', '>': '.', '?': '/' };
const PUNCT = { '`': ['Backquote', 192], '-': ['Minus', 189], '=': ['Equal', 187], '[': ['BracketLeft', 219], ']': ['BracketRight', 221], '\\': ['Backslash', 220], ';': ['Semicolon', 186], "'": ['Quote', 222], ',': ['Comma', 188], '.': ['Period', 190], '/': ['Slash', 191], ' ': ['Space', 32] };
const NAMED = { '\n': ['Enter', 13, 'Enter'], '\t': ['Tab', 9, 'Tab'], '\b': ['Backspace', 8, 'Backspace'] };
function keyFor(ch) {
  if (NAMED[ch]) { const [code, kc, key] = NAMED[ch]; return { code, keyCode: kc, key, shift: false, text: '' }; }
  if (/[a-z]/.test(ch)) return { code: 'Key' + ch.toUpperCase(), keyCode: ch.toUpperCase().charCodeAt(0), key: ch, shift: false, text: ch };
  if (/[A-Z]/.test(ch)) return { code: 'Key' + ch, keyCode: ch.charCodeAt(0), key: ch, shift: true, text: ch };
  if (/[0-9]/.test(ch)) return { code: 'Digit' + ch, keyCode: ch.charCodeAt(0), key: ch, shift: false, text: ch };
  if (SHIFT_MAP[ch]) { const b = SHIFT_MAP[ch]; if (/[0-9]/.test(b)) return { code: 'Digit' + b, keyCode: b.charCodeAt(0), key: ch, shift: true, text: ch }; const p = PUNCT[b]; return p ? { code: p[0], keyCode: p[1], key: ch, shift: true, text: ch } : null; }
  if (PUNCT[ch]) { const [code, kc] = PUNCT[ch]; return { code, keyCode: kc, key: ch, shift: false, text: ch }; }
  return null;
}
async function typeText(c, text, delay) {
  const down = (key, code, kc, mod) => c.send('Input.dispatchKeyEvent', { type: 'rawKeyDown', modifiers: mod, key, code, windowsVirtualKeyCode: kc, nativeVirtualKeyCode: kc });
  const up = (key, code, kc, mod) => c.send('Input.dispatchKeyEvent', { type: 'keyUp', modifiers: mod, key, code, windowsVirtualKeyCode: kc, nativeVirtualKeyCode: kc });
  const skipped = [];
  for (const ch of text) {
    const k = keyFor(ch);
    if (!k) { skipped.push(ch); continue; }
    if (k.shift) {
      await down('Shift', 'ShiftLeft', 16, 8);
      await down(k.key, k.code, k.keyCode, 8);
      await up(k.key, k.code, k.keyCode, 8);
      await up('Shift', 'ShiftLeft', 16, 0);
    } else {
      await down(k.key, k.code, k.keyCode, 0);
      await up(k.key, k.code, k.keyCode, 0);
    }
    await new Promise(r => setTimeout(r, delay));
  }
  return skipped;
}

(async () => {
  const script = fs.readFileSync(localPath, 'utf8').replace(/\r\n/g, '\n');
  const b64 = Buffer.from(script, 'utf8').toString('base64');
  const list = await (await fetch(base + '/json/list')).json();
  const pages = list.filter(t => t.type === 'page' && (t.url || '').includes(pageMatch));
  if (!pages.length) { console.error('no page ' + pageMatch); process.exit(1); }
  const c = await connect(pages[0].webSocketDebuggerUrl);
  // 聚焦画布
  const rect = await evalExpr(c, `(() => { const cv=document.querySelector('canvas'); if(!cv) return null; const b=cv.getBoundingClientRect(); return {x:b.x+b.width/2,y:b.y+b.height/2}; })()`);
  if (rect) {
    await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: rect.x, y: rect.y, button: 'left', clickCount: 1 });
    await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: rect.x, y: rect.y, button: 'left', clickCount: 1 });
    await new Promise(r => setTimeout(r, 200));
  }
  // 先清干净命令行：Ctrl-C x3 + 回车 x2（应对续行/半截命令/残留输入）
  for (let k = 0; k < 3; k++) {
    await c.send('Input.dispatchKeyEvent', { type: 'rawKeyDown', modifiers: 2, key: 'Control', code: 'ControlLeft', windowsVirtualKeyCode: 17, nativeVirtualKeyCode: 17 });
    await c.send('Input.dispatchKeyEvent', { type: 'rawKeyDown', modifiers: 2, key: 'c', code: 'KeyC', windowsVirtualKeyCode: 67, nativeVirtualKeyCode: 67 });
    await c.send('Input.dispatchKeyEvent', { type: 'keyUp', modifiers: 2, key: 'c', code: 'KeyC', windowsVirtualKeyCode: 67, nativeVirtualKeyCode: 67 });
    await c.send('Input.dispatchKeyEvent', { type: 'keyUp', modifiers: 0, key: 'Control', code: 'ControlLeft', windowsVirtualKeyCode: 17, nativeVirtualKeyCode: 17 });
    await new Promise(r => setTimeout(r, 200));
  }
  for (let i = 0; i < 2; i++) {
    await c.send('Input.dispatchKeyEvent', { type: 'rawKeyDown', modifiers: 0, key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 13 });
    await c.send('Input.dispatchKeyEvent', { type: 'keyUp', modifiers: 0, key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 13 });
    await new Promise(r => setTimeout(r, 250));
  }
  const crypto = require('crypto');
  const md5 = crypto.createHash('md5').update(Buffer.from(script, 'utf8')).digest('hex');
  const cmd = `echo ${b64} | base64 -d > ${remotePath}; echo MD5 $(md5sum ${remotePath} | cut -c1-32) LOCAL ${md5}; ${runner} ${remotePath}\n`;
  const skipped = await typeText(c, cmd, Number(process.env.TYPE_DELAY || 30));
  // 补发回车，防止最后一次 Enter 丢失导致命令未执行
  await new Promise(r => setTimeout(r, 400));
  for (let i = 0; i < 2; i++) {
    await c.send('Input.dispatchKeyEvent', { type: 'rawKeyDown', modifiers: 0, key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 13 });
    await c.send('Input.dispatchKeyEvent', { type: 'keyUp', modifiers: 0, key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 13 });
    await new Promise(r => setTimeout(r, 400));
  }
  console.log('PUSHED ' + localPath + ' -> ' + remotePath + ' (' + b64.length + ' b64 chars, cmd ' + cmd.length + ')' + (skipped.length ? ' SKIPPED=' + JSON.stringify(skipped) : ''));
  c.close(); process.exit(0);
})();
