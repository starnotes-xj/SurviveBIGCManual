#!/usr/bin/env node
'use strict';
// ai1-shot.js —— ai1 专用 noVNC 截图：强制 deviceScaleFactor=1，保证 1 像素=1 像素，字形不失真
// 用法: node ai1-shot.js <pageMatch> <outPng> [--scale 2]
const argv = process.argv.slice(2);
const flags = {};
const pos = [];
for (let i = 0; i < argv.length; i++) {
  if (argv[i].startsWith('--')) { flags[argv[i].slice(2)] = argv[i + 1]; i++; }
  else pos.push(argv[i]);
}
const pageMatch = pos[0], outPath = pos[1];
const scale = Number(flags.scale || 2);
const base = 'http://127.0.0.1:9222';
const fs = require('fs');
function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let id = 0; const pending = new Map();
    ws.addEventListener('message', ev => {
      let msg; try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id); pending.delete(msg.id);
        msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
      }
    });
    ws.addEventListener('error', () => reject(new Error('ws fail')));
    ws.addEventListener('open', () => resolve({
      send(m, p) { return new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); },
      close() { try { ws.close(); } catch {} }
    }));
  });
}
async function evalExpr(c, expression) {
  const r = await c.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) throw new Error('eval: ' + JSON.stringify(r.exceptionDetails).slice(0, 200));
  return r.result ? r.result.value : undefined;
}
(async () => {
  const list = await (await fetch(base + '/json/list')).json();
  const pages = list.filter(t => t.type === 'page' && (t.url || '').includes(pageMatch));
  if (!pages.length) { console.error('no page ' + pageMatch); process.exit(1); }
  const c = await connect(pages[0].webSocketDebuggerUrl);
  await c.send('Page.enable');
  // 关键：dpr 固定为 1，画布区域 1024x768 完整落在视口内
  await c.send('Emulation.setDeviceMetricsOverride', { width: 1760, height: 1240, deviceScaleFactor: 1, mobile: false });
  await new Promise(r => setTimeout(r, 700));
  const info = await evalExpr(c, `(() => {
    const cv = document.querySelector('canvas');
    if (!cv) return null;
    // 关掉 noVNC 的 scaleViewport，避免画布被缩放填满 -> 字形失真
    let node = cv.parentElement, depth = 0, rfb = null;
    while (node && depth++ < 20) { const v = node.__vue__; if (v && v.rfb) { rfb = v.rfb; break; } node = node.parentElement; }
    if (rfb) { try { rfb._scaleViewport = false; rfb._clipViewport = false; } catch (e) { } }
    [...document.querySelectorAll('div,header,nav')].forEach(el => {
      const t = (el.className || '') + '';
      if (/vncoperate|commonmodeltitle|ant-layout-header|head_title/.test(t) && el.getBoundingClientRect().height < 130) el.style.display = 'none';
    });
    const box = cv.closest('.novnc_canvas') || cv.parentElement;
    if (box) { box.style.overflow = 'visible'; }
    cv.style.width = cv.width + 'px';
    cv.style.height = cv.height + 'px';
    cv.style.imageRendering = 'pixelated';
    window.scrollTo(0, 0);
    // 清零所有祖先滚动容器，避免画布顶部被视口裁掉（否则解码网格会错位）
    let el = cv;
    while (el) { if (el.scrollTop) el.scrollTop = 0; if (el.scrollLeft) el.scrollLeft = 0; el = el.parentElement; }
    const b = cv.getBoundingClientRect();
    return { x: Math.max(0, Math.round(b.x)), y: Math.max(0, Math.round(b.y)), w: cv.width, h: cv.height, rw: Math.round(b.width), rh: Math.round(b.height), dpr: window.devicePixelRatio, vw: window.innerWidth, vh: window.innerHeight, scaled: rfb ? rfb._scaleViewport : 'no-rfb' };
  })()`);
  if (!info) { console.error('no canvas'); process.exit(1); }
  // 稳定后重新测量一次（防止样式生效后画布位移）
  await new Promise(r => setTimeout(r, 600));
  const info2 = await evalExpr(c, `(() => {
    const cv = document.querySelector('canvas');
    if (!cv) return null;
    window.scrollTo(0, 0);
    const b = cv.getBoundingClientRect();
    return { x: Math.max(0, Math.round(b.x)), y: Math.max(0, Math.round(b.y)), rw: Math.round(b.width), rh: Math.round(b.height) };
  })()`);
  const rect = info2 || info;
  const res = await c.send('Page.captureScreenshot', { format: 'png', clip: { x: rect.x, y: rect.y, width: info.w, height: info.h, scale } });
  fs.writeFileSync(outPath, Buffer.from(res.data, 'base64'));
  console.log('AI1SHOT ' + outPath + ' fb=' + info.w + 'x' + info.h + ' at=' + rect.x + ',' + rect.y + ' cssRect=' + rect.rw + 'x' + rect.rh + ' dpr=' + info.dpr + ' vp=' + info.vw + 'x' + info.vh);
  c.close(); process.exit(0);
})();
