param([Parameter(Mandatory=$true)][string]$Png)
Add-Type -AssemblyName System.Drawing
$b = [System.Drawing.Bitmap]::FromFile($Png)
$W = $b.Width; $H = $b.Height
$rowInk = New-Object 'int[]' $H
$colInk = New-Object 'int[]' $W
for ($y = 0; $y -lt $H; $y++) {
  $c = 0
  for ($x = 0; $x -lt $W; $x += 2) {
    $p = $b.GetPixel($x, $y); $l = [int](($p.R + $p.G + $p.B) / 3)
    if ($l -gt 100) { $c++ }
  }
  $rowInk[$y] = $c
}
for ($x = 0; $x -lt $W; $x++) {
  $c = 0
  for ($y = 0; $y -lt $H; $y += 2) {
    $p = $b.GetPixel($x, $y); $l = [int](($p.R + $p.G + $p.B) / 3)
    if ($l -gt 100) { $c++ }
  }
  $colInk[$x] = $c
}
$b.Dispose()
Write-Output ("size=" + $W + "x" + $H)
# 文本行起点
$starts = @()
$inLine = $false
for ($y = 0; $y -lt $H; $y++) {
  if ($rowInk[$y] -gt 3 -and -not $inLine) { $inLine = $true; $starts += $y }
  elseif ($rowInk[$y] -le 3 -and $inLine) { $inLine = $false }
}
Write-Output ("lineStarts=" + (($starts | Select-Object -First 14) -join ','))
if ($starts.Count -ge 3) {
  $d = @()
  for ($i = 1; $i -lt $starts.Count; $i++) { $d += ($starts[$i] - $starts[$i - 1]) }
  $d = $d | Sort-Object
  Write-Output ("linePitch median=" + $d[[int]($d.Count / 2)] + " all=" + (($d | Select-Object -First 12) -join ','))
}
# 列自相关（找字符水平间距）
$bestLag = 0; $bestScore = -1
for ($lag = 4; $lag -le 80; $lag++) {
  $s = 0
  for ($x = 0; $x -lt ($W - $lag); $x++) { $s += [math]::Min($colInk[$x], $colInk[$x + $lag]) }
  if ($s -gt $bestScore) { $bestScore = $s; $bestLag = $lag }
}
Write-Output ("colPitch autocorr best lag=" + $bestLag + " score=" + $bestScore)
# 前若干列的 ink 分布（每列一个字符，0-9）
$line = ''
foreach ($x in 0..([math]::Min(160, $W - 1))) { $v = $colInk[$x]; $line += if ($v -eq 0) { '.' } elseif ($v -lt 3) { '-' } else { '#' } }
Write-Output ("colProfile[0..160]=" + $line)
