#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""20-screen-ocr.py —— 用 RapidOCR(PP-OCR) 读 VNC 截图上的屏幕文字（离线、无需云 Key）

比 ddddocr 强得多（ddddocr 是验证码模型，桌面文本基本读不出）。

用法：
  python 20-screen-ocr.py <png> [--crop x,y,w,h] [--scale 1.5] [--json out.json] [--txt out.txt]
  python 20-screen-ocr.py <png> --right  -> 只读右侧工具条区域（CSS x>=1050）
输出：按 y 排序的文本行（每行带坐标），JSON/TXT 可选落盘。
"""
import argparse
import json
import sys

from PIL import Image

try:
    from rapidocr_onnxruntime import RapidOCR
except Exception as e:  # pragma: no cover
    print("rapidocr 不可用: %s" % e, file=sys.stderr)
    raise


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("png")
    ap.add_argument("--crop", default="")
    ap.add_argument("--scale", type=float, default=1.5)
    ap.add_argument("--json", default="")
    ap.add_argument("--txt", default="")
    ap.add_argument("--min-score", type=float, default=0.4)
    args = ap.parse_args()

    im = Image.open(args.png).convert("RGB")
    if args.crop:
        x, y, w, h = [int(v) for v in args.crop.split(",")]
        im = im.crop((x, y, x + w, y + h))
    if args.scale and args.scale != 1:
        im = im.resize((int(im.width * args.scale), int(im.height * args.scale)), Image.LANCZOS)

    engine = RapidOCR()
    result, elapse = engine(im)
    lines = []
    for item in (result or []):
        box, text, score = item[0], item[1], float(item[2])
        if score < args.min_score:
            continue
        xs = [p[0] for p in box]
        ys = [p[1] for p in box]
        lines.append({
            "x": int(min(xs) / args.scale), "y": int(min(ys) / args.scale),
            "w": int((max(xs) - min(xs)) / args.scale), "h": int((max(ys) - min(ys)) / args.scale),
            "score": round(score, 3), "text": text,
        })
    lines.sort(key=lambda l: (l["y"] // 12, l["x"]))
    out = {"file": args.png, "count": len(lines), "lines": lines}
    for l in lines:
        print("[%4d,%4d] %s" % (l["x"], l["y"], l["text"]))
    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False, indent=1)
    if args.txt:
        with open(args.txt, "w", encoding="utf-8") as f:
            for l in lines:
                f.write("[%4d,%4d] %s\n" % (l["x"], l["y"], l["text"]))


if __name__ == "__main__":
    main()
