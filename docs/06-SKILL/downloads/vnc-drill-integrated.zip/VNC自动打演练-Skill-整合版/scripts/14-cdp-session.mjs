#!/usr/bin/env node
// 14-cdp-session.mjs —— 从「带 CDP 的 Chrome」导出平台会话：HttpOnly Cookie + localStorage token
//
// 为什么需要它（第 7 轮踩到的坑）：
//   12-cdp-token.js 只能看到 document.cookie（HttpOnly 的会话 Cookie 读不到），而平台接口
//   在「token + 会话 Cookie」同时具备时才认；只带 token 会得到 401「账号已在其他地方登录」。
//   本脚本用 CDP 的 Network.getAllCookies 把 HttpOnly Cookie 一起取出来，形成完整的 HTTP 通道。
//
// 用法：
//   node 14-cdp-session.mjs [--port 9222] [--out <dir>] [--match tp.qianxin.com] [--validate]
// 产物（--out 目录下）：
//   token.txt          纯 token（供 10-plat-api.mjs 使用）
//   cookies.txt        Netscape 格式 Cookie 文件（含 HttpOnly）
//   cookie-header.txt  可直接作为 HTTP `Cookie:` 头的单行字符串
//   session.json       会话元信息（token 只留指纹，cookie 值只留指纹）
// 退出码：0 取到 token  2 页面未登录（无 token）  3 CDP/页面不可用
import fs from 'node:fs';
import path from 'node:path';

const argv = process.argv.slice(2);
const opt = (n, d) => { const i = argv.indexOf('--' + n); return i >= 0 ? argv[i + 1] : d; };
const flag = (n) => argv.includes('--' + n);

const PORT = opt('port', '9222');
const OUT = path.resolve(opt('out', '.'));
const MATCH = opt('match', 'tp.qianxin.com');
const DO_VALIDATE = flag('validate');
fs.mkdirSync(OUT, { recursive: true });

const fp = (v) => (v ? String(v).slice(0, 4) + '…' + String(v).slice(-4) : '');

async function getJson(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + url);
  return r.json();
}

class Cdp {
  constructor(wsUrl) { this.wsUrl = wsUrl; this.seq = 0; this.pending = new Map(); }
  connect() {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(this.wsUrl);
      this.ws = ws;
      const to = setTimeout(() => reject(new Error('CDP websocket 连接超时')), 8000);
      ws.onopen = () => { clearTimeout(to); resolve(); };
      ws.onerror = () => { clearTimeout(to); reject(new Error('CDP websocket 连接失败')); };
      ws.onmessage = (ev) => {
        let m; try { m = JSON.parse(ev.data); } catch { return; }
        if (m.id && this.pending.has(m.id)) {
          const p = this.pending.get(m.id); this.pending.delete(m.id);
          if (m.error) p.reject(new Error(JSON.stringify(m.error))); else p.resolve(m.result);
        }
      };
    });
  }
  send(method, params = {}) {
    const id = ++this.seq;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params }));
      setTimeout(() => { if (this.pending.has(id)) { this.pending.delete(id); reject(new Error('CDP 超时: ' + method)); } }, 20000);
    });
  }
  close() { try { this.ws.close(); } catch { } }
}

const report = { at: new Date().toISOString(), port: PORT, out: OUT, pages: [], cookieNames: [], tokenLen: 0, tokenFingerprint: '', validated: null };

try {
  const list = await getJson(`http://127.0.0.1:${PORT}/json/list`);
  report.pages = list.filter(t => t.type === 'page').map(t => ({ title: t.title, url: t.url }));
  const pages = list.filter(t => t.type === 'page' && (t.url || '').includes(MATCH) && t.webSocketDebuggerUrl);
  const page = pages.find(t => /dril-web|dril\b/.test(t.url)) || pages[0] || list.find(t => t.type === 'page' && t.webSocketDebuggerUrl);
  if (!page) { console.error('FAIL: 没有可用的 page target（浏览器没开页面？）'); process.exit(3); }
  console.log('# target: ' + (page.title || '') + '  ' + page.url);

  const cdp = new Cdp(page.webSocketDebuggerUrl);
  await cdp.connect();
  await cdp.send('Network.enable');

  // ---- 1) 全部 Cookie（含 HttpOnly），过滤平台域
  const ck = await cdp.send('Network.getAllCookies');
  const cookies = (ck.cookies || []).filter(c => String(c.domain || '').includes('qianxin.com'));
  report.cookieNames = cookies.map(c => c.name + '@' + c.domain);
  const header = cookies.map(c => c.name + '=' + c.value).join('; ');
  const netscape = ['# Netscape HTTP Cookie File', '# 由 14-cdp-session.mjs 从 CDP 导出 ' + report.at]
    .concat(cookies.map(c => [c.domain, c.domain.startsWith('.') ? 'TRUE' : 'FALSE', c.path || '/', c.secure ? 'TRUE' : 'FALSE', c.expires && c.expires > 0 ? Math.floor(c.expires) : 0, c.name, c.value].join('\t')))
    .join('\n') + '\n';

  // ---- 2) localStorage 里的 token（递归找长 token 串）
  const expr = `(()=>{const hit=(s)=>{try{const o=JSON.parse(s);const st=[o];const seen=new Set();while(st.length){const c=st.pop();if(!c||typeof c!=='object'||seen.has(c))continue;seen.add(c);for(const k of Object.keys(c)){const v=c[k];if(typeof v==='string'&&v.length>=80&&/^[A-Za-z0-9_\\-]+$/.test(v)&&/token/i.test(k))return v;if(v&&typeof v==='object')st.push(v)}}}catch(e){}return ''};
    for(const k of Object.keys(localStorage)){const v=localStorage.getItem(k)||'';const t=hit(v);if(t)return JSON.stringify({key:k,token:t})}
    return ''})()`;
  const ev = await cdp.send('Runtime.evaluate', { expression: expr, returnByValue: true });
  let token = '', tokenKey = '';
  try { const o = JSON.parse(ev.result.value || '{}'); token = o.token || ''; tokenKey = o.key || ''; } catch { }

  // ---- 3) 落盘
  if (token) fs.writeFileSync(path.join(OUT, 'token.txt'), token, 'utf8');
  fs.writeFileSync(path.join(OUT, 'cookies.txt'), netscape, 'utf8');
  fs.writeFileSync(path.join(OUT, 'cookie-header.txt'), header, 'utf8');
  report.tokenLen = token.length;
  report.tokenFingerprint = fp(token);
  report.tokenKey = tokenKey;
  report.cookieHeaderLen = header.length;

  // ---- 4) 可选：用 token + Cookie 走一次纯 HTTP，验证通道
  if (DO_VALIDATE) {
    const r = await fetch('https://tp.qianxin.com/user/auth/authList', {
      method: 'POST',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'X-Requested-With': 'XMLHttpRequest',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Referer': 'https://tp.qianxin.com/',
        'Origin': 'https://tp.qianxin.com',
        'token': token,
        ...(header ? { Cookie: header } : {}),
      },
      body: 'page=1',
    });
    const text = await r.text();
    let json = null; try { json = JSON.parse(text); } catch { }
    report.validated = { status: r.status, code: json && json.code, msg: json && json.msg, len: text.length, head: text.slice(0, 120) };
  }

  fs.writeFileSync(path.join(OUT, 'session.json'), JSON.stringify(report, null, 1), 'utf8');
  console.log(JSON.stringify({
    page: page.url, cookieNames: report.cookieNames, cookieCount: cookies.length,
    tokenKey, tokenLen: report.tokenLen, tokenFingerprint: report.tokenFingerprint,
    files: ['token.txt', 'cookies.txt', 'cookie-header.txt', 'session.json'], validated: report.validated,
  }, null, 1));
  cdp.close();
  process.exit(token ? 0 : 2);
} catch (e) {
  console.error('FAIL: ' + e.message);
  process.exit(3);
}
