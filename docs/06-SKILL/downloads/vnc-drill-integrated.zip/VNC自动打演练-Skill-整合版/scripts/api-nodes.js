(async () => {
  const token = JSON.parse(localStorage.getItem('userStore') || '{}').userConfig.auth.token;
  const body = 'dark=1&view=1&module=drill&type_=taskdrill&sourceid=5ab4a224-a0d3-49bf-9f1a-7ced2124007b&planid=235';
  const post = async (path, b) => {
    const r = await fetch(path, {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', token },
      body: b || body
    });
    const t = await r.text();
    return t.slice(0, 30000);
  };
  const out = {};
  out.nodelist = await post('/domain/domain/nodelist');
  out.gettopo = await post('/domain/domain/gettopo');
  return JSON.stringify(out);
})()
