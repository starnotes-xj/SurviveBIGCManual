(async () => {
  const token = JSON.parse(localStorage.getItem('userStore') || '{}').userConfig.auth.token;
  const post = async (path, obj) => {
    const r = await fetch(path, {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', token },
      body: new URLSearchParams(obj).toString()
    });
    return (await r.text()).slice(0, 3000);
  };
  const out = {};
  const base = {
    module: 'drill', type_: 'taskdrill',
    sourceid: '5ab4a224-a0d3-49bf-9f1a-7ced2124007b', planid: '235'
  };
  const dev = {
    'WEB-DMZ': '71e5aa98-b927-40f5-8674-152d965918b2',
    'DB-SRV': 'ad6e292e-aac9-4af4-83bb-f4b235a62c13',
    'EVIDENCE': '62dc5a11-683e-4a3d-b327-f8529566e422',
    'PC-HR': 'f1c45227-c724-4a2d-949f-081f77911e68',
    'DC-FILE': '8739c695-9095-4c29-bc8c-3988bca5b485'
  };
  for (const [name, uuid] of Object.entries(dev)) {
    for (const proto of ['vnc']) {
      const body = Object.assign({}, base, { domainuuid: uuid, protocol: proto, uuid, deviceName: name, type: proto });
      out[name + '/' + proto] = await post('/domain/domain/console', body);
    }
  }
  return JSON.stringify(out, null, 1);
})()
