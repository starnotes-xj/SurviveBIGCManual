#!/usr/bin/env node
'use strict';
// cdp.js —— 通过 Chrome DevTools Protocol 读取/操作一个带 --remote-debugging-port 的浏览器实例
// 依赖：Node 22+（内置 WebSocket，无需 ws 包）
//
// 用法：
//   node cdp.js list                                       列出可操作的页面
//   node cdp.js text   [--match tp.qianxin.com] [--port 9222]      打印页面可见文本
//   node cdp.js html   [--match ...]                       打印页面 HTML
//   node cdp.js eval "<js 表达式>"                          在页面里求值（支持 await）
//   node cdp.js click "<文本>"                              点击文本匹配的元素
//   node cdp.js type  "<文本>"                              向当前焦点输入文本（Web 终端用）
//   node cdp.js key   Enter                                 发送按键
//   node cdp.js nav   "<url>"                               页面跳转

const argv = process.argv.slice(2);
function opt(name, def) {
  const i = argv.indexOf('--' + name);
  if (i >= 0) { const v = argv[i + 1]; argv.splice(i, 2); return v; }
  return def;
}
const port = opt('port', '9222');
const match = opt('match', '');
const idxArg = opt('idx', '');
const cmd = argv[0] || 'text';
const arg = argv.slice(1).join(' ');

const base = `http://127.0.0.1:${port}`;

async function targets() {
  const r = await fetch(base + '/json/list');
  if (!r.ok) throw new Error('CDP 返回 HTTP ' + r.status);
  return r.json();
}

function pick(list) {
  const pages = list.filter(t => t.type === 'page' && t.webSocketDebuggerUrl);
  if (!pages.length) throw new Error('没有 page target（浏览器没开页面？）');
  if (idxArg !== '') {
    const i = Number(idxArg);
    if (!Number.isInteger(i) || i < 0 || i >= pages.length) throw new Error(`--idx ${idxArg} 越界（共 ${pages.length} 个 page）`);
    return pages[i];
  }
  if (match) {
    const hit = pages.find(t => (t.url || '').includes(match));
    if (hit) return hit;
    throw new Error('没有页面 URL 含 "' + match + '"，当前页面：\n' + pages.map((p, i) => `  [${i}] ${p.url}`).join('\n'));
  }
  return pages[0];
}

function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let id = 0;
    const pending = new Map();
    ws.addEventListener('message', ev => {
      let msg; try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id);
        pending.delete(msg.id);
        msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
      }
    });
    ws.addEventListener('error', () => reject(new Error('WebSocket 连接失败: ' + wsUrl)));
    ws.addEventListener('open', () => resolve({
      send(method, params) {
        return new Promise((res, rej) => {
          const myId = ++id;
          pending.set(myId, { res, rej });
          ws.send(JSON.stringify({ id: myId, method, params: params || {} }));
        });
      },
      close() { try { ws.close(); } catch {} }
    }));
  });
}

async function evalExpr(c, expression) {
  const r = await c.send('Runtime.evaluate', {
    expression, returnByValue: true, awaitPromise: true, userGesture: true
  });
  if (r.exceptionDetails) {
    const d = r.exceptionDetails;
    throw new Error('页面求值异常: ' + ((d.exception && d.exception.description) || d.text || JSON.stringify(d)));
  }
  return r.result ? r.result.value : undefined;
}

(async () => {
  try {
    if (cmd === 'list') {
      const list = await targets();
      for (const t of list) {
        console.log(`[${t.type}] ${t.title || ''}\n    ${t.url}`);
      }
      return;
    }

    if (cmd === 'newtab') {
      const v = await (await fetch(base + '/json/version')).json();
      const bc = await connect(v.webSocketDebuggerUrl);
      const r = await bc.send('Target.createTarget', { url: arg });
      bc.close();
      console.log('NEWTAB: ' + (r && r.targetId) + '  ' + arg);
      return;
    }

    const t = pick(await targets());
    console.log(`# target: ${t.title || ''}  ${t.url}\n`);
    const c = await connect(t.webSocketDebuggerUrl);

    let out;
    if (cmd === 'text') {
      out = await evalExpr(c, `(() => {
        const b = document.body ? document.body.innerText : '';
        const f = [...document.querySelectorAll('iframe')].map(f => {
          try { return f.contentDocument ? f.contentDocument.body.innerText : '(跨域 iframe)'; } catch (e) { return '(跨域 iframe)'; }
        }).join('\\n--- iframe ---\\n');
        return b + (f ? '\\n--- iframes ---\\n' + f : '');
      })()`);
    } else if (cmd === 'html') {
      out = await evalExpr(c, 'document.documentElement.outerHTML');
    } else if (cmd === 'eval') {
      out = await evalExpr(c, arg);
    } else if (cmd === 'evalfile') {
      // 从文件读 JS 再求值 —— 避开 PowerShell 5.1 传参吃掉引号/反斜杠的问题
      const fs = require('fs');
      out = await evalExpr(c, fs.readFileSync(arg, 'utf8'));
    } else if (cmd === 'evalenv') {
      // 读 JS 文件，把 __PLAT_USER__ / __PLAT_PW__ / __PLAT_CODE__ 替换为环境变量值（凭据不落盘）
      const fs = require('fs');
      const esc = s => String(s == null ? '' : s).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n/g, '\\n');
      const raw = fs.readFileSync(arg, 'utf8');
      const code = raw
        .replace(/__PLAT_USER__/g, esc(process.env.PLAT_USER))
        .replace(/__PLAT_PW__/g, esc(process.env.PLAT_PW))
        .replace(/__PLAT_CODE__/g, esc(process.env.PLAT_CODE));
      out = await evalExpr(c, code);
    } else if (cmd === 'click') {
      out = await evalExpr(c, `(() => {
        const T = ${JSON.stringify(arg)};
        const els = [...document.querySelectorAll('a,button,li,span,div,td,label,input')];
        let cand = els.filter(e => ((e.innerText || e.value || '').trim() === T));
        if (!cand.length) cand = els.filter(e => ((e.innerText || '').includes(T)));
        if (!cand.length) return 'NOT_FOUND: ' + T;
        const el = cand[cand.length - 1];
        el.scrollIntoView({ block: 'center' });
        el.click();
        return 'CLICKED: ' + el.tagName + ' "' + ((el.innerText || el.value || '').trim().slice(0, 80)) + '"';
      })()`);
    } else if (cmd === 'type') {
      await c.send('Input.insertText', { text: arg });
      out = 'TYPED: ' + arg;
    } else if (cmd === 'key') {
      const k = arg || 'Enter';
      const map = { Enter: 13, Tab: 9, Escape: 27, Backspace: 8 };
      const code = map[k] || 13;
      await c.send('Input.dispatchKeyEvent', { type: 'keyDown', windowsVirtualKeyCode: code, nativeVirtualKeyCode: code, key: k, code: k });
      if (k.length === 1) await c.send('Input.dispatchKeyEvent', { type: 'char', text: k });
      await c.send('Input.dispatchKeyEvent', { type: 'keyUp', windowsVirtualKeyCode: code, nativeVirtualKeyCode: code, key: k, code: k });
      out = 'KEY: ' + k;
    } else if (cmd === 'mclick' || cmd === 'rclick') {
      // 真实鼠标事件（mclick 左键 / rclick 右键），坐标用页面 CSS 像素
      const [x, y] = arg.split(',').map(Number);
      const button = cmd === 'rclick' ? 'right' : 'left';
      await c.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y, button: 'none', clickCount: 0 });
      await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button, clickCount: 1 });
      await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button, clickCount: 1 });
      out = (cmd === 'rclick' ? 'RCLICK ' : 'MCLICK ') + x + ',' + y;
    } else if (cmd === 'nav') {
      await c.send('Page.enable');
      await c.send('Page.navigate', { url: arg });
      out = 'NAV: ' + arg;
    } else if (cmd === 'shot') {
      // 用法: node cdp.js shot <输出png> [--selector "#id"] [--clip "x,y,w,h"] [--scale 3] [--full 1] [--wait 800]
      const fs = require('fs');
      const selector = opt('selector', '');
      const clipArg = opt('clip', '');
      const scale = Number(opt('scale', '2'));
      const full = opt('full', '');
      const wait = Number(opt('wait', '600'));
      await c.send('Page.enable');
      if (wait) await new Promise(r => setTimeout(r, wait));
      let clip = null;
      if (selector) {
        const r = await evalExpr(c, `(() => {
          const el = document.querySelector(${JSON.stringify(selector)});
          if (!el) return null;
          const b = el.getBoundingClientRect();
          return { x: b.x, y: b.y, width: b.width, height: b.height };
        })()`);
        if (!r || !r.width) throw new Error('选择器没找到可见元素: ' + selector);
        clip = { x: Math.max(0, Math.floor(r.x) - 4), y: Math.max(0, Math.floor(r.y) - 4), width: Math.ceil(r.width) + 8, height: Math.ceil(r.height) + 8, scale };
      } else if (clipArg) {
        const [x, y, w, h] = clipArg.split(',').map(Number);
        clip = { x, y, width: w, height: h, scale };
      }
      const params = { format: 'png' };
      if (clip) params.clip = clip;
      if (full) params.captureBeyondViewport = true;
      const res = await c.send('Page.captureScreenshot', params);
      fs.writeFileSync(arg, Buffer.from(res.data, 'base64'));
      out = 'SHOT: ' + arg + (clip ? ` clip=${JSON.stringify(clip)}` : ' (viewport)');
    } else {
      throw new Error('未知命令: ' + cmd);
    }

    c.close();
    if (out !== undefined && out !== null) console.log(out);
  } catch (e) {
    console.error('ERR: ' + e.message);
    process.exit(1);
  }
})();
