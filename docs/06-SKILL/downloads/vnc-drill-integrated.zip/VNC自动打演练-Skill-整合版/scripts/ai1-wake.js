#!/usr/bin/env node
'use strict';
// ai1-wake.js —— 唤醒空闲黑屏的 VNC 会话：只移动鼠标（不点击），可选发送一个无害按键
// 用法: node ai1-wake.js <pageMatch> [--key Shift|Enter|none] [--click 0|1]
const argv = process.argv.slice(2);
const flags = {};
const pos = [];
for (let i = 0; i < argv.length; i++) {
  if (argv[i].startsWith('--')) { flags[argv[i].slice(2)] = argv[i + 1]; i++; }
  else pos.push(argv[i]);
}
const pageMatch = pos[0];
const base = 'http://127.0.0.1:9222';
function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let id = 0; const pending = new Map();
    ws.addEventListener('message', ev => {
      let msg; try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id); pending.delete(msg.id);
        msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
      }
    });
    ws.addEventListener('error', () => reject(new Error('ws fail')));
    ws.addEventListener('open', () => resolve({
      send(m, p) { return new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); },
      close() { try { ws.close(); } catch {} }
    }));
  });
}
async function evalExpr(c, expression) {
  const r = await c.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) throw new Error('eval: ' + JSON.stringify(r.exceptionDetails).slice(0, 200));
  return r.result ? r.result.value : undefined;
}
(async () => {
  const list = await (await fetch(base + '/json/list')).json();
  const pages = list.filter(t => t.type === 'page' && (t.url || '').includes(pageMatch));
  if (!pages.length) { console.error('no page ' + pageMatch); process.exit(1); }
  const c = await connect(pages[0].webSocketDebuggerUrl);
  const rect = await evalExpr(c, `(() => { const cv=document.querySelector('canvas'); if(!cv) return null; const b=cv.getBoundingClientRect(); return {x:Math.round(b.x+b.width/2), y:Math.round(b.y+b.height/2)}; })()`);
  if (!rect) { console.error('no canvas'); process.exit(1); }
  for (let i = 0; i < 3; i++) {
    await c.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: rect.x + i, y: rect.y + i, button: 'none' });
    await new Promise(r => setTimeout(r, 250));
  }
  if (flags.click === '1') {
    await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: rect.x, y: rect.y, button: 'left', clickCount: 1 });
    await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: rect.x, y: rect.y, button: 'left', clickCount: 1 });
  }
  const k = flags.key || 'none';
  if (k !== 'none') {
    const map = { Shift: ['Shift', 'ShiftLeft', 16], Enter: ['Enter', 'Enter', 13], Control: ['Control', 'ControlLeft', 17] };
    const [key, code, kc] = map[k] || map.Shift;
    await c.send('Input.dispatchKeyEvent', { type: 'rawKeyDown', modifiers: 0, key, code, windowsVirtualKeyCode: kc, nativeVirtualKeyCode: kc });
    await c.send('Input.dispatchKeyEvent', { type: 'keyUp', modifiers: 0, key, code, windowsVirtualKeyCode: kc, nativeVirtualKeyCode: kc });
  }
  console.log('WAKE sent to ' + pageMatch + ' (mouse move' + (flags.click === '1' ? '+click' : '') + ', key=' + k + ')');
  c.close(); process.exit(0);
})();
