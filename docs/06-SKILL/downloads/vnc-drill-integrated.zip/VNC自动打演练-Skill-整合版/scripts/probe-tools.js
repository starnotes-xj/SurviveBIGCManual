(async () => {
  const out = {};
  let open = document.querySelector('#class-item-dialog .ant-drawer-open');
  if (!open) {
    const i = document.querySelector('.icon-icon_importingfiles');
    if (i) (i.parentElement || i).click();
    await new Promise(r => setTimeout(r, 2500));
    open = document.querySelector('#class-item-dialog .ant-drawer-open');
  }
  out.drawerOpen = !!open;
  const rows = [...document.querySelectorAll('#class-item-dialog tr')].map(tr => ({
    txt: (tr.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 130),
    btns: [...tr.querySelectorAll('button,a,i')].map(b => (b.innerText || '').trim()).filter(Boolean).slice(0, 5)
  }));
  out.rowCount = rows.length;
  out.rows = rows.slice(0, 30);
  return JSON.stringify(out, null, 1);
})()
