param(
  [Parameter(Mandatory=$true)][string]$Sh,
  [int]$Wait = 8,
  [string]$Tag = 'ai1',
  [string]$Page = 'ad6e292e-aac9-4af4-83bb-f4b235a62c13',
  [string]$Map = 'glyphmap-db.json'
)
$ErrorActionPreference = 'Stop'
$scripts = $PSScriptRoot
$root = Split-Path $scripts -Parent
$png = Join-Path $root ($Tag + '.png')
Write-Output ('--- PUSH ' + $Sh + ' -> page ' + $Page)
node (Join-Path $scripts 'pushsh.js') $Page $Sh '/tmp/g.sh' 'bash'
Start-Sleep -Seconds $Wait
node (Join-Path $scripts 'ai1-shot.js') $Page $png --scale 2
Write-Output '--- SCREEN'
& (Join-Path $scripts 'glyph.ps1') -Png $png -MapPath (Join-Path $scripts $Map)
