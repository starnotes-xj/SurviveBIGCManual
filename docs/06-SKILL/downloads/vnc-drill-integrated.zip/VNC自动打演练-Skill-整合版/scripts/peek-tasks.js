#!/usr/bin/env node
'use strict';
// peek-tasks.js —— 后台标签页逐个场景统计题目完成情况（不抢焦点）
const base = 'http://127.0.0.1:9222';
const URL_TASKS = 'https://tp.qianxin.com/static/drl-placeholder';
function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let id = 0; const pending = new Map();
    ws.addEventListener('message', ev => {
      let msg; try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id); pending.delete(msg.id);
        msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
      }
    });
    ws.addEventListener('error', () => reject(new Error('ws fail')));
    ws.addEventListener('open', () => resolve({
      send(m, p) { return new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); },
      close() { try { ws.close(); } catch {} }
    }));
  });
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function evalOn(c, expression) {
  const r = await c.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) return 'ERR:' + JSON.stringify(r.exceptionDetails).slice(0, 200);
  return r.result ? r.result.value : null;
}
const EXTRACT = `(() => {
  const cards = [...document.querySelectorAll('*')].filter(e => e.children.length > 0 && /指定任务/.test(e.innerText||'') && (e.innerText||'').length < 160);
  const seen = new Set(); const list = [];
  for (const c of cards) {
    const t = (c.innerText||'').replace(/\\s+/g,' ').trim();
    if (seen.has(t) || t === '指定任务') continue; seen.add(t);
    const m = t.match(/指定任务\\s*(.*?)\\s*(\\d+)分\\s*\\/\\s*(\\d+)分/);
    if (m) list.push({q:m[1], got:Number(m[2]), total:Number(m[3])});
  }
  return JSON.stringify({done:list.filter(x=>x.got>0).map(x=>x.q+' ['+x.got+'/'+x.total+']'), doneCount:list.filter(x=>x.got>0).length, count:list.length, score:list.reduce((s,x)=>s+x.got,0), totalScore:list.reduce((s,x)=>s+x.total,0)});
})()`;
(async () => {
  const ver = await (await fetch(base + '/json/version')).json();
  const bc = await connect(ver.webSocketDebuggerUrl);
  const created = await bc.send('Target.createTarget', { url: 'about:blank', background: true });
  const tid = created.targetId;
  await sleep(600);
  const list = await (await fetch(base + '/json/list')).json();
  const t = list.find(x => x.id === tid);
  const c = await connect(t.webSocketDebuggerUrl);
  await c.send('Page.enable');
  await c.send('Page.navigate', { url: 'https://tp.qianxin.com/static/dril-web/#/index?uuid=5ab4a224-a0d3-49bf-9f1a-7ced2124007b&planid=235&navKey=3' });
  await sleep(9000);
  const scenarios = ['移动应用服务器应急响应溯源', '企业网应急溯源', 'APT 恶意样本深度分析'];
  for (const s of scenarios) {
    const clicked = await evalOn(c, `(() => {
      const el = [...document.querySelectorAll('span,div,li')].find(e => e.children.length === 0 && (e.innerText||'').trim() === ${JSON.stringify(s)});
      if (!el) return 'NOTFOUND';
      el.click(); return 'OK';
    })()`);
    await sleep(3500);
    const data = await evalOn(c, EXTRACT);
    console.log('===== ' + s + ' (' + clicked + ')');
    console.log(data);
  }
  c.close();
  await bc.send('Target.closeTarget', { targetId: tid });
  bc.close();
  process.exit(0);
})();
