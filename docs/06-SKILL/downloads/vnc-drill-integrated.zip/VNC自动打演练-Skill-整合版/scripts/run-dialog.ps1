param(
  [Parameter(Mandatory = $true)][string]$Cmd,
  [int]$Wait = 8,
  [string]$Tag = 'rd',
  [string]$Match = 'YJ-EVIDENCE'
)
# run-dialog.ps1 -- 通过 Win+R「运行」框执行命令。
#   不点击画布（避免把 Windows 被控机的控制台拖进 QuickEdit 的 Mark/选择模式导致吞键）
#   命令文本走文件传参（避免 PowerShell 把结尾反斜杠/内层引号吃掉）
# 用法: & '.\scripts\run-dialog.ps1' -Cmd 'dir D:\ & echo --- & dir C:\Temp' -Wait 7 -Tag cd1
# 说明: 实际执行的是 `cmd /k <Cmd>`，所以 <Cmd> 里可以用 cmd 的 & 串联、> 重定向。
$root = Split-Path -Parent $PSScriptRoot
$outDir = Join-Path $root 'out'
if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }
$env:PYTHONIOENCODING = 'utf-8'
$f = Join-Path $outDir "run-$Tag.txt"
[System.IO.File]::WriteAllText($f, "cmd /k $Cmd", (New-Object System.Text.UTF8Encoding($false)))

node "$root\scripts\16-vnc.mjs" key win+r --match $Match | Out-Null
Start-Sleep -Seconds 2
node "$root\scripts\16-vnc.mjs" typefile $f --match $Match --delay 30
node "$root\scripts\16-vnc.mjs" key enter --match $Match
Start-Sleep -Seconds $Wait
$png = Join-Path $outDir "scr-$Tag.png"
node "$root\scripts\16-vnc.mjs" shot $png --match $Match
python "$root\scripts\20-screen-ocr.py" $png --txt (Join-Path $outDir "ocr-$Tag.txt") 2>$null | Out-Null
Write-Host "OCR -> out\ocr-$Tag.txt (png: out\scr-$Tag.png)"
