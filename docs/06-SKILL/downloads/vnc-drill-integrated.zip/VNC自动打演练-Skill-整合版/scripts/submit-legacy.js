#!/usr/bin/env node
'use strict';
// submit.js —— 在演练任务页按题目文本提交答案
// 用法: node submit.js "<题目子串>" "<答案>"   （可重复调用）
const base = 'http://127.0.0.1:9222';
const Q = process.argv[2];
const A = process.argv[3];
function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let id = 0; const pending = new Map();
    ws.addEventListener('message', ev => {
      let msg; try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id); pending.delete(msg.id);
        msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
      }
    });
    ws.addEventListener('error', () => reject(new Error('ws fail')));
    ws.addEventListener('open', () => resolve({
      send(m, p) { return new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); },
      close() { try { ws.close(); } catch {} }
    }));
  });
}
async function ev(c, expression) {
  const r = await c.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true, userGesture: true });
  if (r.exceptionDetails) return 'ERR:' + JSON.stringify(r.exceptionDetails).slice(0, 300);
  return r.result ? r.result.value : null;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  const list = await (await fetch(base + '/json/list')).json();
  let page = list.find(t => t.type === 'page' && (t.url || '').includes('dril-web'));
  if (!page) { console.error('no drill page'); process.exit(1); }
  let c = await connect(page.webSocketDebuggerUrl);
  // 确保在演练任务页并选中企业网场景
  const step0 = await ev(c, `(async () => {
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    const nav = [...document.querySelectorAll('span,a,div,li')].filter(e => (e.innerText||'').trim() === '演练任务');
    if (nav.length) nav[nav.length-1].click();
    await sleep(2000);
    const sc = [...document.querySelectorAll('span,div,li')].filter(e => e.children.length === 0 && (e.innerText||'').trim() === '企业网应急溯源');
    if (sc.length) sc[0].click();
    await sleep(2000);
    return 'scene-ready:' + sc.length;
  })()`);
  console.log('step0 ' + step0);

  for (let i = 0; i < 60; i++) {
    const clicked = await ev(c, `(() => {
      const q = ${JSON.stringify(Q)};
      const cards = [...document.querySelectorAll('*')].filter(e => e.children.length > 0 && (e.innerText||'').includes('指定任务') && (e.innerText||'').includes(q) && (e.innerText||'').length < 260);
      if (!cards.length) return 'NOCARD';
      const el = cards[cards.length - 1];
      el.scrollIntoView({ block: 'center' });
      el.click();
      return 'CLICKED:' + (el.innerText||'').replace(/\\s+/g,' ').slice(0, 60);
    })()`);
    if (clicked === 'NOCARD') { console.log('attempt ' + i + ' NOCARD'); await sleep(2000); continue; }
    console.log(clicked);
    await sleep(1500);
    const detail = await ev(c, `(() => {
      const t = (document.body.innerText || '');
      const i = t.lastIndexOf('任务名称');
      return i >= 0 ? t.slice(i, i + 120).replace(/\\s+/g, ' ') : 'NO_DETAIL';
    })()`);
    console.log('detail ' + detail);
    if (process.argv.includes('--dry')) { c.close(); process.exit(0); }
    const filled = await ev(c, `(() => {
      const a = ${JSON.stringify(A)};
      const done = [...document.querySelectorAll('*')].some(e => (e.innerText||'').includes('已完成'));
      const ta = document.querySelector('textarea');
      if (!ta) return 'NO_INPUT';
      const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
      setter.call(ta, a);
      ta.dispatchEvent(new Event('input', { bubbles: true }));
      ta.dispatchEvent(new Event('change', { bubbles: true }));
      return 'FILLED:' + ta.value;
    })()`);
    console.log(filled);
    await sleep(500);
    const clickedSubmit = await ev(c, `(() => {
      const el = [...document.querySelectorAll('.btn-item-style')].find(b => (b.innerText||'').trim() === '提交');
      if (!el) return 'NO_BTN';
      el.click();
      return 'SUBMITTED';
    })()`);
    console.log(clickedSubmit);
    await sleep(3500);
    const after = await ev(c, `(() => {
      const msgs = [...document.querySelectorAll('.ant-message-notice, .ant-message, [class*=message]')].map(e => (e.innerText||'').replace(/\\s+/g,' ').trim()).filter(Boolean).slice(-4);
      const t = document.body.innerText || '';
      const i = t.indexOf(${JSON.stringify(Q)});
      const card = i >= 0 ? t.slice(Math.max(0, i - 40), i + 80).replace(/\\s+/g, ' ') : 'NA';
      return JSON.stringify({ msgs, card });
    })()`);
    console.log('after ' + after);
    break;
  }
  c.close();
  process.exit(0);
})();
