#!/usr/bin/env node
'use strict';
// ai1-winsend.js —— 向 Windows 靶机 VNC 盲打命令（支持 Win+R 打开运行框）
// 用法: node ai1-winsend.js <pageMatch> "<文本>" [--winr 1] [--enter 1] [--delay 15] [--click 1]
const argv = process.argv.slice(2);
const flags = {};
const pos = [];
for (let i = 0; i < argv.length; i++) {
  if (argv[i].startsWith('--')) { flags[argv[i].slice(2)] = argv[i + 1]; i++; }
  else pos.push(argv[i]);
}
const pageMatch = pos[0];
const text = pos.slice(1).join(' ');
const base = 'http://127.0.0.1:9222';
function connect(wsUrl) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    let id = 0; const pending = new Map();
    ws.addEventListener('message', ev => {
      let msg; try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.id && pending.has(msg.id)) {
        const { res, rej } = pending.get(msg.id); pending.delete(msg.id);
        msg.error ? rej(new Error(JSON.stringify(msg.error))) : res(msg.result);
      }
    });
    ws.addEventListener('error', () => reject(new Error('ws fail')));
    ws.addEventListener('open', () => resolve({
      send(m, p) { return new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); },
      close() { try { ws.close(); } catch {} }
    }));
  });
}
async function evalExpr(c, expression) {
  const r = await c.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) throw new Error('eval: ' + JSON.stringify(r.exceptionDetails).slice(0, 200));
  return r.result ? r.result.value : undefined;
}
const SHIFT_MAP = { '~': '`', '!': '1', '@': '2', '#': '3', '$': '4', '%': '5', '^': '6', '&': '7', '*': '8', '(': '9', ')': '0', '_': '-', '+': '=', '{': '[', '}': ']', '|': '\\', ':': ';', '"': "'", '<': ',', '>': '.', '?': '/' };
const PUNCT = { '`': ['Backquote', 192], '-': ['Minus', 189], '=': ['Equal', 187], '[': ['BracketLeft', 219], ']': ['BracketRight', 221], '\\': ['Backslash', 220], ';': ['Semicolon', 186], "'": ['Quote', 222], ',': ['Comma', 188], '.': ['Period', 190], '/': ['Slash', 191], ' ': ['Space', 32] };
function keyFor(ch) {
  if (/[a-z]/.test(ch)) return { code: 'Key' + ch.toUpperCase(), kc: ch.toUpperCase().charCodeAt(0), key: ch, shift: false };
  if (/[A-Z]/.test(ch)) return { code: 'Key' + ch, kc: ch.charCodeAt(0), key: ch, shift: true };
  if (/[0-9]/.test(ch)) return { code: 'Digit' + ch, kc: ch.charCodeAt(0), key: ch, shift: false };
  if (SHIFT_MAP[ch]) { const b = SHIFT_MAP[ch]; if (/[0-9]/.test(b)) return { code: 'Digit' + b, kc: b.charCodeAt(0), key: ch, shift: true }; const p = PUNCT[b]; return p ? { code: p[0], kc: p[1], key: ch, shift: true } : null; }
  if (PUNCT[ch]) { const [code, kc] = PUNCT[ch]; return { code, kc, key: ch, shift: false }; }
  return null;
}
(async () => {
  const list = await (await fetch(base + '/json/list')).json();
  const pages = list.filter(t => t.type === 'page' && (t.url || '').includes(pageMatch));
  if (!pages.length) { console.error('no page ' + pageMatch); process.exit(1); }
  const c = await connect(pages[0].webSocketDebuggerUrl);
  const rect = await evalExpr(c, `(() => { const cv=document.querySelector('canvas'); if(!cv) return null; const b=cv.getBoundingClientRect(); return {x:Math.round(b.x+b.width/2), y:Math.round(b.y+b.height/2)}; })()`);
  if (rect && flags.click === '1') {
    await c.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: rect.x, y: rect.y, button: 'left', clickCount: 1 });
    await c.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: rect.x, y: rect.y, button: 'left', clickCount: 1 });
    await new Promise(r => setTimeout(r, 300));
  }
  const delay = Number(flags.delay || 15);
  const down = (key, code, kc, mod) => c.send('Input.dispatchKeyEvent', { type: 'rawKeyDown', modifiers: mod, key, code, windowsVirtualKeyCode: kc, nativeVirtualKeyCode: kc });
  const up = (key, code, kc, mod) => c.send('Input.dispatchKeyEvent', { type: 'keyUp', modifiers: mod, key, code, windowsVirtualKeyCode: kc, nativeVirtualKeyCode: kc });
  if (flags.winr === '1') {
    await down('Meta', 'MetaLeft', 91, 4);
    await down('r', 'KeyR', 82, 4);
    await up('r', 'KeyR', 82, 4);
    await up('Meta', 'MetaLeft', 91, 0);
    await new Promise(r => setTimeout(r, 900));
  }
  const skipped = [];
  for (const ch of text) {
    const k = keyFor(ch);
    if (!k) { skipped.push(ch); continue; }
    if (k.shift) {
      await down('Shift', 'ShiftLeft', 16, 8);
      await down(k.key, k.code, k.kc, 8);
      await up(k.key, k.code, k.kc, 8);
      await up('Shift', 'ShiftLeft', 16, 0);
    } else {
      await down(k.key, k.code, k.kc, 0);
      await up(k.key, k.code, k.kc, 0);
    }
    await new Promise(r => setTimeout(r, delay));
  }
  if (flags.enter !== '0') {
    await new Promise(r => setTimeout(r, 400));
    await down('Enter', 'Enter', 13, 0);
    await up('Enter', 'Enter', 13, 0);
  }
  console.log('WINSEND ' + text.length + ' chars (winr=' + (flags.winr === '1') + ')' + (skipped.length ? ' SKIPPED=' + JSON.stringify(skipped) : ''));
  c.close(); process.exit(0);
})();
