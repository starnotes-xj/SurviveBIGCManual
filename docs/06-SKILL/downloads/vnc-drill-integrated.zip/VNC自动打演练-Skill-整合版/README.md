# VNC自动打演练-Skill-整合版

三套实战 SKILL 的整合版（2026-10-11 奇安信 tp.qianxin.com 演练实战沉淀）：

- 来源1：`Chrome/Edge + CDP 脚本流`（CTF-drill-skill，应急响应实战 33/36）
- 来源2：`字形解码 + base64 注入 工程流`（Desktop 上的 vnc-drill-autoplay / 补充篇 / 实战手册）
- 来源3：`chrome-devtools MCP 直驱流`（Claude Code 会话内直接注入 canvas）

## 30 秒上手

```bash
# 路线A（推荐脚本化）：浏览器开 --remote-debugging-port=9222 打开演练页后
node scripts/cdp.js list                         # 看页面
node scripts/submit.js --list                    # 全部场景：未答题 + 分数（防重复提交的核心）
node scripts/submit.js "<题面子串>" "<答案>"       # 自动跨场景定位并提交（防重三道闸 + answers.json 留痕）
node scripts/peek-tasks.js                       # 后台静默统计三场景进度

# 操作 VNC（靶机未登录时）
node scripts/vm.js shot  "deviceName=X" a.png    # 截 canvas
node scripts/vm.js type  "deviceName=X" "id"     # 注入命令（自动物理 Shift）
node scripts/vm.js enter "deviceName=X"

# 路线B（Agent 会话内）：把 scripts/vnc-helper-browser.js 全文注入页面 evaluate_script，
# 之后用 window.__vnc.type()/click()/key()/press() 操作。
```

## 文档

| 文件 | 内容 |
|---|---|
| `SKILL.md` | 主文档：架构、SOP、四条铁律、自动答题提交、踩坑总表、脚本索引 |
| `ANALYSIS.md` | 三套原 SKILL 的优缺点分析与取舍（为什么合并、丢了什么） |
| `reference/platform-api.md` | 平台 URL 模板/API/设备凭据/坐标换算 |
| `reference/forensics-playbook.md` | 取证速查（Linux/Windows/pcap）+ 证据级答案校验 + 实战案例 |

## 安装为 Claude Code 技能（可选）

把本目录复制/软链到用户技能目录，目录名用 skill 名：
```
%USERPROFILE%\.claude\skills\vnc-drill-integrated\   ← 复制本目录内容
```

## 依赖

- Node ≥ 22（零 npm 依赖）；PowerShell 5.1（工具类脚本）；Windows 优先。
- 可选：带 `--remote-debugging-port=9222` 的 Chrome/Edge（路线A）。
